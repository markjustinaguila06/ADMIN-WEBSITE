#!/usr/bin/env node

/**
 * Firebase Setup Script for DisCon-X
 * 
 * This script helps set up the initial Firebase configuration
 * and imports default data to the Firestore database.
 */

const firebaseService = require('./src/services/firebase-service');
require('dotenv').config({ path: './environment.env' });

// Default safety tips data
const defaultSafetyTips = {
    title: "Wi-Fi Safety Tips",
    description: "Essential security tips for safe Wi-Fi usage",
    tips: [
        {
            id: 1,
            category: "password",
            priority: "high",
            icon: "user",
            iconColor: "blue",
            title: "Use strong, unique passwords",
            description: "Use strong, unique passwords for your Wi-Fi and devices.",
            details: "Create complex passwords with at least 12 characters, including uppercase, lowercase, numbers, and special characters. Avoid using the same password for multiple devices.",
            iconSvg: "M12 17v.01M12 13a4 4 0 0 1 4 4v1H8v-1a4 4 0 0 1 4-4zM12 7a4 4 0 1 1 0 8 4 4 0 0 1 0-8z"
        },
        {
            id: 2,
            category: "router_security",
            priority: "high",
            icon: "check",
            iconColor: "green",
            title: "Change default router credentials",
            description: "Change default router credentials to prevent unauthorized access.",
            details: "Replace the default admin username and password on your router. Many routers come with 'admin/admin' or 'admin/password' which are easily exploited by attackers.",
            iconSvg: "M5 13l4 4L19 7"
        },
        {
            id: 3,
            category: "encryption",
            priority: "high",
            icon: "clock",
            iconColor: "yellow",
            title: "Enable WPA3 or WPA2 encryption",
            description: "Enable WPA3 or WPA2 encryption on your Wi-Fi network.",
            details: "Use the strongest encryption available on your router. WPA3 is the latest and most secure, but WPA2 is acceptable if WPA3 isn't available. Avoid WEP encryption.",
            iconSvg: "M12 8v4l3 3M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20z"
        },
        {
            id: 4,
            category: "firmware",
            priority: "medium",
            icon: "sun",
            iconColor: "red",
            title: "Keep your router firmware updated",
            description: "Keep your router firmware updated for the latest security patches.",
            details: "Regularly check for firmware updates from your router manufacturer. Enable automatic updates if available. Outdated firmware can contain security vulnerabilities.",
            iconSvg: "M18.364 5.636l-1.414 1.414M6.343 17.657l-1.415 1.415M12 2v2M12 20v2M4.222 4.222l1.415 1.415M19.778 19.778l-1.415-1.415M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10z"
        },
        {
            id: 5,
            category: "wps",
            priority: "medium",
            icon: "lock",
            iconColor: "purple",
            title: "Disable WPS",
            description: "Disable WPS (Wi-Fi Protected Setup) if not needed.",
            details: "WPS can be vulnerable to brute force attacks. Unless you frequently connect new devices, it's safer to disable this feature and connect devices manually.",
            iconSvg: "M3 11h18a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM7 11V7a5 5 0 0 1 10 0v4"
        },
        {
            id: 6,
            category: "public_wifi",
            priority: "high",
            icon: "arrow-right",
            iconColor: "cyan",
            title: "Be cautious of public Wi-Fi",
            description: "Be cautious of public Wi-Fi—avoid accessing sensitive data on open networks.",
            details: "Use a VPN when connecting to public Wi-Fi. Avoid accessing banking, email, or other sensitive accounts. Turn off automatic Wi-Fi connection on your devices.",
            iconSvg: "M17 16l4-4m0 0l-4-4m4 4H7"
        },
        {
            id: 7,
            category: "device_monitoring",
            priority: "medium",
            icon: "clock",
            iconColor: "rose",
            title: "Monitor connected devices",
            description: "Monitor connected devices and remove unknown ones.",
            details: "Regularly check your router's admin panel for connected devices. Remove any devices you don't recognize and consider changing your password if suspicious devices are found.",
            iconSvg: "M12 8v4l3 3M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20z"
        },
        {
            id: 8,
            category: "guest_network",
            priority: "low",
            icon: "grid",
            iconColor: "green",
            title: "Use a guest network",
            description: "Use a guest network for visitors to keep your main network secure.",
            details: "Set up a separate guest network for visitors. This isolates guest devices from your main network and prevents access to your personal devices and files.",
            iconSvg: "M9 9h6v6H9zM3 9v6a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9"
        }
    ],
    metadata: {
        version: "1.0",
        lastUpdated: new Date().toISOString(),
        totalTips: 8,
        categories: ["password", "router_security", "encryption", "firmware", "wps", "public_wifi", "device_monitoring", "guest_network"]
    }
};

// Default app configuration
const defaultConfig = {
    scanInterval: 30,
    threatDetectionEnabled: true,
    autoReportThreats: false,
    maxNetworksToStore: 100,
    apiVersion: '1.0.0',
    features: {
        realTimeScanning: true,
        gpsTracking: true,
        threatReporting: true,
        whitelistSync: true
    },
    serverEndpoints: {
        scanData: '/api/mobile/scan-data',
        threatReport: '/api/mobile/threat-report',
        safetyTips: '/api/safety-tips'
    }
};

async function setupFirebase() {
    console.log('🔥 Starting Firebase setup for DisCon-X...\n');

    try {
        // Initialize Firebase
        console.log('1. Initializing Firebase service...');
        await firebaseService.initialize();
        console.log('✅ Firebase service initialized successfully\n');

        // Test Firebase connection
        console.log('2. Testing Firebase connection...');
        const healthCheck = await firebaseService.healthCheck();
        if (!healthCheck.success) {
            throw new Error(`Firebase health check failed: ${healthCheck.error}`);
        }
        console.log('✅ Firebase connection healthy\n');

        // Import safety tips
        console.log('3. Importing safety tips...');
        const tipsResult = await firebaseService.importSafetyTips(defaultSafetyTips);
        if (tipsResult.success) {
            console.log(`✅ Imported ${defaultSafetyTips.tips.length} safety tips successfully`);
        } else {
            console.log(`⚠️  Safety tips import warning: ${tipsResult.error}`);
        }
        console.log('');

        // Set app configuration
        console.log('4. Setting up app configuration...');
        const configResult = await firebaseService.updateAppConfiguration(defaultConfig);
        if (configResult.success) {
            console.log('✅ App configuration set successfully');
        } else {
            console.log(`⚠️  App configuration warning: ${configResult.error}`);
        }
        console.log('');

        // Create sample data for testing
        console.log('5. Creating sample data for testing...');
        
        // Sample network scan data
        const sampleScanData = {
            lastScan: new Date().toISOString(),
            networks: [
                {
                    ssid: "Sample_WiFi_Network",
                    bssid: "00:11:22:33:44:55",
                    security: "WPA2",
                    signalStrength: -45,
                    frequency: 2412,
                    capabilities: ["WPA2-PSK-CCMP"],
                    isConnected: false,
                    isSuspicious: false
                },
                {
                    ssid: "Suspicious_Network",
                    bssid: "AA:BB:CC:DD:EE:FF",
                    security: "OPEN",
                    signalStrength: -30,
                    frequency: 2412,
                    capabilities: [],
                    isConnected: false,
                    isSuspicious: true
                }
            ],
            statistics: {
                totalNetworks: 2,
                suspiciousNetworks: 1,
                verifiedNetworks: 1,
                threatsDetected: 1
            },
            deviceId: "sample_device_001",
            location: {
                latitude: 14.2117,
                longitude: 121.1644,
                accuracy: 10.0,
                city: "Manila",
                address: "Sample Address, Manila"
            }
        };

        const scanResult = await firebaseService.saveNetworkScanData(sampleScanData);
        if (scanResult.success) {
            console.log('✅ Sample network scan data created');
        }

        // Sample threat report
        const sampleThreatReport = {
            network: {
                ssid: "Suspicious_Network",
                bssid: "AA:BB:CC:DD:EE:FF",
                security: "OPEN",
                signalStrength: -30
            },
            location: {
                latitude: 14.2117,
                longitude: 121.1644,
                accuracy: 5.0,
                city: "Manila",
                address: "Sample Location, Manila"
            },
            deviceId: "sample_device_001",
            additionalInfo: "Network appeared suddenly with unusually strong signal",
            reportType: "suspicious",
            status: "pending"
        };

        const threatResult = await firebaseService.saveThreatReport(sampleThreatReport);
        if (threatResult.success) {
            console.log('✅ Sample threat report created');
        }

        console.log('');
        console.log('🎉 Firebase setup completed successfully!');
        console.log('');
        console.log('📋 Setup Summary:');
        console.log(`   • Safety Tips: ${defaultSafetyTips.tips.length} imported`);
        console.log('   • App Configuration: Set');
        console.log('   • Sample Data: Created');
        console.log('   • Database: Ready');
        console.log('');
        console.log('🚀 Your DisCon-X Firebase integration is ready to use!');
        console.log('');
        console.log('📝 Next steps:');
        console.log('   1. Update your .env file with Firebase credentials');
        console.log('   2. Start your server: npm start');
        console.log('   3. Test the API endpoints');
        console.log('   4. Deploy Firestore rules: firebase deploy --only firestore:rules');
        console.log('');
        console.log('📊 Monitor your Firebase usage at: https://console.firebase.google.com');

    } catch (error) {
        console.error('❌ Firebase setup failed:', error.message);
        console.log('');
        console.log('🔧 Troubleshooting:');
        console.log('   1. Check your .env file contains valid Firebase credentials');
        console.log('   2. Ensure your Firebase project has Firestore enabled');
        console.log('   3. Verify your service account has proper permissions');
        console.log('   4. Check your internet connection');
        process.exit(1);
    }
}

// Run setup if called directly
if (require.main === module) {
    setupFirebase();
}

module.exports = { setupFirebase, defaultSafetyTips, defaultConfig };

# DisConX - Wi-Fi Network Security Monitoring Platform

<div align="center">
  
  [![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://semver.org)
  [![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
  [![Platform](https://img.shields.io/badge/platform-Web%20%7C%20Android%20%7C%20iOS-lightgrey.svg)]()
  [![Node.js](https://img.shields.io/badge/node.js-18%2B-brightgreen.svg)](https://nodejs.org)
  [![Flutter](https://img.shields.io/badge/flutter-3.0%2B-blue.svg)](https://flutter.dev)
  [![Express](https://img.shields.io/badge/express-4.18%2B-000000.svg)](https://expressjs.com)

  **A comprehensive Wi-Fi security monitoring solution featuring real-time threat detection, network analysis, and secure connection management.**
</div>

---

## 🌟 Overview

DisConX (Disconnect X) is a comprehensive Wi-Fi network security monitoring platform designed to protect users from malicious networks and provide insights into Wi-Fi security threats. The platform consists of a powerful web dashboard for administrators and a mobile application for end-users, working together to create a robust network security ecosystem.

### 🎯 Mission Statement

To provide accessible and effective Wi-Fi security monitoring tools that protect users from network-based threats while educating them about safe connectivity practices.

## ✨ Features

### 🖥️ Web Dashboard

#### **Network Monitoring & Analysis**
- 📊 **Real-time Network Statistics** - Live monitoring of network counts, verification status, and user activity
- 🗺️ **Interactive Coverage Maps** - Geographical visualization of network distribution across regions
- 📈 **Trend Analysis** - Historical data analysis with interactive charts and graphs
- 🔍 **Network Discovery** - Automated scanning and cataloging of available Wi-Fi networks

#### **Security & Threat Management**
- 🛡️ **Advanced Threat Detection** - Real-time identification of malicious networks and security threats
- ⚠️ **Evil Twin Detection** - Sophisticated algorithms to detect rogue access points
- 🚨 **Forensic Analysis Tools** - Detailed threat investigation and analysis capabilities
- 📋 **Threat Intelligence Dashboard** - Comprehensive threat reporting and monitoring

#### **User & Network Management**
- 👥 **User Activity Monitoring** - Track user connections and behavior patterns
- 📱 **Mobile App Integration** - Seamless connection with mobile applications
- ✅ **Network Whitelisting** - Manage trusted and verified networks
- 🔐 **Access Control** - Role-based permissions and security controls

#### **Analytics & Reporting**
- 📊 **Comprehensive Analytics** - Detailed reports on network usage and security metrics
- 📈 **Performance Metrics** - System performance and health monitoring
- 📋 **Custom Reports** - Generate tailored reports for different stakeholders
- 💼 **Export Capabilities** - Data export in multiple formats (PDF, CSV, JSON)

### 📱 Mobile Application (Flutter)

#### **Core Functionality**
- 🔍 **WiFi Network Scanning** - Real-time scanning of available networks
- 📶 **Signal Strength Analysis** - Detailed signal quality and strength measurements
- 🔒 **Security Assessment** - Automated security evaluation of discovered networks
- 🌐 **Intelligent Connection Management** - Smart connection recommendations and management

#### **Security Features**
- 🛡️ **Threat Detection** - On-device threat identification and alerts
- ⚠️ **Security Warnings** - Real-time notifications about suspicious networks
- 🔐 **Secure Connection Protocols** - Implementation of best-practice connection methods
- 📍 **Location-based Security** - Geographic context for network security decisions

#### **User Experience**
- 🎨 **Modern Material Design** - Clean, intuitive user interface
- 🌙 **Dark/Light Mode Support** - Customizable theme preferences
- 📚 **Educational Content** - Built-in security education and tips
- 🏆 **Interactive Quizzes** - Gamified learning experiences

#### **Data & Privacy**
- 🔒 **Local Data Storage** - Secure local data management
- ☁️ **Cloud Synchronization** - Optional cloud backup and sync
- 🚫 **Privacy Controls** - Granular privacy and data sharing controls
- 📊 **Usage Analytics** - Optional usage statistics and improvement data

## 🏗️ Architecture

### System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Mobile App    │    │  Web Dashboard  │    │  Backend API    │
│   (Flutter)     │◄──►│    (HTML/JS)    │◄──►│  (Node.js/Express)│
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Local Storage   │    │ Static Assets   │    │ Safety Tips API │
│ (SQLite/Prefs)  │    │ (CSS/JS/Images) │    │ (JSON Data)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### Technology Stack

#### **Backend (Web Dashboard)**
- **Runtime**: Node.js 18+
- **Framework**: Express.js 4.18+
- **Static Serving**: Express Static Middleware
- **API**: RESTful JSON API
- **CORS**: Cross-Origin Resource Sharing enabled

#### **Frontend (Web Dashboard)**
- **Core**: Vanilla JavaScript (ES6+)
- **Styling**: Modern CSS3 with CSS Grid and Flexbox
- **Maps**: Leaflet.js for interactive mapping
- **Charts**: Chart.js for data visualization
- **Architecture**: Component-based modular design

#### **Mobile Application**
- **Framework**: Flutter 3.0+ (Dart)
- **State Management**: Provider pattern
- **Local Storage**: SharedPreferences & SQLite
- **Networking**: Dio HTTP client
- **Maps**: Flutter Map with Leaflet integration
- **Location**: Geolocator for GPS services

#### **External Services**
- **Firebase**: Authentication, Analytics, Cloud Messaging
- **WiFi APIs**: Platform-specific WiFi scanning and management
- **Location Services**: GPS and network-based positioning

## 📋 Prerequisites

### System Requirements

#### **For Web Dashboard**
- Node.js 16+ (Node.js 18+ recommended)
- npm 8+ (comes with Node.js)
- Modern web browser (Chrome 90+, Firefox 88+, Safari 14+, Edge 90+)
- 2GB RAM minimum
- 500MB disk space

#### **For Mobile Development**
- Flutter SDK 3.0+
- Dart SDK 3.0+
- Android Studio (for Android development)
- Xcode (for iOS development, macOS only)
- Android SDK API level 21+ (Android 5.0+)
- iOS 12.0+ (for iOS development)

### Development Tools
- Git 2.30+
- VS Code or preferred IDE
- Chrome DevTools for debugging
- Flutter DevTools
- Android/iOS simulators or physical devices

## 🚀 Installation & Setup

### Quick Start (Web Dashboard)

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/websitecapstone.git
   cd websitecapstone
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm start
   ```

4. **Access the application**
   - 🌐 **Web Dashboard**: http://localhost:3000
   - 🔧 **API Health Check**: http://localhost:3000/api/health
   - 📚 **Safety Tips API**: http://localhost:3000/api/safety-tips

### Mobile Application Setup

1. **Navigate to mobile directory**
   ```bash
   cd disconx
   ```

2. **Install Flutter dependencies**
   ```bash
   flutter pub get
   ```

3. **Configure Firebase (Optional)**
   ```bash
   # Add your google-services.json (Android) and GoogleService-Info.plist (iOS)
   # Configure Firebase project settings
   ```

4. **Run the application**
   ```bash
   # For Android
   flutter run -d android
   
   # For iOS (macOS only)
   flutter run -d ios
   
   # For web
   flutter run -d chrome
   ```

### Production Deployment

#### **Web Dashboard Deployment**

1. **Environment Configuration**
   ```bash
   # Set environment variables
   export NODE_ENV=production
   export PORT=3000
   ```

2. **Install production dependencies**
   ```bash
   npm ci --only=production
   ```

3. **Start production server**
   ```bash
   npm start
   ```

#### **Mobile App Deployment**

1. **Build for production**
   ```bash
   # Android APK
   flutter build apk --release
   
   # Android App Bundle
   flutter build appbundle --release
   
   # iOS (macOS only)
   flutter build ios --release
   ```

2. **Deploy to app stores**
   - Follow Google Play Store guidelines for Android
   - Follow App Store guidelines for iOS

## 📁 Project Structure

```
websitecapstone/
├── 🌐 Web Dashboard
│   ├── server.js                    # Express server entry point
│   ├── package.json                 # Node.js dependencies
│   ├── index.html                   # Main dashboard SPA
│   ├── login.html                   # Authentication page
│   ├── redirect.html                # OAuth redirect handler
│   ├── script.js                    # Main application logic
│   └── src/
│       ├── components/              # Reusable UI components
│       │   ├── Card/               # Card component
│       │   ├── Header/             # Header component
│       │   └── Sidebar/            # Sidebar navigation
│       ├── features/               # Feature-specific modules
│       │   ├── AnalyticsReports.js # Analytics functionality
│       │   ├── WhitelistTable.js   # Network whitelist management
│       │   └── WiFiNetworks.js     # Network discovery and management
│       ├── styles/                 # CSS stylesheets
│       │   ├── global.css          # Global styles and variables
│       │   ├── dashboard.css       # Dashboard-specific styles
│       │   ├── sidebar.css         # Navigation styles
│       │   └── *.css              # Feature-specific styles
│       └── utils/                  # Utility functions
│           ├── auth.js             # Authentication utilities
│           ├── charts.js           # Chart rendering utilities
│           ├── dashboard.js        # Dashboard functionality
│           ├── map.js              # Interactive map utilities
│           └── threats.js          # Threat detection utilities
│
└── 📱 Mobile Application (disconx/)
    ├── android/                     # Android platform files
    ├── ios/                        # iOS platform files
    ├── lib/                        # Dart source code
    │   ├── main.dart               # Application entry point
    │   ├── app.dart                # App configuration
    │   ├── core/                   # Core utilities and constants
    │   │   ├── constants/          # Application constants
    │   │   ├── theme/              # Theme configuration
    │   │   └── utils/              # Core utilities
    │   ├── data/                   # Data layer
    │   │   ├── models/             # Data models
    │   │   ├── repositories/       # Data repositories
    │   │   └── services/           # Data services
    │   ├── presentation/           # UI layer
    │   │   ├── screens/            # Application screens
    │   │   ├── widgets/            # Reusable widgets
    │   │   └── dialogs/            # Dialog components
    │   └── providers/              # State management
    ├── assets/                     # Static assets
    │   └── images/                 # Image resources
    ├── pubspec.yaml               # Flutter dependencies
    └── README.md                  # Mobile app documentation
```

## 🔌 API Documentation

### Base URL
```
http://localhost:3000/api
```

### Authentication
Currently, the API uses CORS for cross-origin requests. Authentication will be implemented in future versions.

### Endpoints

#### **Health Check**
```http
GET /api/health
```

**Response:**
```json
{
  "success": true,
  "status": "healthy",
  "service": "DisCon-X API",
  "version": "1.0.0",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "endpoints": {
    "GET /api/safety-tips": "Get all safety tips",
    "GET /api/safety-tips/:id": "Get specific safety tip",
    "GET /api/safety-tips/category/:category": "Get tips by category",
    "GET /api/safety-tips/priority/:priority": "Get tips by priority"
  }
}
```

#### **Safety Tips**

**Get All Safety Tips**
```http
GET /api/safety-tips
```

**Get Safety Tip by ID**
```http
GET /api/safety-tips/:id
```

**Get Tips by Category**
```http
GET /api/safety-tips/category/:category
```

Available categories: `password`, `router_security`, `encryption`, `firmware`, `wps`, `public_wifi`, `device_monitoring`, `guest_network`

**Get Tips by Priority**
```http
GET /api/safety-tips/priority/:priority
```

Available priorities: `high`, `medium`, `low`

**Example Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "category": "password",
    "priority": "high",
    "title": "Use strong, unique passwords",
    "description": "Use strong, unique passwords for your Wi-Fi and devices.",
    "details": "Create complex passwords with at least 12 characters...",
    "iconSvg": "M12 17v.01M12 13a4 4 0 0 1 4 4v1H8v-1a4 4 0 0 1 4-4z..."
  },
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

## 💻 Usage Examples

### Web Dashboard

#### **Accessing the Dashboard**
1. Start the server: `npm start`
2. Navigate to: `http://localhost:3000`
3. Use the navigation sidebar to explore different sections

#### **Key Features Usage**

**Dashboard Overview**
- View real-time statistics on the main dashboard
- Click on stat cards for detailed breakdowns
- Monitor system health and performance metrics

**Network Analysis**
- Navigate to "Networks" section
- Use filters to sort by security level, signal strength, or location
- Click on networks for detailed analysis

**Threat Detection**
- Access "Threats" section for security insights
- Review forensic analysis for detected threats
- Export threat reports for further investigation

**Coverage Mapping**
- Use "Coverage Map" for geographical network visualization
- Click on regions for detailed provincial statistics
- Analyze network density and coverage patterns

### Mobile Application

#### **Initial Setup**
1. Install the app on your Android/iOS device
2. Grant necessary permissions (Location, WiFi access)
3. Complete the onboarding process

#### **Core Functionality**

**WiFi Scanning**
- Tap the scan button to discover nearby networks
- View detailed information about each network
- Check security ratings and recommendations

**Security Assessment**
- Review automatic security evaluations
- Follow recommended actions for suspicious networks
- Enable notifications for threat alerts

**Educational Content**
- Access the learning section for security tips
- Complete interactive quizzes to test knowledge
- Bookmark important security information

## 🛠️ Development

### Setting Up Development Environment

1. **Clone and setup**
   ```bash
   git clone <repository-url>
   cd websitecapstone
   npm install
   cd disconx && flutter pub get
   ```

2. **Start development servers**
   ```bash
   # Terminal 1 - Web Dashboard
   npm start
   
   # Terminal 2 - Mobile App
   cd disconx && flutter run
   ```

3. **Development workflow**
   - Use hot reload for rapid development
   - Test on multiple devices and browsers
   - Follow coding standards and conventions

### Code Style and Standards

#### **Web Dashboard (JavaScript)**
- Use ES6+ syntax and features
- Follow modular component architecture
- Implement responsive design principles
- Use semantic HTML and accessible design

#### **Mobile App (Dart/Flutter)**
- Follow Dart style guidelines
- Use proper widget composition
- Implement Material Design principles
- Handle platform-specific differences

### Testing

#### **Web Dashboard Testing**
```bash
# Manual testing checklist
- Cross-browser compatibility
- Responsive design on various screen sizes
- API endpoint functionality
- Interactive features and navigation
```

#### **Mobile App Testing**
```bash
# Flutter testing commands
flutter test                    # Unit tests
flutter integration_test       # Integration tests
flutter drive --target=test_driver/app.dart  # E2E tests
```

### Contributing Guidelines

1. **Fork the repository**
2. **Create a feature branch** (`git checkout -b feature/amazing-feature`)
3. **Make your changes** following the coding standards
4. **Test thoroughly** on multiple platforms
5. **Commit your changes** (`git commit -m 'Add amazing feature'`)
6. **Push to your branch** (`git push origin feature/amazing-feature`)
7. **Open a Pull Request** with detailed description

### Pull Request Requirements

- [ ] Code follows project style guidelines
- [ ] Self-review of code completed
- [ ] Changes tested on multiple platforms
- [ ] Documentation updated if necessary
- [ ] No breaking changes introduced
- [ ] Performance impact considered

## 🚀 Deployment

### Production Deployment Checklist

#### **Web Dashboard**
- [ ] Environment variables configured
- [ ] Production build optimized
- [ ] HTTPS certificate installed
- [ ] Database backups configured
- [ ] Monitoring and logging setup
- [ ] Performance optimization applied

#### **Mobile Application**
- [ ] App signing configured
- [ ] Store listings prepared
- [ ] Privacy policy and terms updated
- [ ] App permissions minimized
- [ ] Crash reporting configured
- [ ] Analytics implementation verified

### Deployment Platforms

#### **Web Dashboard Options**
- **Heroku**: Easy deployment with git integration
- **Vercel**: Optimized for static sites and serverless
- **DigitalOcean**: Full server control and customization
- **AWS EC2**: Enterprise-grade scalability and reliability

#### **Mobile App Distribution**
- **Google Play Store**: Android app distribution
- **Apple App Store**: iOS app distribution
- **Alternative stores**: Samsung Galaxy Store, Amazon Appstore

## 🔧 Configuration

### Environment Variables

```bash
# Web Dashboard
NODE_ENV=production              # Environment mode
PORT=3000                       # Server port
API_BASE_URL=http://localhost:3000  # API base URL

# Mobile App
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_API_KEY=your-api-key
ENABLE_ANALYTICS=true
DEBUG_MODE=false
```

### Configuration Files

#### **Web Dashboard**
- `package.json`: Dependencies and scripts
- `server.js`: Server configuration and routes

#### **Mobile Application**
- `pubspec.yaml`: Flutter dependencies
- `android/app/build.gradle`: Android configuration
- `ios/Runner/Info.plist`: iOS configuration

## 📊 Performance Optimization

### Web Dashboard
- Implement lazy loading for large datasets
- Optimize image assets and compression
- Use efficient data fetching strategies
- Enable browser caching for static assets

### Mobile Application
- Implement efficient state management
- Optimize widget rebuilds and animations
- Use appropriate caching strategies
- Minimize network requests and data usage

## 🛡️ Security Considerations

### Web Dashboard Security
- Implement proper CORS policies
- Validate and sanitize all inputs
- Use HTTPS in production
- Implement rate limiting for APIs

### Mobile App Security
- Secure local data storage
- Implement certificate pinning
- Validate all network communications
- Follow platform security guidelines

## 🐛 Troubleshooting

### Common Issues

#### **Web Dashboard**

**Port already in use**
```bash
# Find and kill process using port 3000
lsof -ti:3000 | xargs kill -9
# Or change port in server.js
```

**CORS issues**
- Check CORS configuration in server.js
- Ensure proper headers are set
- Verify origin whitelist settings

**Module import errors**
- Verify Node.js version compatibility
- Clear npm cache: `npm cache clean --force`
- Delete node_modules and reinstall: `rm -rf node_modules && npm install`

#### **Mobile Application**

**Flutter build issues**
```bash
flutter clean
flutter pub get
flutter doctor  # Check for issues
```

**Permission errors**
- Check platform-specific permission configurations
- Verify permissions are requested at runtime
- Test on physical devices for accurate results

**Network connectivity issues**
- Verify network permissions in manifests
- Check Firebase configuration
- Test with different network conditions

### Getting Help

1. **Check existing issues** in the repository
2. **Review documentation** and troubleshooting guides
3. **Search community forums** for similar problems
4. **Create a detailed issue** with reproduction steps
5. **Contact maintainers** for critical issues

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

### Third-Party Licenses

- **Flutter**: BSD 3-Clause License
- **Node.js**: MIT License
- **Express.js**: MIT License
- **Leaflet**: BSD 2-Clause License
- **Chart.js**: MIT License

## 🤝 Acknowledgments

### Contributors
- **Development Team**: Core development and maintenance
- **Security Researchers**: Threat detection algorithms and analysis
- **UI/UX Designers**: User interface and experience design
- **Community Contributors**: Bug reports, feature requests, and improvements

### Special Thanks
- DICT (Department of Information and Communications Technology) for project sponsorship
- Open source community for providing excellent tools and libraries
- Beta testers for valuable feedback and bug reports
- Security community for threat intelligence and best practices

### Inspiration
This project was inspired by the need for accessible Wi-Fi security tools and the growing importance of network security awareness in our connected world.

---

<div align="center">
  <p><strong>Made with ❤️ for a safer connected world</strong></p>
  
  [![GitHub stars](https://img.shields.io/github/stars/your-username/websitecapstone?style=social)](https://github.com/your-username/websitecapstone)
  [![GitHub forks](https://img.shields.io/github/forks/your-username/websitecapstone?style=social)](https://github.com/your-username/websitecapstone)
  [![Follow on Twitter](https://img.shields.io/twitter/follow/your-twitter?style=social)](https://twitter.com/your-twitter)
</div>

## 📞 Contact & Support

- **Project Repository**: [GitHub](https://github.com/your-username/websitecapstone)
- **Issue Tracker**: [GitHub Issues](https://github.com/your-username/websitecapstone/issues)
- **Email**: project-email@example.com
- **Documentation**: [Wiki](https://github.com/your-username/websitecapstone/wiki)

---

*This README was last updated on: December 2024*

// Main dashboard logic for DisCon-X
// This file provides fallback functionality and test controls

document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if main.js hasn't already handled it
    if (!window.showSection) {
        console.log('Main.js not loaded, setting up fallback navigation...');
        
        // Fallback showSection function
        window.showSection = function(sectionName) {
            // Hide all sections
            document.querySelectorAll('.main-content > div').forEach(section => {
                section.classList.remove('active');
            });

            // Show selected section
            const selectedSection = document.querySelector(`.${sectionName}`);
            if (selectedSection) {
                selectedSection.classList.add('active');
            }

            // Update navigation
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            const selectedNavItem = document.querySelector(`.nav-item[data-section="${sectionName}"]`);
            if (selectedNavItem) {
                selectedNavItem.classList.add('active');
            }

            // Update page title
            const pageTitle = document.querySelector('.page-title');
            if (pageTitle) {
                const titles = {
                    'dashboard': 'Dashboard',
                    'coverage-map': 'Coverage Map',
                    'networks': 'Wi-Fi Networks',
                    'safety-tips': 'Safety Tips',
                    'threats': 'Threat Activity',
                    'analytics-reports': 'Analytics & Reports',
                    'users': 'User Management',
                    'whitelist': 'Whitelist Management',
                    'notifications': 'Notifications',
                    'reports': 'Reports',
                    'settings': 'Settings'
                };
                pageTitle.textContent = titles[sectionName] || 'Dashboard';
            }

            // Dispatch section loaded event
            document.dispatchEvent(new CustomEvent('sectionLoaded', {
                detail: { section: sectionName }
            }));
        };
        
        // Setup fallback navigation handlers
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', () => {
                const section = item.dataset.section;
                if (section) {
                    window.showSection(section);
                }
            });
        });
    }

    // Initialize dashboard map if visible and not already initialized
    const dashboardSection = document.querySelector('.dashboard');
    if (dashboardSection && (dashboardSection.classList.contains('active') || dashboardSection.style.display !== 'none')) {
        const checkLeaflet = setInterval(() => {
            if (typeof L !== 'undefined') {
                clearInterval(checkLeaflet);
                setTimeout(() => {
                    if (typeof initializeMap === 'function') {
                        initializeMap('dashboardMap');
                    }
                }, 500);
            }
        }, 100);
    }

    // Initialize trends chart if function exists
    setTimeout(() => {
        if (typeof renderTrendsChart === 'function') {
            renderTrendsChart('Last 7 Days');
        }
    }, 1000);

    // Render threat activity table if function exists
    setTimeout(() => {
        console.log('Script.js: Attempting to render recent threat activity...');
        if (typeof renderRecentThreatActivity === 'function') {
            console.log('Script.js: renderRecentThreatActivity function found, calling it...');
            renderRecentThreatActivity();
        } else {
            console.warn('Script.js: renderRecentThreatActivity function not found!');
            // Fallback: try to manually populate the table
            const tableBody = document.querySelector('#recent-threat-table tbody');
            if (tableBody && tableBody.children.length === 0) {
                console.log('Script.js: Adding fallback placeholder...');
                tableBody.innerHTML = `
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 20px; color: #9ca3af;">
                            <div>Loading threat activity...</div>
                        </td>
                    </tr>
                `;
            }
        }
    }, 1500);

    // Expose forensics modal functions globally for button onclicks
    if (!window.openForensicsModal) {
        window.openForensicsModal = function(threatData) {
            console.log('Opening forensics modal:', threatData);
        };
    }
    
    if (!window.closeForensicsModal) {
        window.closeForensicsModal = function() {
            console.log('Closing forensics modal');
        };
    }
    
    if (!window.showEvilTwinAlert) {
        window.showEvilTwinAlert = function(threat) {
            console.log('Showing evil twin alert:', threat);
        };
    }
    
    if (!window.testThreatActivity) {
        window.testThreatActivity = function() {
            console.log('Testing threat activity');
        };
    }

    // Add user management functions
    if (!window.editUser) {
        window.editUser = function(userId) {
            console.log('Editing user:', userId);
            if (typeof window.showToast === 'function') {
                window.showToast('User edit functionality coming soon!', 'info');
            } else {
                alert('User edit functionality coming soon!');
            }
        };
    }

    if (!window.removeUser) {
        window.removeUser = function(userId) {
            console.log('Removing user:', userId);
            if (confirm('Are you sure you want to remove this user?')) {
                if (typeof window.showToast === 'function') {
                    window.showToast('User removed successfully', 'success');
                } else {
                    alert('User removed successfully');
                }
            }
        };
    }

    // Add trends chart dropdown functionality
    const trendsSelect = document.getElementById('trendsSelect');
    if (trendsSelect) {
        trendsSelect.addEventListener('change', (e) => {
            const selectedPeriod = e.target.value;
            console.log('Trends period changed:', selectedPeriod);
            if (typeof renderTrendsChart === 'function') {
                renderTrendsChart(selectedPeriod);
            }
            if (typeof window.showToast === 'function') {
                window.showToast(`Chart updated for ${selectedPeriod}`, 'info');
            }
        });
    }

    // Add logout functionality
    const logoutBtn = document.querySelector('.logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (confirm('Are you sure you want to logout?')) {
                if (typeof window.authManager !== 'undefined') {
                    window.authManager.logout();
                } else {
                    // Fallback logout
                    localStorage.clear();
                    window.location.href = 'login.html';
                }
            }
        });
    }

    // Add status badge functionality
    document.querySelectorAll('.status-badge').forEach(badge => {
        badge.addEventListener('click', (e) => {
            const currentStatus = e.target.textContent.trim();
            const newStatus = currentStatus === 'Active' ? 'Pending' : 'Active';
            e.target.textContent = newStatus;
            e.target.className = `status-badge ${newStatus.toLowerCase()}`;
            
            if (typeof window.showToast === 'function') {
                window.showToast(`Status changed to ${newStatus}`, 'success');
            }
        });
    });

    // Add table sorting functionality for sortable headers
    document.querySelectorAll('.sortable').forEach(header => {
        header.addEventListener('click', () => {
            const sortBy = header.dataset.sort;
            console.log('Sorting by:', sortBy);
            
            // Toggle sort direction
            const currentDirection = header.dataset.direction || 'asc';
            const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
            header.dataset.direction = newDirection;
            
            // Update visual indicators
            document.querySelectorAll('.sortable').forEach(h => {
                h.classList.remove('sort-asc', 'sort-desc');
            });
            header.classList.add(`sort-${newDirection}`);
            
            if (typeof window.showToast === 'function') {
                window.showToast(`Sorted by ${sortBy} (${newDirection})`, 'info');
            }
        });
    });

    // Add search functionality for map search inputs
    const mapSearchInputs = document.querySelectorAll('[id*="SearchInput"]');
    mapSearchInputs.forEach(input => {
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const searchValue = e.target.value.trim();
                if (searchValue) {
                    console.log('Map search:', searchValue);
                    if (typeof window.showToast === 'function') {
                        window.showToast(`Searching for: ${searchValue}`, 'info');
                    }
                    // Trigger map search functionality
                    if (typeof window.zoomToProvince === 'function') {
                        window.zoomToProvince(searchValue);
                    }
                }
            }
        });
    });

    // Add functionality for filter clear button
    const filterClearBtn = document.querySelector('.filter-clear-btn');
    if (filterClearBtn) {
        filterClearBtn.addEventListener('click', () => {
            if (typeof window.clearAllFilters === 'function') {
                window.clearAllFilters();
            }
        });
    }

    // Add functionality for export/refresh buttons
    const exportBtn = document.querySelector('.export-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            if (typeof window.exportThreats === 'function') {
                window.exportThreats();
            }
        });
    }

    const refreshBtn = document.querySelector('.refresh-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => {
            if (typeof window.refreshThreats === 'function') {
                window.refreshThreats();
            }
        });
    }

    // Add functionality for zoom controls
    document.querySelectorAll('[id*="ZoomIn"]').forEach(btn => {
        btn.addEventListener('click', () => {
            console.log('Zoom in clicked');
            if (typeof window.showToast === 'function') {
                window.showToast('Zooming in...', 'info');
            }
        });
    });

    document.querySelectorAll('[id*="ZoomOut"]').forEach(btn => {
        btn.addEventListener('click', () => {
            console.log('Zoom out clicked');
            if (typeof window.showToast === 'function') {
                window.showToast('Zooming out...', 'info');
            }
        });
    });

    // Add generic button click handlers for action buttons
    document.querySelectorAll('.action-btn').forEach(btn => {
        if (!btn.onclick && !btn.getAttribute('onclick')) {
            btn.addEventListener('click', (e) => {
                const buttonText = e.target.textContent.trim();
                console.log('Action button clicked:', buttonText);
                
                if (typeof window.showToast === 'function') {
                    window.showToast(`${buttonText} functionality activated`, 'info');
                } else {
                    console.log(`${buttonText} functionality would be executed here`);
                }
            });
        }
    });

});

// Cleanup on unload
window.addEventListener('beforeunload', () => {
    if (typeof cleanupMap === 'function') cleanupMap();
    if (typeof cleanupChart === 'function') cleanupChart();
}); 
#!/usr/bin/env node

/**
 * DisCon-X Startup Script
 * 
 * This script handles the startup process for the DisCon-X server
 * with proper Firebase initialization and error handling.
 */

const path = require('path');
require('dotenv').config({ path: './environment.env' });

console.log('🚀 Starting DisCon-X Server...\n');

// Check for required environment variables
const requiredEnvVars = ['FIREBASE_PROJECT_ID', 'FIREBASE_PRIVATE_KEY', 'FIREBASE_CLIENT_EMAIL'];
const missingEnvVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingEnvVars.length > 0) {
    console.log('⚠️  Warning: Missing Firebase environment variables:');
    missingEnvVars.forEach(varName => {
        console.log(`   - ${varName}`);
    });
    console.log('\n💡 Firebase will be disabled. The server will use in-memory storage.');
    console.log('   To enable Firebase, set up your environment variables in .env file.\n');
}

// Display startup information
console.log('📋 Configuration:');
console.log(`   • Port: ${process.env.PORT || 3000}`);
console.log(`   • Environment: ${process.env.NODE_ENV || 'development'}`);
console.log(`   • Firebase Project: ${process.env.FIREBASE_PROJECT_ID || 'Not configured'}`);
console.log(`   • Firebase Status: ${missingEnvVars.length === 0 ? '✅ Enabled' : '❌ Disabled'}`);
console.log('');

// Start the server
try {
    require('./server.js');
} catch (error) {
    console.error('❌ Failed to start server:', error.message);
    console.log('\n🔧 Troubleshooting:');
    console.log('   1. Check that all dependencies are installed: npm install');
    console.log('   2. Verify your .env file configuration');
    console.log('   3. Ensure Firebase credentials are correct');
    console.log('   4. Check that the port is not already in use');
    process.exit(1);
}

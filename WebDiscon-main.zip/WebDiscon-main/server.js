const express = require('express');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');
const firebaseService = require('./src/services/firebase-service');
require('dotenv').config({ path: './environment.env' });

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});
const port = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(__dirname));
app.use('/src', express.static(path.join(__dirname, 'src')));

// Enable CORS for mobile app integration
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    next();
});

// Initialize Firebase Service
let firebaseInitialized = false;
(async () => {
    try {
        await firebaseService.initialize();
        firebaseInitialized = true;
        console.log('🔥 Firebase initialized successfully');
        
        // Import existing safety tips to Firebase
        await firebaseService.importSafetyTips(safetyTipsData);
        console.log('📚 Safety tips imported to Firebase');
        
        // Set default app configuration
        const defaultConfig = {
            scanInterval: 30,
            threatDetectionEnabled: true,
            autoReportThreats: false,
            maxNetworksToStore: 100,
            apiVersion: '1.0.0',
            features: {
                realTimeScanning: true,
                gpsTracking: true,
                threatReporting: true,
                whitelistSync: true
            },
            serverEndpoints: {
                scanData: '/api/mobile/scan-data',
                threatReport: '/api/mobile/threat-report',
                safetyTips: '/api/safety-tips'
            }
        };
        await firebaseService.updateAppConfiguration(defaultConfig);
        console.log('⚙️ Default app configuration set');
        
    } catch (error) {
        console.error('❌ Firebase initialization failed:', error);
    }
})();

// Safety Tips Data - extracted from the dashboard
const safetyTipsData = {
    title: "Wi-Fi Safety Tips",
    description: "Essential security tips for safe Wi-Fi usage",
    tips: [
        {
            id: 1,
            category: "password",
            priority: "high",
            icon: "user",
            iconColor: "blue",
            title: "Use strong, unique passwords",
            description: "Use strong, unique passwords for your Wi-Fi and devices.",
            details: "Create complex passwords with at least 12 characters, including uppercase, lowercase, numbers, and special characters. Avoid using the same password for multiple devices.",
            iconSvg: "M12 17v.01M12 13a4 4 0 0 1 4 4v1H8v-1a4 4 0 0 1 4-4zM12 7a4 4 0 1 1 0 8 4 4 0 0 1 0-8z"
        },
        {
            id: 2,
            category: "router_security",
            priority: "high",
            icon: "check",
            iconColor: "green",
            title: "Change default router credentials",
            description: "Change default router credentials to prevent unauthorized access.",
            details: "Replace the default admin username and password on your router. Many routers come with 'admin/admin' or 'admin/password' which are easily exploited by attackers.",
            iconSvg: "M5 13l4 4L19 7"
        },
        {
            id: 3,
            category: "encryption",
            priority: "high",
            icon: "clock",
            iconColor: "yellow",
            title: "Enable WPA3 or WPA2 encryption",
            description: "Enable WPA3 or WPA2 encryption on your Wi-Fi network.",
            details: "Use the strongest encryption available on your router. WPA3 is the latest and most secure, but WPA2 is acceptable if WPA3 isn't available. Avoid WEP encryption.",
            iconSvg: "M12 8v4l3 3M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20z"
        },
        {
            id: 4,
            category: "firmware",
            priority: "medium",
            icon: "sun",
            iconColor: "red",
            title: "Keep your router firmware updated",
            description: "Keep your router firmware updated for the latest security patches.",
            details: "Regularly check for firmware updates from your router manufacturer. Enable automatic updates if available. Outdated firmware can contain security vulnerabilities.",
            iconSvg: "M18.364 5.636l-1.414 1.414M6.343 17.657l-1.415 1.415M12 2v2M12 20v2M4.222 4.222l1.415 1.415M19.778 19.778l-1.415-1.415M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10z"
        },
        {
            id: 5,
            category: "wps",
            priority: "medium",
            icon: "lock",
            iconColor: "purple",
            title: "Disable WPS",
            description: "Disable WPS (Wi-Fi Protected Setup) if not needed.",
            details: "WPS can be vulnerable to brute force attacks. Unless you frequently connect new devices, it's safer to disable this feature and connect devices manually.",
            iconSvg: "M3 11h18a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2zM7 11V7a5 5 0 0 1 10 0v4"
        },
        {
            id: 6,
            category: "public_wifi",
            priority: "high",
            icon: "arrow-right",
            iconColor: "cyan",
            title: "Be cautious of public Wi-Fi",
            description: "Be cautious of public Wi-Fi—avoid accessing sensitive data on open networks.",
            details: "Use a VPN when connecting to public Wi-Fi. Avoid accessing banking, email, or other sensitive accounts. Turn off automatic Wi-Fi connection on your devices.",
            iconSvg: "M17 16l4-4m0 0l-4-4m4 4H7"
        },
        {
            id: 7,
            category: "device_monitoring",
            priority: "medium",
            icon: "clock",
            iconColor: "rose",
            title: "Monitor connected devices",
            description: "Monitor connected devices and remove unknown ones.",
            details: "Regularly check your router's admin panel for connected devices. Remove any devices you don't recognize and consider changing your password if suspicious devices are found.",
            iconSvg: "M12 8v4l3 3M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20z"
        },
        {
            id: 8,
            category: "guest_network",
            priority: "low",
            icon: "grid",
            iconColor: "green",
            title: "Use a guest network",
            description: "Use a guest network for visitors to keep your main network secure.",
            details: "Set up a separate guest network for visitors. This isolates guest devices from your main network and prevents access to your personal devices and files.",
            iconSvg: "M9 9h6v6H9zM3 9v6a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9"
        }
    ],
    metadata: {
        version: "1.0",
        lastUpdated: new Date().toISOString(),
        totalTips: 8,
        categories: ["password", "router_security", "encryption", "firmware", "wps", "public_wifi", "device_monitoring", "guest_network"]
    }
};

// API Routes

// Get all safety tips
app.get('/api/safety-tips', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            // Fallback to in-memory data if Firebase not ready
            return res.json({
                success: true,
                data: safetyTipsData,
                timestamp: new Date().toISOString(),
                source: 'memory'
            });
        }

        const result = await firebaseService.getSafetyTips();
        if (result.success) {
            res.json({
                success: true,
                data: {
                    title: "Wi-Fi Safety Tips",
                    description: "Essential security tips for safe Wi-Fi usage",
                    tips: result.data,
                    metadata: {
                        version: "1.0",
                        lastUpdated: new Date().toISOString(),
                        totalTips: result.data.length,
                        source: 'firebase'
                    }
                },
                timestamp: new Date().toISOString()
            });
        } else {
            // Fallback to in-memory data
            res.json({
                success: true,
                data: safetyTipsData,
                timestamp: new Date().toISOString(),
                source: 'memory_fallback'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve safety tips',
            timestamp: new Date().toISOString()
        });
    }
});

// Get safety tips by category
app.get('/api/safety-tips/category/:category', async (req, res) => {
    try {
        const category = req.params.category.toLowerCase();
        
        if (!firebaseInitialized) {
            // Fallback to in-memory data
            const filteredTips = safetyTipsData.tips.filter(tip => tip.category === category);
            
            if (filteredTips.length === 0) {
                return res.status(404).json({
                    success: false,
                    error: `No tips found for category: ${category}`,
                    availableCategories: safetyTipsData.metadata.categories,
                    timestamp: new Date().toISOString()
                });
            }

            return res.json({
                success: true,
                data: {
                    category: category,
                    tips: filteredTips,
                    count: filteredTips.length
                },
                timestamp: new Date().toISOString()
            });
        }

        const result = await firebaseService.getSafetyTips(category);
        if (result.success) {
            if (result.data.length === 0) {
                return res.status(404).json({
                    success: false,
                    error: `No tips found for category: ${category}`,
                    timestamp: new Date().toISOString()
                });
            }

            res.json({
                success: true,
                data: {
                    category: category,
                    tips: result.data,
                    count: result.data.length
                },
                timestamp: new Date().toISOString()
            });
        } else {
            // Fallback to in-memory data
            const filteredTips = safetyTipsData.tips.filter(tip => tip.category === category);
            res.json({
                success: true,
                data: {
                    category: category,
                    tips: filteredTips,
                    count: filteredTips.length
                },
                timestamp: new Date().toISOString(),
                source: 'memory_fallback'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve safety tips by category',
            timestamp: new Date().toISOString()
        });
    }
});

// Get safety tips by priority
app.get('/api/safety-tips/priority/:priority', (req, res) => {
    try {
        const priority = req.params.priority.toLowerCase();
        const filteredTips = safetyTipsData.tips.filter(tip => tip.priority === priority);
        
        if (filteredTips.length === 0) {
            return res.status(404).json({
                success: false,
                error: `No tips found for priority: ${priority}`,
                availablePriorities: ["high", "medium", "low"],
                timestamp: new Date().toISOString()
            });
        }

        res.json({
            success: true,
            data: {
                priority: priority,
                tips: filteredTips,
                count: filteredTips.length
            },
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve safety tips by priority',
            timestamp: new Date().toISOString()
        });
    }
});

// Get single safety tip by ID
app.get('/api/safety-tips/:id', (req, res) => {
    try {
        const tipId = parseInt(req.params.id);
        const tip = safetyTipsData.tips.find(tip => tip.id === tipId);
        
        if (!tip) {
            return res.status(404).json({
                success: false,
                error: `Safety tip with ID ${tipId} not found`,
                timestamp: new Date().toISOString()
            });
        }

        res.json({
            success: true,
            data: tip,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve safety tip',
            timestamp: new Date().toISOString()
        });
    }
});

// Mobile App Integration APIs

// Store network scan data from mobile app (fallback for when Firebase is not available)
let networkScanData = {
    lastScan: null,
    networks: [],
    statistics: {
        totalNetworks: 0,
        suspiciousNetworks: 0,
        verifiedNetworks: 0,
        threatsDetected: 0
    }
};

// Store threat reports from mobile app (fallback for when Firebase is not available)
let threatReports = [];

// Store mobile app scan data
app.post('/api/mobile/scan-data', async (req, res) => {
    try {
        const { networks, statistics, scanTime, deviceId, location } = req.body;
        
        const scanData = {
            lastScan: scanTime || new Date().toISOString(),
            networks: networks || [],
            statistics: statistics || networkScanData.statistics,
            deviceId: deviceId,
            location: location
        };

        // Save to Firebase if available
        if (firebaseInitialized) {
            const firebaseResult = await firebaseService.saveNetworkScanData(scanData);
            if (firebaseResult.success) {
                // Broadcast to connected dashboard clients
                io.emit('scanDataUpdate', { ...scanData, id: firebaseResult.id, source: 'firebase' });
                
                return res.json({
                    success: true,
                    message: 'Scan data saved to Firebase successfully',
                    id: firebaseResult.id,
                    timestamp: new Date().toISOString()
                });
            }
        }
        
        // Fallback to in-memory storage
        networkScanData = scanData;
        
        // Broadcast to connected dashboard clients
        io.emit('scanDataUpdate', { ...networkScanData, source: 'memory' });
        
        res.json({
            success: true,
            message: 'Scan data received successfully',
            timestamp: new Date().toISOString(),
            source: 'memory'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to process scan data',
            timestamp: new Date().toISOString()
        });
    }
});

// Get current network scan data for dashboard
app.get('/api/mobile/scan-data', async (req, res) => {
    try {
        const { limit = 10, deviceId } = req.query;

        if (firebaseInitialized) {
            let result;
            if (deviceId) {
                result = await firebaseService.getNetworkScansByDevice(deviceId, parseInt(limit));
            } else {
                result = await firebaseService.getLatestNetworkScanData(parseInt(limit));
            }
            
            if (result.success) {
                return res.json({
                    success: true,
                    data: result.data.length > 0 ? result.data[0] : networkScanData,
                    allScans: result.data,
                    timestamp: new Date().toISOString(),
                    source: 'firebase'
                });
            }
        }

        // Fallback to in-memory data
        res.json({
            success: true,
            data: networkScanData,
            timestamp: new Date().toISOString(),
            source: 'memory'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve scan data',
            timestamp: new Date().toISOString()
        });
    }
});

// Submit threat report from mobile app
app.post('/api/mobile/threat-report', async (req, res) => {
    try {
        const { network, location, deviceId, additionalInfo, reportType } = req.body;
        
        const threatReport = {
            id: Date.now().toString(),
            network: network,
            location: location,
            deviceId: deviceId,
            additionalInfo: additionalInfo,
            reportType: reportType || 'suspicious',
            timestamp: new Date().toISOString(),
            status: 'pending'
        };

        // Save to Firebase if available
        if (firebaseInitialized) {
            const firebaseResult = await firebaseService.saveThreatReport(threatReport);
            if (firebaseResult.success) {
                // Broadcast to connected dashboard clients
                io.emit('threatReportUpdate', {
                    report: { ...threatReport, id: firebaseResult.id },
                    source: 'firebase'
                });
                
                return res.json({
                    success: true,
                    message: 'Threat report saved to Firebase successfully',
                    reportId: firebaseResult.id,
                    timestamp: new Date().toISOString()
                });
            }
        }
        
        // Fallback to in-memory storage
        threatReports.unshift(threatReport);
        
        // Keep only last 100 reports
        if (threatReports.length > 100) {
            threatReports = threatReports.slice(0, 100);
        }
        
        // Broadcast to connected dashboard clients
        io.emit('threatReportUpdate', {
            report: threatReport,
            totalReports: threatReports.length,
            source: 'memory'
        });
        
        res.json({
            success: true,
            message: 'Threat report submitted successfully',
            reportId: threatReport.id,
            timestamp: new Date().toISOString(),
            source: 'memory'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to submit threat report',
            timestamp: new Date().toISOString()
        });
    }
});

// Get threat reports for dashboard
app.get('/api/mobile/threat-reports', async (req, res) => {
    try {
        const { limit = 50, status = 'all' } = req.query;

        if (firebaseInitialized) {
            const result = await firebaseService.getThreatReports(parseInt(limit), status);
            if (result.success) {
                return res.json({
                    success: true,
                    data: {
                        reports: result.data,
                        total: result.data.length,
                        limit: parseInt(limit)
                    },
                    timestamp: new Date().toISOString(),
                    source: 'firebase'
                });
            }
        }
        
        // Fallback to in-memory data
        let filteredReports = threatReports;
        if (status !== 'all') {
            filteredReports = threatReports.filter(report => report.status === status);
        }
        
        const limitedReports = filteredReports.slice(0, parseInt(limit));
        
        res.json({
            success: true,
            data: {
                reports: limitedReports,
                total: filteredReports.length,
                limit: parseInt(limit)
            },
            timestamp: new Date().toISOString(),
            source: 'memory'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve threat reports',
            timestamp: new Date().toISOString()
        });
    }
});

// Mobile app configuration endpoint
app.get('/api/mobile/config', async (req, res) => {
    try {
        if (firebaseInitialized) {
            const result = await firebaseService.getAppConfiguration();
            if (result.success) {
                return res.json({
                    success: true,
                    data: result.data,
                    timestamp: new Date().toISOString(),
                    source: 'firebase'
                });
            }
        }

        // Fallback configuration
        const config = {
            scanInterval: 30, // seconds
            threatDetectionEnabled: true,
            autoReportThreats: false,
            maxNetworksToStore: 100,
            apiVersion: '1.0.0',
            features: {
                realTimeScanning: true,
                gpsTracking: true,
                threatReporting: true,
                whitelistSync: true
            },
            serverEndpoints: {
                scanData: '/api/mobile/scan-data',
                threatReport: '/api/mobile/threat-report',
                safetyTips: '/api/safety-tips'
            }
        };
        
        res.json({
            success: true,
            data: config,
            timestamp: new Date().toISOString(),
            source: 'memory'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve configuration',
            timestamp: new Date().toISOString()
        });
    }
});

// Firebase-specific endpoints

// Import whitelist and geolocation data endpoint
app.post('/api/admin/import-whitelist', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const { accessPoints, metadata } = req.body;
        
        if (!accessPoints || !Array.isArray(accessPoints)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid data format. Expected accessPoints array.',
                timestamp: new Date().toISOString()
            });
        }

        // Validate access point data structure
        const validationErrors = [];
        accessPoints.forEach((ap, index) => {
            if (!ap.ssid || !ap.macAddress) {
                validationErrors.push(`Access point ${index}: Missing required fields (ssid, macAddress)`);
            }
            if (ap.latitude && (typeof ap.latitude !== 'number' || ap.latitude < -90 || ap.latitude > 90)) {
                validationErrors.push(`Access point ${index}: Invalid latitude value`);
            }
            if (ap.longitude && (typeof ap.longitude !== 'number' || ap.longitude < -180 || ap.longitude > 180)) {
                validationErrors.push(`Access point ${index}: Invalid longitude value`);
            }
        });

        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                error: 'Data validation failed',
                details: validationErrors,
                timestamp: new Date().toISOString()
            });
        }

        const result = await firebaseService.importWhitelistData({
            accessPoints,
            metadata: metadata || {
                version: '1.0.0',
                importedAt: new Date().toISOString(),
                source: 'manual_import'
            }
        });
        
        res.json({
            success: result.success,
            message: result.success ? 'Whitelist data imported successfully' : 'Failed to import whitelist data',
            imported: result.success ? accessPoints.length : 0,
            id: result.id || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to import whitelist data',
            details: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Import geolocation data for access points
app.post('/api/admin/import-geolocations', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const { geolocations, metadata } = req.body;
        
        if (!geolocations || !Array.isArray(geolocations)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid data format. Expected geolocations array.',
                timestamp: new Date().toISOString()
            });
        }

        // Validate geolocation data structure
        const validationErrors = [];
        geolocations.forEach((geo, index) => {
            if (!geo.macAddress || !geo.latitude || !geo.longitude) {
                validationErrors.push(`Location ${index}: Missing required fields (macAddress, latitude, longitude)`);
            }
            if (typeof geo.latitude !== 'number' || geo.latitude < -90 || geo.latitude > 90) {
                validationErrors.push(`Location ${index}: Invalid latitude value`);
            }
            if (typeof geo.longitude !== 'number' || geo.longitude < -180 || geo.longitude > 180) {
                validationErrors.push(`Location ${index}: Invalid longitude value`);
            }
        });

        if (validationErrors.length > 0) {
            return res.status(400).json({
                success: false,
                error: 'Data validation failed',
                details: validationErrors,
                timestamp: new Date().toISOString()
            });
        }

        const result = await firebaseService.importGeolocationData({
            geolocations,
            metadata: metadata || {
                version: '1.0.0',
                importedAt: new Date().toISOString(),
                source: 'manual_import'
            }
        });
        
        res.json({
            success: result.success,
            message: result.success ? 'Geolocation data imported successfully' : 'Failed to import geolocation data',
            imported: result.success ? geolocations.length : 0,
            id: result.id || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to import geolocation data',
            details: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Bulk import endpoint for both whitelist and geolocation data
app.post('/api/admin/import-access-points', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const { accessPoints, options } = req.body;
        
        if (!accessPoints || !Array.isArray(accessPoints)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid data format. Expected accessPoints array.',
                timestamp: new Date().toISOString()
            });
        }

        const results = await firebaseService.bulkImportAccessPoints(accessPoints, options);
        
        res.json({
            success: results.success,
            message: results.success ? 'Access points imported successfully' : 'Import completed with errors',
            summary: results.summary,
            errors: results.errors || [],
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to import access points',
            details: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Get whitelist data
app.get('/api/whitelist', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const result = await firebaseService.getWhitelistData();
        
        res.json({
            success: result.success,
            data: result.data || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve whitelist data',
            timestamp: new Date().toISOString()
        });
    }
});

// Get geolocation data for access points
app.get('/api/geolocations', async (req, res) => {
    try {
        const { macAddress, bounds } = req.query;
        
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        let result;
        if (macAddress) {
            result = await firebaseService.getAccessPointLocation(macAddress);
        } else if (bounds) {
            // bounds should be: "lat1,lng1,lat2,lng2"
            const [lat1, lng1, lat2, lng2] = bounds.split(',').map(Number);
            result = await firebaseService.getAccessPointsInBounds(lat1, lng1, lat2, lng2);
        } else {
            result = await firebaseService.getAllGeolocations();
        }
        
        res.json({
            success: result.success,
            data: result.data || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve geolocation data',
            timestamp: new Date().toISOString()
        });
    }
});

// Data migration endpoint
app.post('/api/admin/migrate-data', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const existingData = {
            networkScanData: networkScanData,
            threatReports: threatReports,
            safetyTipsData: safetyTipsData
        };

        const result = await firebaseService.migrateExistingData(existingData);
        
        res.json({
            success: result.success,
            data: result.results || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to migrate data',
            details: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Update threat report status
app.patch('/api/mobile/threat-reports/:id/status', async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const result = await firebaseService.updateThreatReportStatus(id, status);
        
        if (result.success) {
            // Broadcast update to clients
            io.emit('threatReportStatusUpdate', { id, status });
        }

        res.json({
            success: result.success,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to update threat report status',
            timestamp: new Date().toISOString()
        });
    }
});

// Analytics endpoint
app.post('/api/analytics/event', async (req, res) => {
    try {
        if (!firebaseInitialized) {
            return res.status(503).json({
                success: false,
                error: 'Firebase not initialized',
                timestamp: new Date().toISOString()
            });
        }

        const eventData = req.body;
        const result = await firebaseService.saveAnalyticsEvent(eventData);
        
        res.json({
            success: result.success,
            id: result.id || null,
            error: result.error || null,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to save analytics event',
            timestamp: new Date().toISOString()
        });
    }
});

// WebSocket connection handling
io.on('connection', (socket) => {
    console.log('Dashboard client connected:', socket.id);
    
    // Send current data to newly connected client
    const sendInitialData = async () => {
        try {
            if (firebaseInitialized) {
                // Send Firebase data
                const scanResult = await firebaseService.getLatestNetworkScanData(1);
                const threatResult = await firebaseService.getThreatReports(10);
                
                socket.emit('scanDataUpdate', {
                    data: scanResult.success && scanResult.data.length > 0 ? scanResult.data[0] : networkScanData,
                    source: 'firebase'
                });
                
                socket.emit('threatReportsUpdate', {
                    reports: threatResult.success ? threatResult.data : threatReports.slice(0, 10),
                    total: threatResult.success ? threatResult.data.length : threatReports.length,
                    source: 'firebase'
                });
            } else {
                // Send in-memory data
                socket.emit('scanDataUpdate', { data: networkScanData, source: 'memory' });
                socket.emit('threatReportsUpdate', {
                    reports: threatReports.slice(0, 10),
                    total: threatReports.length,
                    source: 'memory'
                });
            }
        } catch (error) {
            console.error('Error sending initial data:', error);
            // Fallback to in-memory data
            socket.emit('scanDataUpdate', { data: networkScanData, source: 'memory' });
            socket.emit('threatReportsUpdate', {
                reports: threatReports.slice(0, 10),
                total: threatReports.length,
                source: 'memory'
            });
        }
    };
    
    sendInitialData();
    
    socket.on('disconnect', () => {
        console.log('Dashboard client disconnected:', socket.id);
    });
    
    // Handle dashboard requests
    socket.on('requestScanUpdate', async () => {
        try {
            if (firebaseInitialized) {
                const result = await firebaseService.getLatestNetworkScanData(1);
                socket.emit('scanDataUpdate', {
                    data: result.success && result.data.length > 0 ? result.data[0] : networkScanData,
                    source: 'firebase'
                });
            } else {
                socket.emit('scanDataUpdate', { data: networkScanData, source: 'memory' });
            }
        } catch (error) {
            socket.emit('scanDataUpdate', { data: networkScanData, source: 'memory' });
        }
    });
    
    socket.on('requestThreatReports', async (data) => {
        try {
            const limit = data?.limit || 10;
            if (firebaseInitialized) {
                const result = await firebaseService.getThreatReports(limit);
                socket.emit('threatReportsUpdate', {
                    reports: result.success ? result.data : threatReports.slice(0, limit),
                    total: result.success ? result.data.length : threatReports.length,
                    source: 'firebase'
                });
            } else {
                socket.emit('threatReportsUpdate', {
                    reports: threatReports.slice(0, limit),
                    total: threatReports.length,
                    source: 'memory'
                });
            }
        } catch (error) {
            const limit = data?.limit || 10;
            socket.emit('threatReportsUpdate', {
                reports: threatReports.slice(0, limit),
                total: threatReports.length,
                source: 'memory'
            });
        }
    });
    
    // Handle Firebase real-time subscription requests
    socket.on('subscribeToUpdates', () => {
        if (firebaseInitialized) {
            console.log(`Client ${socket.id} subscribed to real-time updates`);
            socket.emit('subscriptionConfirmed', { status: 'subscribed', source: 'firebase' });
        } else {
            socket.emit('subscriptionConfirmed', { status: 'unavailable', source: 'memory' });
        }
    });
});

// Get API health status
app.get('/api/health', async (req, res) => {
    try {
        let firebaseStatus = 'disabled';
        let firebaseHealth = null;

        if (firebaseInitialized) {
            const health = await firebaseService.healthCheck();
            firebaseStatus = health.success ? 'healthy' : 'unhealthy';
            firebaseHealth = health;
        }

        res.json({
            success: true,
            status: 'healthy',
            service: 'DisCon-X API',
            version: '1.0.0',
            timestamp: new Date().toISOString(),
            integrations: {
                websocket: 'enabled',
                mobileSync: 'active',
                firebase: firebaseStatus
            },
            firebase: firebaseHealth,
            endpoints: {
                'GET /api/safety-tips': 'Get all safety tips',
                'GET /api/safety-tips/:id': 'Get specific safety tip',
                'GET /api/safety-tips/category/:category': 'Get tips by category',
                'GET /api/safety-tips/priority/:priority': 'Get tips by priority',
                'POST /api/mobile/scan-data': 'Submit scan data from mobile',
                'GET /api/mobile/scan-data': 'Get current scan data',
                'POST /api/mobile/threat-report': 'Submit threat report',
                'GET /api/mobile/threat-reports': 'Get threat reports',
                'PATCH /api/mobile/threat-reports/:id/status': 'Update threat report status',
                'GET /api/mobile/config': 'Get mobile app configuration',
                'POST /api/admin/migrate-data': 'Migrate existing data to Firebase',
                'POST /api/analytics/event': 'Save analytics event'
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            status: 'unhealthy',
            service: 'DisCon-X API',
            error: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Serve index.html for all other routes (for SPA)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

server.listen(port, () => {
    console.log(`🚀 DisCon-X Server running at http://localhost:${port}`);
    console.log(`📱 Mobile API available at http://localhost:${port}/api/mobile/`);
    console.log(`🔗 WebSocket server enabled for real-time updates`);
    console.log(`🏥 Health check: http://localhost:${port}/api/health`);
}); 
// WebSocket Manager for Real-time Data Synchronization
// Provides robust WebSocket connection management with auto-reconnect and event handling

class WebSocketManager {
    constructor(url = null) {
        this.url = url || this.getWebSocketUrl();
        this.socket = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.listeners = new Map();
        this.isConnected = false;
        this.connectionId = null;
        this.heartbeatInterval = null;
        this.messageQueue = [];
        this.stats = {
            messagesReceived: 0,
            messagesSent: 0,
            connectionTime: null,
            lastActivity: null,
            errors: 0
        };
    }

    getWebSocketUrl() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        return `${protocol}//${host}`;
    }

    connect() {
        return new Promise((resolve, reject) => {
            try {
                if (this.socket && this.socket.readyState === WebSocket.OPEN) {
                    resolve();
                    return;
                }

                this.socket = new WebSocket(this.url);
                
                this.socket.onopen = () => {
                    console.log('✅ WebSocket connected');
                    this.isConnected = true;
                    this.connectionId = this.generateConnectionId();
                    this.stats.connectionTime = new Date();
                    this.reconnectAttempts = 0;
                    this.startHeartbeat();
                    this.flushMessageQueue();
                    this.emit('connected', { connectionId: this.connectionId });
                    resolve();
                };

                this.socket.onmessage = (event) => {
                    try {
                        const data = JSON.parse(event.data);
                        this.stats.messagesReceived++;
                        this.stats.lastActivity = new Date();
                        this.handleMessage(data);
                    } catch (error) {
                        console.error('Error parsing WebSocket message:', error);
                        this.stats.errors++;
                    }
                };

                this.socket.onerror = (error) => {
                    console.error('❌ WebSocket error:', error);
                    this.stats.errors++;
                    this.emit('error', error);
                    reject(error);
                };

                this.socket.onclose = (event) => {
                    console.log('🔌 WebSocket disconnected');
                    this.isConnected = false;
                    this.stopHeartbeat();
                    this.emit('disconnected', { code: event.code, reason: event.reason });
                    
                    if (!event.wasClean && this.reconnectAttempts < this.maxReconnectAttempts) {
                        this.reconnect();
                    }
                };
            } catch (error) {
                console.error('Failed to create WebSocket connection:', error);
                reject(error);
            }
        });
    }

    reconnect() {
        this.reconnectAttempts++;
        const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1), 30000);
        
        console.log(`Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
        this.emit('reconnecting', { attempt: this.reconnectAttempts, delay });
        
        setTimeout(() => {
            this.connect().catch(error => {
                console.error('Reconnection failed:', error);
            });
        }, delay);
    }

    disconnect() {
        this.stopHeartbeat();
        if (this.socket) {
            this.socket.close(1000, 'Client disconnect');
            this.socket = null;
        }
        this.isConnected = false;
        this.messageQueue = [];
    }

    send(type, data) {
        const message = {
            type,
            data,
            timestamp: new Date().toISOString(),
            connectionId: this.connectionId
        };

        if (this.isConnected && this.socket.readyState === WebSocket.OPEN) {
            try {
                this.socket.send(JSON.stringify(message));
                this.stats.messagesSent++;
                this.stats.lastActivity = new Date();
                return true;
            } catch (error) {
                console.error('Failed to send message:', error);
                this.messageQueue.push(message);
                return false;
            }
        } else {
            this.messageQueue.push(message);
            return false;
        }
    }

    on(event, callback) {
        if (!this.listeners.has(event)) {
            this.listeners.set(event, []);
        }
        this.listeners.get(event).push(callback);
        return () => this.off(event, callback);
    }

    off(event, callback) {
        const callbacks = this.listeners.get(event);
        if (callbacks) {
            const index = callbacks.indexOf(callback);
            if (index > -1) {
                callbacks.splice(index, 1);
            }
        }
    }

    emit(event, data) {
        const callbacks = this.listeners.get(event);
        if (callbacks) {
            callbacks.forEach(callback => {
                try {
                    callback(data);
                } catch (error) {
                    console.error(`Error in event listener for ${event}:`, error);
                }
            });
        }
    }

    handleMessage(message) {
        // Handle system messages
        switch (message.type) {
            case 'ping':
                this.send('pong', { timestamp: Date.now() });
                break;
            case 'scanDataUpdate':
                this.emit('scanDataUpdate', message.data);
                break;
            case 'threatReportUpdate':
                this.emit('threatReportUpdate', message.data);
                break;
            case 'threatReportsUpdate':
                this.emit('threatReportsUpdate', message.data);
                break;
            case 'systemStatus':
                this.emit('systemStatus', message.data);
                break;
            case 'notification':
                this.emit('notification', message.data);
                break;
            default:
                this.emit(message.type, message.data);
        }
    }

    startHeartbeat() {
        this.stopHeartbeat();
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected) {
                this.send('heartbeat', { timestamp: Date.now() });
            }
        }, 30000);
    }

    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }

    flushMessageQueue() {
        while (this.messageQueue.length > 0 && this.isConnected) {
            const message = this.messageQueue.shift();
            this.socket.send(JSON.stringify(message));
            this.stats.messagesSent++;
        }
    }

    generateConnectionId() {
        return `conn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    getStats() {
        return {
            ...this.stats,
            isConnected: this.isConnected,
            connectionId: this.connectionId,
            queuedMessages: this.messageQueue.length,
            uptime: this.stats.connectionTime ? Date.now() - this.stats.connectionTime : 0
        };
    }

    // Subscribe to specific data streams
    subscribe(channel, options = {}) {
        return this.send('subscribe', { channel, options });
    }

    unsubscribe(channel) {
        return this.send('unsubscribe', { channel });
    }
}

// Create singleton instance
const wsManager = new WebSocketManager();

// Auto-connect when module loads
if (typeof window !== 'undefined') {
    window.addEventListener('load', () => {
        wsManager.connect().catch(error => {
            console.error('Initial WebSocket connection failed:', error);
        });
    });

    // Handle page visibility changes
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            wsManager.stopHeartbeat();
        } else if (wsManager.isConnected) {
            wsManager.startHeartbeat();
        }
    });

    // Cleanup on page unload
    window.addEventListener('beforeunload', () => {
        wsManager.disconnect();
    });
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = wsManager;
} else {
    window.wsManager = wsManager;
}

export default wsManager;


const admin = require('firebase-admin');
require('dotenv').config();

class FirebaseService {
    constructor() {
        this.db = null;
        this.storage = null;
        this.initialized = false;
    }

    /**
     * Initialize Firebase Admin SDK
     */
    async initialize() {
        if (this.initialized) {
            return;
        }

        try {
            // Initialize Firebase Admin SDK
            const serviceAccount = {
                type: "service_account",
                project_id: process.env.FIREBASE_PROJECT_ID,
                private_key: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
                client_email: process.env.FIREBASE_CLIENT_EMAIL,
            };

            admin.initializeApp({
                credential: admin.credential.cert(serviceAccount),
                databaseURL: process.env.FIREBASE_DATABASE_URL,
                storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
            });

            this.db = admin.firestore();
            // Storage is optional - only initialize if available
            try {
                this.storage = admin.storage();
            } catch (error) {
                console.log('ℹ️  Firebase Storage not available (requires Blaze plan)');
                this.storage = null;
            }
            
            // Enable offline persistence settings
            const settings = {
                ignoreUndefinedProperties: true,
            };
            this.db.settings(settings);

            this.initialized = true;
            console.log('✅ Firebase service initialized successfully');
        } catch (error) {
            console.error('❌ Firebase initialization error:', error);
            throw error;
        }
    }

    /**
     * Network Scan Data Operations
     */
    async saveNetworkScanData(scanData) {
        try {
            const docRef = await this.db.collection('network_scans').add({
                ...scanData,
                timestamp: admin.firestore.FieldValue.serverTimestamp(),
                createdAt: new Date().toISOString(),
            });
            return { success: true, id: docRef.id };
        } catch (error) {
            console.error('Error saving network scan data:', error);
            return { success: false, error: error.message };
        }
    }

    async getLatestNetworkScanData(limit = 1) {
        try {
            const snapshot = await this.db
                .collection('network_scans')
                .orderBy('timestamp', 'desc')
                .limit(limit)
                .get();

            const scans = [];
            snapshot.forEach(doc => {
                scans.push({ id: doc.id, ...doc.data() });
            });

            return { success: true, data: scans };
        } catch (error) {
            console.error('Error getting network scan data:', error);
            return { success: false, error: error.message };
        }
    }

    async getNetworkScansByDevice(deviceId, limit = 50) {
        try {
            const snapshot = await this.db
                .collection('network_scans')
                .where('deviceId', '==', deviceId)
                .orderBy('timestamp', 'desc')
                .limit(limit)
                .get();

            const scans = [];
            snapshot.forEach(doc => {
                scans.push({ id: doc.id, ...doc.data() });
            });

            return { success: true, data: scans };
        } catch (error) {
            console.error('Error getting network scans by device:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Threat Reports Operations
     */
    async saveThreatReport(reportData) {
        try {
            const docRef = await this.db.collection('threat_reports').add({
                ...reportData,
                timestamp: admin.firestore.FieldValue.serverTimestamp(),
                createdAt: new Date().toISOString(),
            });
            return { success: true, id: docRef.id };
        } catch (error) {
            console.error('Error saving threat report:', error);
            return { success: false, error: error.message };
        }
    }

    async getThreatReports(limit = 50, status = 'all') {
        try {
            let query = this.db
                .collection('threat_reports')
                .orderBy('timestamp', 'desc')
                .limit(limit);

            if (status !== 'all') {
                query = query.where('status', '==', status);
            }

            const snapshot = await query.get();
            const reports = [];
            snapshot.forEach(doc => {
                reports.push({ id: doc.id, ...doc.data() });
            });

            return { success: true, data: reports };
        } catch (error) {
            console.error('Error getting threat reports:', error);
            return { success: false, error: error.message };
        }
    }

    async updateThreatReportStatus(reportId, status) {
        try {
            await this.db.collection('threat_reports').doc(reportId).update({
                status: status,
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            });
            return { success: true };
        } catch (error) {
            console.error('Error updating threat report status:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Safety Tips Operations
     */
    async importSafetyTips(tipsData) {
        try {
            const batch = this.db.batch();
            
            // Save metadata
            const metadataRef = this.db.collection('safety_tips_metadata').doc('current');
            batch.set(metadataRef, {
                ...tipsData.metadata,
                importedAt: admin.firestore.FieldValue.serverTimestamp(),
            });

            // Save individual tips
            tipsData.tips.forEach(tip => {
                const tipRef = this.db.collection('safety_tips').doc(tip.id.toString());
                batch.set(tipRef, {
                    ...tip,
                    importedAt: admin.firestore.FieldValue.serverTimestamp(),
                });
            });

            await batch.commit();
            return { success: true, message: 'Safety tips imported successfully' };
        } catch (error) {
            console.error('Error importing safety tips:', error);
            return { success: false, error: error.message };
        }
    }

    async getSafetyTips(category = null, priority = null) {
        try {
            let query = this.db.collection('safety_tips');

            if (category) {
                query = query.where('category', '==', category);
            }
            if (priority) {
                query = query.where('priority', '==', priority);
            }

            const snapshot = await query.get();
            const tips = [];
            snapshot.forEach(doc => {
                tips.push({ id: doc.id, ...doc.data() });
            });

            return { success: true, data: tips };
        } catch (error) {
            console.error('Error getting safety tips:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Analytics Operations
     */
    async saveAnalyticsEvent(eventData) {
        try {
            const docRef = await this.db.collection('analytics').add({
                ...eventData,
                timestamp: admin.firestore.FieldValue.serverTimestamp(),
                createdAt: new Date().toISOString(),
            });
            return { success: true, id: docRef.id };
        } catch (error) {
            console.error('Error saving analytics event:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Configuration Operations
     */
    async getAppConfiguration() {
        try {
            const doc = await this.db.collection('config').doc('mobile_app').get();
            if (doc.exists) {
                return { success: true, data: doc.data() };
            } else {
                return { success: false, error: 'Configuration not found' };
            }
        } catch (error) {
            console.error('Error getting app configuration:', error);
            return { success: false, error: error.message };
        }
    }

    async updateAppConfiguration(configData) {
        try {
            await this.db.collection('config').doc('mobile_app').set({
                ...configData,
                updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            }, { merge: true });
            return { success: true };
        } catch (error) {
            console.error('Error updating app configuration:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Whitelist Operations
     */
    async importWhitelist(whitelistData) {
        try {
            const batch = this.db.batch();
            
            // Save metadata
            const metadataRef = this.db.collection('whitelists').doc('current');
            batch.set(metadataRef, {
                version: whitelistData.version,
                lastUpdated: admin.firestore.FieldValue.serverTimestamp(),
                checksum: whitelistData.checksum,
                accessPointsCount: whitelistData.accessPoints.length,
            });

            // Save to Firestore (for metadata and small lists)
            const whitelistRef = this.db.collection('whitelist_data').doc('current');
            batch.set(whitelistRef, {
                accessPoints: whitelistData.accessPoints,
                importedAt: admin.firestore.FieldValue.serverTimestamp(),
            });

            await batch.commit();

            // Also save to Storage for larger files (if Storage is available)
            if (this.storage) {
                try {
                    const bucket = this.storage.bucket();
                    const file = bucket.file('whitelists/current/whitelist_latest.json');
                    await file.save(JSON.stringify(whitelistData), {
                        metadata: {
                            contentType: 'application/json',
                        },
                    });
                } catch (error) {
                    console.log('ℹ️  Storage not available, whitelist saved to Firestore only');
                }
            }

            return { success: true, message: 'Whitelist imported successfully' };
        } catch (error) {
            console.error('Error importing whitelist:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Real-time subscriptions for dashboard
     */
    subscribeToNetworkScans(callback) {
        return this.db
            .collection('network_scans')
            .orderBy('timestamp', 'desc')
            .limit(10)
            .onSnapshot(callback, error => {
                console.error('Network scans subscription error:', error);
            });
    }

    subscribeToThreatReports(callback) {
        return this.db
            .collection('threat_reports')
            .orderBy('timestamp', 'desc')
            .limit(20)
            .onSnapshot(callback, error => {
                console.error('Threat reports subscription error:', error);
            });
    }

    /**
     * Data migration utilities
     */
    async migrateExistingData(existingData) {
        try {
            const results = {
                networkScans: 0,
                threatReports: 0,
                safetyTips: 0,
                errors: []
            };

            // Migrate network scan data
            if (existingData.networkScanData && existingData.networkScanData.networks) {
                const scanResult = await this.saveNetworkScanData(existingData.networkScanData);
                if (scanResult.success) results.networkScans++;
                else results.errors.push(`Network scan: ${scanResult.error}`);
            }

            // Migrate threat reports
            if (existingData.threatReports && Array.isArray(existingData.threatReports)) {
                for (const report of existingData.threatReports) {
                    const reportResult = await this.saveThreatReport(report);
                    if (reportResult.success) results.threatReports++;
                    else results.errors.push(`Threat report ${report.id}: ${reportResult.error}`);
                }
            }

            // Migrate safety tips
            if (existingData.safetyTipsData) {
                const tipsResult = await this.importSafetyTips(existingData.safetyTipsData);
                if (tipsResult.success) results.safetyTips = existingData.safetyTipsData.tips.length;
                else results.errors.push(`Safety tips: ${tipsResult.error}`);
            }

            return { success: true, results };
        } catch (error) {
            console.error('Data migration error:', error);
            return { success: false, error: error.message };
        }
    }

    /**
     * Health check
     */
    async healthCheck() {
        try {
            // Simple read operation to test connectivity
            await this.db.collection('config').doc('health_check').set({
                timestamp: admin.firestore.FieldValue.serverTimestamp(),
                status: 'healthy'
            });
            return { success: true, status: 'healthy' };
        } catch (error) {
            console.error('Firebase health check failed:', error);
            return { success: false, status: 'unhealthy', error: error.message };
        }
    }
}

module.exports = new FirebaseService();

// AnalyticsReports.js - Modern Analytics & Reports Dashboard for DICT WiFi

function renderAnalyticsReports(containerId) {
  const container = document.getElementById(containerId);
  if (!container) {
    console.error(`Container with ID ${containerId} not found`);
    return;
  }

  // Add styles if not already present
  if (!document.getElementById('analytics-reports-styles')) {
    const style = document.createElement('style');
    style.id = 'analytics-reports-styles';
    style.innerHTML = `
      .analytics-reports-container {
        background: #fff;
        border-radius: 16px;
        box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
        overflow: hidden;
      }
      .analytics-header {
        background: var(--header-gradient);
        color: white !important;
        padding: 32px 40px;
        margin: 0;
        border-bottom: 3px solid #1d4ed8;
        flex-shrink: 0;
        position: relative;
        overflow: hidden;
      }
      .analytics-header::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 50%;
        height: 100%;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
        opacity: 0.3;
        pointer-events: none;
      }
      .analytics-header-content {
        position: relative;
        z-index: 1;
      }
      .analytics-title {
        font-size: 2.5rem;
        font-weight: 800;
        margin: 0 0 12px 0;
        display: flex;
        align-items: center;
        gap: 16px;
        color: white !important;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        letter-spacing: -0.025em;
        position: relative;
        z-index: 1;
      }
      .analytics-title svg {
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
      }
      .analytics-subtitle {
        font-size: 15px;
        color: rgba(255, 255, 255, 0.9) !important;
        margin: 0 0 20px 0;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
      }
      .analytics-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        padding: 32px;
        background: #f8fafc;
      }
      .analytics-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        padding: 20px 18px 18px 18px;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 8px;
        border: 1px solid #e2e8f0;
        transition: box-shadow 0.2s, border 0.2s;
      }
      .analytics-card:hover {
        box-shadow: 0 8px 25px -5px rgba(30,41,59,0.12), 0 4px 10px -2px rgba(30,41,59,0.08);
        border-color: #1e293b;
      }
      .analytics-card-title {
        font-size: 14px;
        color: #64748b;
        font-weight: 600;
      }
      .analytics-card-value {
        font-size: 2rem;
        font-weight: 700;
        color: #1e293b;
      }
      .analytics-card-trend {
        font-size: 13px;
        font-weight: 500;
        color: #10b981;
      }
      .analytics-charts {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 32px;
        padding: 32px;
      }
      .regional-stats-card {
        background: white;
        border-radius: 12px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        padding: 24px 18px 18px 18px;
        display: flex;
        flex-direction: column;
        gap: 12px;
      }
      .regional-stats-title { font-size: 16px; font-weight: 600; color: #374151; margin-bottom: 8px; }
      .regional-table { width: 100%; border-collapse: collapse; }
      .regional-table th, .regional-table td { padding: 10px 12px; border-bottom: 1px solid #f1f5f9; text-align: left; font-size: 14px; }
      .regional-table th { color: #6b7280; font-weight: 600; text-transform: uppercase; font-size: 12px; letter-spacing: .5px; }
      .analytics-chart-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        padding: 24px 18px 18px 18px;
        border: 1px solid #e2e8f0;
        display: flex;
        flex-direction: column;
        gap: 12px;
        height: 350px;
        max-height: 350px;
        overflow: hidden;
      }
      .analytics-chart-title {
        font-size: 16px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
      }
      @media (max-width: 900px) {
        .analytics-charts {
          grid-template-columns: 1fr;
        }
      }
      @media (max-width: 600px) {
        .analytics-cards, .analytics-charts {
          padding: 16px;
        }
      }
    `;
    document.head.appendChild(style);
  }

  container.innerHTML = `
    <div class="analytics-reports-container">
      <div class="analytics-header">
        <div class="analytics-header-content">
          <h1 class="analytics-title">
            <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2a4 4 0 014-4h2a4 4 0 014 4v2M7 17v-2a4 4 0 00-4-4H3a4 4 0 00-4 4v2"/>
            </svg>
            Analytics & Reports
          </h1>
          <p class="analytics-subtitle">Comprehensive analytics and reports for your Wi-Fi network monitoring</p>
        </div>
      </div>
      <div class="analytics-cards">
        <div class="analytics-card">
          <div class="analytics-card-title">Total Networks</div>
          <div class="analytics-card-value">1,254</div>
          <div class="analytics-card-trend">+8.2% from last month</div>
        </div>
        <div class="analytics-card">
          <div class="analytics-card-title">Verified Networks</div>
          <div class="analytics-card-value">987</div>
          <div class="analytics-card-trend" style="color:#10b981;">+12.5% verified</div>
        </div>
        <div class="analytics-card">
          <div class="analytics-card-title">Suspicious Networks</div>
          <div class="analytics-card-value" style="color:#ef4444;">37</div>
          <div class="analytics-card-trend" style="color:#ef4444;">+4.8% threats</div>
        </div>
        <div class="analytics-card">
          <div class="analytics-card-title">Active Users</div>
          <div class="analytics-card-value">13,542</div>
          <div class="analytics-card-trend">+18.3% last 30 days</div>
        </div>
      </div>
      <div class="analytics-charts">
        <div class="analytics-chart-card">
          <div class="analytics-chart-title" style="display: flex; justify-content: space-between; align-items: center;">
            Detection Trends
            <div class="select-container" style="position: relative;">
              <select class="trends-select" id="analyticsTrendsSelect" name="analyticsTrendsSelect" style="
                padding: 6px 12px;
                border: 1px solid #e2e8f0;
                border-radius: 6px;
                background: white;
                color: #374151;
                font-size: 12px;
                font-weight: 500;
                cursor: pointer;
                outline: none;
              ">
                <option>Last 7 Days</option>
                <option>Last 30 Days</option>
                <option>Last 90 Days</option>
              </select>
            </div>
          </div>
          <canvas id="analyticsDetectionTrends" height="200" style="max-height: 200px;"></canvas>
        </div>
        <div class="analytics-chart-card">
          <div class="analytics-chart-title">Regional Coverage</div>
          <canvas id="analyticsRegionalCoverage" height="200" style="max-height: 200px;"></canvas>
        </div>
      </div>
      <div class="regional-stats-card">
        <div class="regional-stats-title">CALABARZON Regional Statistics</div>
        <table class="regional-table">
          <thead>
            <tr><th>Province</th><th>Networks</th><th>Verified</th><th>Suspicious</th><th>Coverage</th></tr>
          </thead>
          <tbody>
            <tr><td>Cavite</td><td>287</td><td>231</td><td>28</td><td>76%</td></tr>
            <tr><td>Laguna</td><td>342</td><td>298</td><td>12</td><td>82%</td></tr>
            <tr><td>Batangas</td><td>215</td><td>187</td><td>8</td><td>68%</td></tr>
            <tr><td>Rizal</td><td>263</td><td>209</td><td>9</td><td>73%</td></tr>
            <tr><td>Quezon</td><td>147</td><td>62</td><td>3</td><td>42%</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Render sample charts using Chart.js
  if (window.Chart) {
    // Initialize Detection Trends with default timeframe
    setTimeout(() => {
      renderAnalyticsTrendsChart('Last 7 Days');
    }, 100);
    // Regional Coverage
    new Chart(document.getElementById('analyticsRegionalCoverage').getContext('2d'), {
      type: 'bar',
      data: {
        labels: ['Cavite', 'Laguna', 'Batangas', 'Rizal', 'Quezon'],
        datasets: [{
          label: 'Coverage %',
          data: [76, 82, 68, 73, 42],
          backgroundColor: [
            '#0ea5e9', '#6366f1', '#f59e0b', '#8b5cf6', '#ec4899'
          ]
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, max: 100 } }
      }
    });
  }
}

// Generate dynamic data for analytics trends based on timeframe
function generateAnalyticsTrendData(timeframe) {
  const now = new Date();
  let labels = [];
  let dataPoints = 0;
  
  switch(timeframe) {
    case 'Last 30 Days':
      dataPoints = 30;
      for (let i = dataPoints - 1; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
      }
      break;
    case 'Last 90 Days':
      dataPoints = 90;
      for (let i = dataPoints - 1; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
      }
      break;
    default: // Last 7 Days
      dataPoints = 7;
      for (let i = dataPoints - 1; i >= 0; i--) {
        const date = new Date(now);
        date.setDate(date.getDate() - i);
        labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
      }
  }

  // Generate realistic-looking data with trends
  const generateDataset = (baseValue, variance, trend) => {
    return Array.from({ length: dataPoints }, (_, i) => {
      const randomFactor = Math.random() * variance;
      const trendFactor = (i / dataPoints) * trend;
      return Math.round(baseValue + randomFactor + trendFactor);
    });
  };

  return {
    labels,
    datasets: [
      {
        label: 'Verified Networks',
        data: generateDataset(65, 15, 10),
        borderColor: '#1e293b',
        backgroundColor: 'rgba(30, 41, 59, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 3,
        pointHoverRadius: 5
      },
      {
        label: 'Pending Verification',
        data: generateDataset(28, 20, -5),
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 3,
        pointHoverRadius: 5
      },
      {
        label: 'Suspicious Activities',
        data: generateDataset(12, 8, 2),
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true,
        pointRadius: 3,
        pointHoverRadius: 5
      }
    ]
  };
}

// Store the analytics chart instance
let analyticsChart = null;

// Function to render analytics trends chart with timeframe
function renderAnalyticsTrendsChart(timeframe = 'Last 7 Days') {
  const ctx = document.getElementById('analyticsDetectionTrends');
  if (!ctx) return;

  // Destroy existing chart if it exists
  if (analyticsChart) {
    analyticsChart.destroy();
  }

  const data = generateAnalyticsTrendData(timeframe);

  analyticsChart = new Chart(ctx.getContext('2d'), {
    type: 'line',
    data: data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: {
        padding: {
          right: 20,
          bottom: 10
        }
      },
      interaction: {
        intersect: false,
        mode: 'index'
      },
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          align: 'start',
          labels: {
            usePointStyle: false,
            boxWidth: 40,
            boxHeight: 2,
            padding: 20,
            color: '#64748b',
            font: {
              size: 12
            }
          }
        },
        tooltip: {
          backgroundColor: 'rgba(255, 255, 255, 0.9)',
          titleColor: '#1e293b',
          bodyColor: '#475569',
          borderColor: '#e2e8f0',
          borderWidth: 1,
          padding: 10,
          boxPadding: 4,
          usePointStyle: true,
          titleFont: { size: 12 },
          bodyFont: { size: 12 },
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: ${context.parsed.y} networks`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            display: false
          },
          ticks: {
            color: '#64748b',
            maxRotation: 45,
            minRotation: 45,
            font: { size: 12 }
          }
        },
        y: {
          beginAtZero: true,
          grid: {
            color: '#e2e8f0'
          },
          ticks: {
            color: '#64748b',
            font: { size: 12 },
            callback: function(value) {
              return value;
            }
          }
        }
      },
      animation: {
        duration: 1000,
        easing: 'easeInOutQuart'
      },
      elements: {
        point: {
          radius: 2,
          hoverRadius: 4
        }
      }
    }
  });

  // Add event listener to the timeframe selector
  const analyticsTrendsSelect = document.getElementById('analyticsTrendsSelect');
  if (analyticsTrendsSelect && !analyticsTrendsSelect.hasEventListener) {
    analyticsTrendsSelect.addEventListener('change', (e) => {
      renderAnalyticsTrendsChart(e.target.value);
    });
    analyticsTrendsSelect.hasEventListener = true;
  }
}

window.renderAnalyticsReports = renderAnalyticsReports;
window.renderAnalyticsTrendsChart = renderAnalyticsTrendsChart;
// To use: call renderAnalyticsReports('analytics-reports-container') 
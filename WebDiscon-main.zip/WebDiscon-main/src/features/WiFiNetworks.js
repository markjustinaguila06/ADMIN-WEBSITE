// WiFiNetworks.js - Enhanced Interactive Database-style Table Interface for Wi-Fi Networks Management
// Professional table layout with advanced filtering, sorting, pagination, and real-time interactions

console.log('Enhanced WiFiNetworks.js loading...');

// Global state for interactive features
let currentSortColumn = 'lastSeen';
let currentSortDirection = 'desc';
let currentFilters = {
    status: 'all',
    threatLevel: 'all',
    security: 'all',
    province: 'all'
};
let isTableInteractive = false;

// Simulated whitelist storage (in real app, this would be from a database/API)
let whitelistedNetworks = [
  { id: 1, bssid: '00:11:22:33:44:55', ssid: 'DICT WiFi - Batangas', addedDate: '2024-03-20', addedBy: 'Admin' },
  { id: 4, bssid: 'AA:BB:CC:DD:EE:FF', ssid: 'DICT WiFi - Cavite', addedDate: '2024-03-21', addedBy: 'Admin' }
];

// Utility function to remove duplicate networks based on BSSID
function removeDuplicateNetworks(networks) {
  const seen = new Set();
  return networks.filter(network => {
    if (seen.has(network.bssid)) {
      console.log(`Duplicate BSSID detected: ${network.bssid} for ${network.ssid} - removing duplicate`);
      return false;
    }
    seen.add(network.bssid);
    return true;
  });
}

// Raw network data (may contain duplicates)
const rawWifiNetworksData = [
  {
    id: 1,
    ssid: 'DICT WiFi - Batangas',
    bssid: '00:11:22:33:44:55',
    location: 'Batangas City',
    signal: -45,
    security: 'WPA2',
    encryption: 'AES',
    channel: 6,
    frequency: '2.4 GHz',
    status: 'Verified',
    threatLevel: 'Low',
    lastSeen: '2024-03-22 14:30:00',
    connectedDevices: 23,
    maxSpeed: '100 Mbps',
    coverage: 'Strong',
    manufacturer: 'Cisco',
    model: 'Aironet 1815',
    uptime: '99.8%',
    region: 'CALABARZON',
    province: 'Batangas',
    isWhitelisted: true
  },
  {
    id: 2,
    ssid: 'DICT WiFi - Lipa',
    bssid: '66:77:88:99:AA:BB',
    location: 'Lipa City',
    signal: -65,
    security: 'WPA2',
    encryption: 'AES',
    channel: 11,
    frequency: '2.4 GHz',
    status: 'Pending',
    threatLevel: 'Medium',
    lastSeen: '2024-03-22 14:25:00',
    connectedDevices: 15,
    maxSpeed: '100 Mbps',
    coverage: 'Medium',
    manufacturer: 'TP-Link',
    model: 'EAP225',
    uptime: '98.5%',
    region: 'CALABARZON',
    province: 'Batangas',
    isWhitelisted: false
  },
  {
    id: 3,
    ssid: 'DICT WiFi - Tanauan',
    bssid: 'CC:DD:EE:FF:00:11',
    location: 'Tanauan City',
    signal: -85,
    security: 'Open',
    encryption: 'None',
    channel: 1,
    frequency: '2.4 GHz',
    status: 'Suspicious',
    threatLevel: 'High',
    lastSeen: '2024-03-22 14:20:00',
    connectedDevices: 8,
    maxSpeed: '54 Mbps',
    coverage: 'Weak',
    manufacturer: 'Unknown',
    model: 'Unknown',
    uptime: '95.2%',
    region: 'CALABARZON',
    province: 'Batangas',
    isWhitelisted: false
  },
  {
    id: 4,
    ssid: 'DICT WiFi - Cavite',
    bssid: 'AA:BB:CC:DD:EE:FF',
    location: 'Cavite City',
    signal: -55,
    security: 'WPA3',
    encryption: 'AES-256',
    channel: 36,
    frequency: '5 GHz',
    status: 'Verified',
    threatLevel: 'Low',
    lastSeen: '2024-03-22 14:35:00',
    connectedDevices: 31,
    maxSpeed: '1 Gbps',
    coverage: 'Strong',
    manufacturer: 'Ubiquiti',
    model: 'UniFi AP-AC-Pro',
    uptime: '99.9%',
    region: 'CALABARZON',
    province: 'Cavite',
    isWhitelisted: true
  },
  {
    id: 5,
    ssid: 'DICT WiFi - Laguna',
    bssid: '11:22:33:44:55:66',
    location: 'San Pablo City',
    signal: -70,
    security: 'WPA2',
    encryption: 'AES',
    channel: 8,
    frequency: '2.4 GHz',
    status: 'Pending',
    threatLevel: 'Medium',
    lastSeen: '2024-03-22 14:28:00',
    connectedDevices: 12,
    maxSpeed: '100 Mbps',
    coverage: 'Medium',
    manufacturer: 'MikroTik',
    model: 'hAP ac²',
    uptime: '97.8%',
    region: 'CALABARZON',
    province: 'Laguna',
    isWhitelisted: false
  },
  {
    id: 6,
    ssid: 'DICT WiFi - Rizal',
    bssid: '22:33:44:55:66:77',
    location: 'Antipolo City',
    signal: -60,
    security: 'WPA2',
    encryption: 'AES',
    channel: 13,
    frequency: '2.4 GHz',
    status: 'Verified',
    threatLevel: 'Low',
    lastSeen: '2024-03-22 14:32:00',
    connectedDevices: 28,
    maxSpeed: '100 Mbps',
    coverage: 'Strong',
    manufacturer: 'Aruba',
    model: 'AP-315',
    uptime: '99.6%',
    region: 'CALABARZON',
    province: 'Rizal',
    isWhitelisted: false
  },
  {
    id: 7,
    ssid: 'DICT WiFi - Quezon',
    bssid: '33:44:55:66:77:88',
    location: 'Lucena City',
    signal: -75,
    security: 'WPA2',
    encryption: 'TKIP',
    channel: 3,
    frequency: '2.4 GHz',
    status: 'Pending',
    threatLevel: 'Medium',
    lastSeen: '2024-03-22 14:15:00',
    connectedDevices: 6,
    maxSpeed: '54 Mbps',
    coverage: 'Weak',
    manufacturer: 'D-Link',
    model: 'DAP-1360',
    uptime: '96.3%',
    region: 'CALABARZON',
    province: 'Quezon',
    isWhitelisted: false
  },
  {
    id: 8,
    ssid: 'DICT WiFi - Calamba',
    bssid: '44:55:66:77:88:99',
    location: 'Calamba City',
    signal: -50,
    security: 'WPA3',
    encryption: 'AES-256',
    channel: 40,
    frequency: '5 GHz',
    status: 'Verified',
    threatLevel: 'Low',
    lastSeen: '2024-03-22 14:40:00',
    connectedDevices: 42,
    maxSpeed: '1 Gbps',
    coverage: 'Strong',
    manufacturer: 'Cisco',
    model: 'Meraki MR46',
    uptime: '99.7%',
    region: 'CALABARZON',
    province: 'Laguna',
    isWhitelisted: false
  }
];

// Clean data - remove duplicates based on BSSID (MAC address)
const wifiNetworksData = removeDuplicateNetworks(rawWifiNetworksData);

console.log('WiFi networks data loaded:', wifiNetworksData.length, 'networks');

// Function to add new network with duplicate detection
function addNewNetwork(newNetwork) {
  // Check if BSSID already exists
  const existingNetwork = wifiNetworksData.find(network => network.bssid === newNetwork.bssid);
  
  if (existingNetwork) {
    console.warn(`Network with BSSID ${newNetwork.bssid} already exists. Updating existing entry.`);
    // Update existing network with newer information
    Object.assign(existingNetwork, {
      ...newNetwork,
      lastSeen: new Date().toISOString().slice(0, 19).replace('T', ' ')
    });
    return existingNetwork;
  } else {
    // Add new network
    const newId = Math.max(...wifiNetworksData.map(n => n.id)) + 1;
    const networkWithId = {
      ...newNetwork,
      id: newId,
      lastSeen: new Date().toISOString().slice(0, 19).replace('T', ' ')
    };
    wifiNetworksData.push(networkWithId);
    console.log(`Added new network: ${newNetwork.ssid} (${newNetwork.bssid})`);
    return networkWithId;
  }
}

// Function to validate network data integrity
function validateNetworkData() {
  const bssids = new Set();
  const duplicates = [];
  
  wifiNetworksData.forEach(network => {
    if (bssids.has(network.bssid)) {
      duplicates.push(network);
    } else {
      bssids.add(network.bssid);
    }
  });
  
  if (duplicates.length > 0) {
    console.warn('Found duplicate networks:', duplicates);
    return false;
  }
  
  console.log('Network data validation passed - no duplicates found');
  return true;
}

// Run validation on load
validateNetworkData();

let currentSort = { field: 'ssid', direction: 'asc' };
let currentFilter = { 
  status: 'all', 
  security: 'all', 
  threatLevel: 'all',
  province: 'all',
  frequency: 'all',
  whitelist: 'all'
};
let searchQuery = '';
let currentPage = 1;
let rowsPerPage = 10;
let isRendering = false;

function renderWiFiNetworks(containerId) {
  console.log('renderWiFiNetworks called with containerId:', containerId);
  
  if (isRendering) {
    console.log('Already rendering, skipping...');
    return;
  }
  
  try {
    isRendering = true;
    const container = document.getElementById(containerId);
    if (!container) {
      console.error(`Container with ID ${containerId} not found`);
      return;
    }

    console.log('Container found, rendering WiFi networks table...');

    // Add enhanced database-style table CSS
    if (!document.getElementById('wifi-networks-table-styles')) {
      const style = document.createElement('style');
      style.id = 'wifi-networks-table-styles';
      style.innerHTML = `
        .wifi-database-container {
          background: #f8fafc;
          border-radius: 0;
          box-shadow: none;
          overflow: hidden;
          margin: 0 !important;
          padding: 0 !important;
          height: 100vh;
          width: 100%;
          display: flex;
          flex-direction: column;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
          position: relative;
          left: 0;
          top: 0;
        }
        
        .networks {
          padding: 0 !important;
          margin: 0 !important;
          height: 100vh;
          overflow: hidden;
          position: relative;
          width: 100%;
        }
        
        .wifi-database-header {
          background: var(--header-gradient);
          color: white !important;
          padding: 32px 40px;
          margin: 0;
          border-bottom: 3px solid #1d4ed8;
          flex-shrink: 0;
          position: relative;
          overflow: hidden;
        }
        
        .wifi-database-header::before {
          content: '';
          position: absolute;
          top: 0;
          right: 0;
          width: 50%;
          height: 100%;
          background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse"><path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="1"/></pattern></defs><rect width="100" height="100" fill="url(%23grid)"/></svg>');
          opacity: 0.3;
          pointer-events: none;
        }
        
        .wifi-database-title {
          font-size: 2.5rem;
          font-weight: 800;
          margin: 0 0 12px 0;
          display: flex;
          align-items: center;
          gap: 16px;
          color: white !important;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
          letter-spacing: -0.025em;
          position: relative;
          z-index: 1;
        }
        
        .wifi-database-title svg {
          filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }
        
        .wifi-database-subtitle {
          font-size: 15px;
          color: rgba(255, 255, 255, 0.9) !important;
          margin: 0 0 20px 0;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        .wifi-database-stats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
          gap: 16px;
          margin-top: 16px;
        }
        
        /* Interactive Controls - Search Removed */
        .wifi-header-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
        }
        
        .wifi-filter-group {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        
        .wifi-filter-select {
          padding: 8px 12px;
          border: 2px solid #e5e7eb;
          border-radius: 6px;
          font-size: 13px;
          background: white;
          cursor: pointer;
          outline: none;
          transition: all 0.2s ease;
          min-width: 120px;
        }
        
        .wifi-filter-select:hover {
          border-color: #d1d5db;
        }
        
        .wifi-filter-select:focus {
          border-color: #10b981;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        
        .wifi-header-actions { display: flex; gap: 8px; }

        /* New: Upload Whitelist button */
        .wifi-upload-btn {
          background: #2563eb;
          color: white;
          border: none;
          border-radius: 8px;
          padding: 10px 14px;
          font-weight: 600;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }
        .wifi-upload-btn:hover { background: #1d4ed8; }
        
        .wifi-action-btn {
          padding: 8px 16px;
          border: none;
          border-radius: 6px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          display: flex;
          align-items: center;
          gap: 6px;
        }
        
        .wifi-action-btn.primary {
          background: #10b981;
          color: white;
        }
        
        .wifi-action-btn.primary:hover {
          background: #2563eb;
          transform: translateY(-1px);
        }
        
        .wifi-action-btn.secondary {
          background: #f3f4f6;
          color: #374151;
          border: 1px solid #d1d5db;
        }
        
        .wifi-action-btn.secondary:hover {
          background: #e5e7eb;
        }
        
        /* Interactive Table Headers */
        .wifi-table th {
          cursor: pointer;
          user-select: none;
          transition: all 0.2s ease;
          position: relative;
        }
        
        .wifi-table th:hover {
          background-color: #f3f4f6;
        }
        
        .wifi-table th.sortable::after {
          content: '↕️';
          position: absolute;
          right: 8px;
          opacity: 0.5;
          font-size: 12px;
        }
        
        .wifi-table th.sort-asc::after {
          content: '↑';
          opacity: 1;
          color: #10b981;
        }
        
        .wifi-table th.sort-desc::after {
          content: '↓';
          opacity: 1;
          color: #10b981;
        }
        
        /* Interactive Row States */
        .wifi-table tbody tr {
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .wifi-table tbody tr:hover {
          background-color: #f8fafc !important;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          transform: translateY(-1px);
        }
        
        .wifi-table tbody tr.selected {
          background-color: #dbeafe !important;
          border-left: 4px solid #10b981;
        }
        
        /* Action Buttons in Rows */
        .wifi-row-actions {
          display: flex;
          gap: 4px;
          opacity: 0;
          transition: opacity 0.2s ease;
        }
        
        .wifi-table tbody tr:hover .wifi-row-actions {
          opacity: 1;
        }
        
        .wifi-mini-btn {
          padding: 4px 8px;
          border: none;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .wifi-mini-btn.view {
          background: #e0f2fe;
          color: #0369a1;
        }
        
        .wifi-mini-btn.view:hover {
          background: #0369a1;
          color: white;
        }
        
        .wifi-mini-btn.block {
          background: #fef2f2;
          color: #dc2626;
        }
        
        .wifi-mini-btn.block:hover {
          background: #dc2626;
          color: white;
        }
        
        .wifi-mini-btn.verify {
          background: #f0fdf4;
          color: #16a34a;
        }
        
        .wifi-mini-btn.verify:hover {
          background: #16a34a;
          color: white;
        }
        
        .wifi-stat-card {
          background: rgba(255, 255, 255, 0.1);
          padding: 16px;
          border-radius: 8px;
          text-align: center;
          backdrop-filter: blur(10px);
        }
        
        .wifi-stat-number {
          font-size: 24px;
          font-weight: 700;
          color: white !important;
          display: block;
          margin-bottom: 4px;
        }
        
        .wifi-stat-label {
          font-size: 13px;
          color: rgba(255, 255, 255, 0.8) !important;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 500;
        }
        

        
        .wifi-table-container {
          flex: 1;
          overflow: auto;
          background: white;
          margin: 0 16px;
          border-left: 1px solid #e2e8f0;
          border-right: 1px solid #e2e8f0;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }
        
        .wifi-database-table {
          width: 100%;
          border-collapse: separate;
          border-spacing: 0;
          font-size: 14px;
          background: white;
          min-width: 1400px;
          overflow: hidden;
          table-layout: fixed;
        }
        
        .wifi-database-table th {
          background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
          border-bottom: 3px solid #10b981;
          border-right: 1px solid #e2e8f0;
          padding: 16px 12px;
          text-align: left;
          font-weight: 700;
          color: #1e293b;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.8px;
          position: sticky;
          top: 0;
          z-index: 10;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
          vertical-align: middle;
        }
        
        .wifi-database-table th:last-child {
          border-right: none;
        }
        
        .wifi-database-table th.sortable {
          cursor: pointer;
          user-select: none;
          transition: all 0.2s;
          position: relative;
        }
        
        .wifi-database-table th.sortable:hover {
          background: #f1f5f9;
          color: #1e293b;
        }
        
        .wifi-database-table th.sorted {
          background: #e0e7ff;
          color: #3730a3;
        }
        
        .wifi-sort-icon {
          display: inline-block;
          margin-left: 6px;
          opacity: 0.5;
          transition: all 0.2s;
        }
        
        .wifi-database-table th.sorted .wifi-sort-icon {
          opacity: 1;
          color: #10b981;
        }
        
        .wifi-database-table td {
          padding: 14px 12px;
          border-bottom: 1px solid #f1f5f9;
          border-right: 1px solid #f8fafc;
          color: #374151;
          vertical-align: middle;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
          font-size: 13px;
          text-align: left;
          word-wrap: break-word;
        }
        
        .wifi-database-table td:last-child {
          border-right: none;
        }
        
        .wifi-database-table tbody tr {
          transition: all 0.2s ease;
          position: relative;
        }
        
        .wifi-database-table tbody tr:hover {
          background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        
        .wifi-database-table tbody tr:nth-child(even) {
          background: #fafbfc;
        }
        
        .wifi-database-table tbody tr:nth-child(even):hover {
          background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
          transform: translateY(-1px);
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        }
        
        .wifi-ssid-cell {
          font-weight: 600;
          color: #1e293b;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        
        .wifi-bssid-cell {
          font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
          font-size: 12px;
          color: #6b7280;
          background: #f9fafb;
          padding: 4px 8px;
          border-radius: 4px;
          display: inline-block;
        }
        
        .wifi-location-cell {
          color: #374151;
          font-weight: 500;
        }
        
        .wifi-signal-cell {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        
        .wifi-signal-strength {
          display: flex;
          align-items: end;
          gap: 1px;
          margin-right: 8px;
        }
        
        .wifi-signal-bar {
          width: 3px;
          background: #e5e7eb;
          border-radius: 1px;
          transition: all 0.2s;
        }
        
        .wifi-signal-bar.active {
          background: #10b981;
        }
        
        .wifi-signal-bar.medium {
          background: #f59e0b;
        }
        
        .wifi-signal-bar.weak {
          background: #ef4444;
        }
        
        .wifi-signal-text {
          font-size: 12px;
          color: #6b7280;
          font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
        }
        
        .wifi-status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .wifi-status-verified {
          background: #dcfce7;
          color: #166534;
          border: 1px solid #bbf7d0;
        }
        
        .wifi-status-pending {
          background: #fef3c7;
          color: #92400e;
          border: 1px solid #fde68a;
        }
        
        .wifi-status-suspicious {
          background: #fee2e2;
          color: #991b1b;
          border: 1px solid #fecaca;
        }
        
        .wifi-threat-badge {
          display: inline-block;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .wifi-threat-low {
          background: #dbeafe;
          color: #1d4ed8;
        }
        
        .wifi-threat-medium {
          background: #fef3c7;
          color: #d97706;
        }
        
        .wifi-threat-high {
          background: #fee2e2;
          color: #dc2626;
        }
        
        .wifi-security-badge {
          display: inline-block;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .wifi-security-wpa3 {
          background: #dcfce7;
          color: #166534;
        }
        
        .wifi-security-wpa2 {
          background: #dbeafe;
          color: #1d4ed8;
        }
        
        .wifi-security-open {
          background: #fee2e2;
          color: #dc2626;
        }
        
        .wifi-whitelist-badge {
          display: inline-block;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 10px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .wifi-whitelist-badge.whitelisted {
          background: #dcfce7;
          color: #166534;
          border: 1px solid #bbf7d0;
        }
        
        .wifi-whitelist-badge.not-whitelisted {
          background: #f3f4f6;
          color: #6b7280;
          border: 1px solid #d1d5db;
        }
        
        .wifi-actions-cell {
          display: flex;
          gap: 6px;
          align-items: center;
        }
        
        .wifi-action-btn {
          padding: 6px 10px;
          border: none;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 4px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .wifi-action-view {
          background: #dbeafe;
          color: #1d4ed8;
        }
        
        .wifi-action-view:hover {
          background: #bfdbfe;
          transform: translateY(-1px);
        }
        
        .wifi-action-add {
          background: #dcfce7;
          color: #166534;
        }
        
        .wifi-action-add:hover {
          background: #bbf7d0;
          transform: translateY(-1px);
        }
        
        .wifi-action-remove {
          background: #fee2e2;
          color: #dc2626;
        }
        
        .wifi-action-remove:hover {
          background: #fecaca;
          transform: translateY(-1px);
        }
        
        .wifi-table-footer {
          background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
          border-top: 2px solid #e2e8f0;
          padding: 20px 40px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-shrink: 0;
          margin: 0 16px 16px 16px;
          border-radius: 0 0 12px 12px;
          box-shadow: 0 -2px 4px rgba(0, 0, 0, 0.05);
        }
        
        .wifi-pagination-info {
          color: #6b7280;
          font-size: 14px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        .wifi-pagination-controls {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        
        .wifi-rows-per-page {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #6b7280;
          font-size: 14px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        .wifi-rows-select {
          background: white;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          padding: 4px 8px;
          font-size: 14px;
          color: #374151;
          cursor: pointer;
        }
        
        .wifi-pagination-btn {
          background: white;
          border: 1px solid #d1d5db;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 14px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          gap: 4px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        .wifi-pagination-btn:hover:not(:disabled) {
          background: #f9fafb;
          border-color: #9ca3af;
        }
        
        .wifi-pagination-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        
        .wifi-page-numbers {
          display: flex;
          gap: 4px;
        }
        
        .wifi-page-btn {
          background: white;
          border: 1px solid #d1d5db;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 14px;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 36px;
          text-align: center;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
        }
        
        .wifi-page-btn.active {
          background: #10b981;
          color: white;
          border-color: #10b981;
        }
        
        .wifi-page-btn:hover:not(.active) {
          background: #f9fafb;
          border-color: #9ca3af;
        }
        
        .wifi-empty-state {
          text-align: center;
          padding: 80px 20px;
          color: #6b7280;
        }
        
        .wifi-empty-icon {
          font-size: 64px;
          margin-bottom: 16px;
          opacity: 0.5;
        }
        
        .wifi-empty-title {
          font-size: 18px;
          font-weight: 600;
          margin-bottom: 8px;
          color: #374151;
        }
        
        .wifi-empty-subtitle {
          font-size: 14px;
          color: #6b7280;
        }
        
        @media (max-width: 768px) {

          
          .wifi-database-table {
            min-width: 800px;
          }
          
          .wifi-table-footer {
            flex-direction: column;
            gap: 16px;
            align-items: stretch;
            text-align: center;
          }
          
          .wifi-pagination-controls {
            justify-content: center;
          }
        }
      `;
      document.head.appendChild(style);
    }

    // Get filtered, searched, and sorted data
    const filteredData = getFilteredAndSearchedWiFiData();
    const sortedData = getSortedWiFiData(filteredData);
    
    // Calculate pagination
    const totalItems = sortedData.length;
    const totalPages = Math.ceil(totalItems / rowsPerPage);
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const paginatedData = sortedData.slice(startIndex, endIndex);

    const networksHTML = `
      <div class="wifi-database-container">
        <div class="wifi-database-header">
          <div class="wifi-header-row">
            <h1 class="wifi-database-title">
            <svg width="40" height="40" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/>
            </svg>
DICT Wifi Access Points
            </h1>
            <div class="wifi-header-actions">
              <button id="wifiWhitelistUploadBtn" class="wifi-upload-btn" title="Upload whitelist CSV" aria-label="Upload whitelist">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <path d="M12 5v14M5 12h14"/>
                </svg>
                Upload Whitelist
              </button>
            </div>
          </div>
          <p class="wifi-database-subtitle">Real-time network monitoring • Advanced threat detection • Professional database management</p>
          <div class="wifi-database-stats">
            <div class="wifi-stat-card">
              <span class="wifi-stat-number">${wifiNetworksData.length}</span>
              <span class="wifi-stat-label">Total Networks</span>
            </div>
            <div class="wifi-stat-card">
              <span class="wifi-stat-number">${wifiNetworksData.filter(n => n.status === 'Verified').length}</span>
              <span class="wifi-stat-label">Verified</span>
            </div>
            <div class="wifi-stat-card">
              <span class="wifi-stat-number">${wifiNetworksData.filter(n => n.status === 'Pending').length}</span>
              <span class="wifi-stat-label">Pending</span>
            </div>
            <div class="wifi-stat-card">
              <span class="wifi-stat-number">${wifiNetworksData.filter(n => n.threatLevel === 'High').length}</span>
              <span class="wifi-stat-label">High Risk</span>
            </div>
            <div class="wifi-stat-card">
              <span class="wifi-stat-number">${wifiNetworksData.filter(n => n.security === 'WPA3').length}</span>
              <span class="wifi-stat-label">WPA3 Secure</span>
            </div>
          </div>
        </div>
        


        
        <div class="wifi-table-container">
          ${paginatedData.length === 0 ? `
            <div class="wifi-empty-state">
              <div class="wifi-empty-icon">📶</div>
              <div class="wifi-empty-title">No networks found</div>
              <div class="wifi-empty-subtitle">Try adjusting your filters</div>
            </div>
          ` : `
            <table class="wifi-database-table">
              <thead>
                <tr>
                  <th class="sortable ${currentSort.field === 'ssid' ? 'sorted' : ''}" data-sort="ssid">
                    SSID
                    <span class="wifi-sort-icon">${getSortIcon('ssid')}</span>
                  </th>
                  <th>BSSID</th>
                  <th class="sortable ${currentSort.field === 'location' ? 'sorted' : ''}" data-sort="location">
                    Location
                    <span class="wifi-sort-icon">${getSortIcon('location')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'signal' ? 'sorted' : ''}" data-sort="signal">
                    Signal Strength
                    <span class="wifi-sort-icon">${getSortIcon('signal')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'security' ? 'sorted' : ''}" data-sort="security">
                    Security
                    <span class="wifi-sort-icon">${getSortIcon('security')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'frequency' ? 'sorted' : ''}" data-sort="frequency">
                    Frequency
                    <span class="wifi-sort-icon">${getSortIcon('frequency')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'status' ? 'sorted' : ''}" data-sort="status">
                    Status
                    <span class="wifi-sort-icon">${getSortIcon('status')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'threatLevel' ? 'sorted' : ''}" data-sort="threatLevel">
                    Threat
                    <span class="wifi-sort-icon">${getSortIcon('threatLevel')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'isWhitelisted' ? 'sorted' : ''}" data-sort="isWhitelisted">
                    Whitelist
                    <span class="wifi-sort-icon">${getSortIcon('isWhitelisted')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'connectedDevices' ? 'sorted' : ''}" data-sort="connectedDevices">
                    Devices
                    <span class="wifi-sort-icon">${getSortIcon('connectedDevices')}</span>
                  </th>
                  <th class="sortable ${currentSort.field === 'lastSeen' ? 'sorted' : ''}" data-sort="lastSeen">
                    Last Seen
                    <span class="wifi-sort-icon">${getSortIcon('lastSeen')}</span>
                  </th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${paginatedData.map(network => `
                  <tr>
                    <td>
                      <div class="wifi-ssid-cell">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.143 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"/>
                        </svg>
                        ${network.ssid}
                      </div>
                    </td>
                    <td>
                      <span class="wifi-bssid-cell">${network.bssid}</span>
                    </td>
                    <td>
                      <div class="wifi-location-cell">
                        ${network.location}
                        <div style="font-size: 12px; color: #6b7280; margin-top: 2px;">${network.province}</div>
                      </div>
                    </td>
                    <td>
                      <div class="wifi-signal-cell">
                        <div class="wifi-signal-strength">
                          ${getSignalBars(network.signal)}
                        </div>
                        <div>
                          <div class="wifi-signal-text">${network.signal} dBm</div>
                          <div style="font-size: 11px; color: #6b7280;">${network.coverage}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div>
                        <span class="wifi-security-badge wifi-security-${network.security.toLowerCase().replace(/[^a-z]/g, '')}">${network.security}</span>
                        <div style="font-size: 11px; color: #6b7280; margin-top: 4px;">${network.encryption}</div>
                      </div>
                    </td>
                    <td style="font-weight: 500;">${network.frequency}</td>
                    <td>
                      <span class="wifi-status-badge wifi-status-${network.status.toLowerCase()}">
                        ${network.status}
                      </span>
                    </td>
                    <td>
                      <span class="wifi-threat-badge wifi-threat-${network.threatLevel.toLowerCase()}">
                        ${network.threatLevel}
                      </span>
                    </td>
                    <td>
                      <span class="wifi-whitelist-badge ${network.isWhitelisted ? 'whitelisted' : 'not-whitelisted'}">
                        ${network.isWhitelisted ? '✓ Whitelisted' : '○ Not Listed'}
                      </span>
                    </td>
                    <td style="text-align: center; font-weight: 600;">${network.connectedDevices}</td>
                    <td style="font-size: 12px; color: #6b7280;">${formatDateTime(network.lastSeen)}</td>
                    <td>
                      <div class="wifi-actions-cell">
                        <button class="wifi-action-btn wifi-action-view" onclick="viewWiFiNetworkDetails(${network.id})" title="View Details">
                          <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                          </svg>
                        </button>
                        ${network.isWhitelisted ? `
                          <button class="wifi-action-btn wifi-action-remove" onclick="removeWiFiNetworkFromWhitelist(${network.id})" title="Remove from Whitelist">
                            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                          </button>
                        ` : `
                          <button class="wifi-action-btn wifi-action-add" onclick="addWiFiNetworkToWhitelist(${network.id})" title="Add to Whitelist">
                            <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                          </button>
                        `}
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `}
        </div>
        
        <div class="wifi-table-footer">
          <div class="wifi-pagination-info">
            Showing ${startIndex + 1}-${Math.min(endIndex, totalItems)} of ${totalItems} networks
          </div>
          
          <div class="wifi-pagination-controls">
            <div class="wifi-rows-per-page">
              <label for="wifiRowsPerPage">Rows per page:</label>
              <select class="wifi-rows-select" id="wifiRowsPerPage">
                <option value="10" ${rowsPerPage === 10 ? 'selected' : ''}>10</option>
                <option value="25" ${rowsPerPage === 25 ? 'selected' : ''}>25</option>
                <option value="50" ${rowsPerPage === 50 ? 'selected' : ''}>50</option>
                <option value="100" ${rowsPerPage === 100 ? 'selected' : ''}>100</option>
              </select>
            </div>
            
            <button class="wifi-pagination-btn" onclick="goToWiFiPage(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
              </svg>
              Previous
            </button>
            
            <div class="wifi-page-numbers">
              ${generatePageNumbers(currentPage, totalPages)}
            </div>
            
            <button class="wifi-pagination-btn" onclick="goToWiFiPage(${currentPage + 1})" ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''}>
              Next
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = networksHTML;

    // Add event listeners
    setupWiFiEventListeners();

  } catch (error) {
    console.error('Error rendering WiFi networks:', error);
  } finally {
    isRendering = false;
  }
}

// Hook up whitelist upload button behavior (placeholder)
document.addEventListener('click', (e) => {
  const btn = e.target.closest('#wifiWhitelistUploadBtn');
  if (btn) {
    alert('Upload whitelist: please select your CSV of legitimate access points. (Hook to real uploader)');
  }
});

function getFilteredWiFiData() {
  return wifiNetworksData.filter(item => {
    const statusMatch = currentFilter.status === 'all' || item.status === currentFilter.status;
    const securityMatch = currentFilter.security === 'all' || item.security === currentFilter.security;
    const threatMatch = currentFilter.threatLevel === 'all' || item.threatLevel === currentFilter.threatLevel;
    const provinceMatch = currentFilter.province === 'all' || item.province === currentFilter.province;
    const frequencyMatch = currentFilter.frequency === 'all' || item.frequency === currentFilter.frequency;
    const whitelistMatch = currentFilter.whitelist === 'all' || 
                          (currentFilter.whitelist === 'whitelisted' && item.isWhitelisted) ||
                          (currentFilter.whitelist === 'not-whitelisted' && !item.isWhitelisted);
    
    return statusMatch && securityMatch && threatMatch && provinceMatch && frequencyMatch && whitelistMatch;
  });
}

// Whitelist management functions
function isNetworkWhitelisted(networkId) {
  return whitelistedNetworks.some(wn => wn.id === networkId);
}

function checkNetworkInWhitelist(bssid) {
  return whitelistedNetworks.some(wn => wn.bssid === bssid);
}

function getSortedWiFiData(data) {
  return [...data].sort((a, b) => {
    let aVal = a[currentSort.field];
    let bVal = b[currentSort.field];
    
    if (typeof aVal === 'string') {
      aVal = aVal.toLowerCase();
      bVal = bVal.toLowerCase();
    }
    
    if (currentSort.direction === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });
}

function getSignalBars(signal) {
  const strength = Math.abs(signal);
  let bars = '';
  
  for (let i = 1; i <= 5; i++) {
    let className = 'wifi-signal-bar';
    if (strength < 60 && i <= 5) className += ' active';
    else if (strength < 70 && i <= 4) className += ' active';
    else if (strength < 80 && i <= 3) className += ' medium';
    else if (strength < 90 && i <= 2) className += ' weak';
    else if (i <= 1) className += ' weak';
    
    const height = i * 3;
    bars += `<div class="${className}" style="height: ${height}px;"></div>`;
  }
  
  return bars;
}

function formatDateTime(dateTimeString) {
  const date = new Date(dateTimeString);
  return date.toLocaleString('en-US', { 
    month: 'short', 
    day: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit' 
  });
}

function setupWiFiEventListeners() {
  console.log('Setting up enhanced WiFi event listeners...');
  




  // Rows per page select listener
  const rowsPerPageSelect = document.getElementById('wifiRowsPerPage');
  if (rowsPerPageSelect) {
    rowsPerPageSelect.addEventListener('change', (e) => {
      rowsPerPage = parseInt(e.target.value);
      currentPage = 1; // Reset to first page when rows per page changes
      showWiFiFilterToast(`Showing ${e.target.value} rows per page`);
      renderWiFiNetworks('wifi-networks-container');
    });
  }
  
  // Enhanced sortable table headers
  const sortableHeaders = document.querySelectorAll('.wifi-table th.sortable');
  sortableHeaders.forEach(header => {
    header.addEventListener('click', (e) => {
      const sortField = header.dataset.sort || header.textContent.toLowerCase().trim();
      handleWiFiSort(sortField);
    });
  });
  
  // Interactive table rows
  const tableRows = document.querySelectorAll('.wifi-table tbody tr');
  tableRows.forEach((row, index) => {
    // Add row selection on click
    row.addEventListener('click', (e) => {
      // Don't select if clicking on action buttons
      if (e.target.closest('.wifi-action-btn')) return;
      
      // Toggle row selection
      const isSelected = row.classList.contains('selected');
      
      // Clear other selections
      tableRows.forEach(r => r.classList.remove('selected'));
      
      if (!isSelected) {
        row.classList.add('selected');
        showWiFiFilterToast('Network selected - click actions to manage');
      }
    });
    
    // Add keyboard navigation
    row.setAttribute('tabindex', '0');
    row.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        row.click();
      }
    });
  });
  
  // Mark as interactive
  isTableInteractive = true;
  console.log('WiFi networks table is now fully interactive');
}

function getFilteredAndSearchedWiFiData() {
  let filteredData = getFilteredWiFiData();
  if (searchQuery) {
    const searchLower = searchQuery.toLowerCase();
    filteredData = filteredData.filter(network => 
      network.ssid.toLowerCase().includes(searchLower) ||
      network.bssid.toLowerCase().includes(searchLower) ||
      network.location.toLowerCase().includes(searchLower) ||
      network.manufacturer.toLowerCase().includes(searchLower)
    );
  }
  return filteredData;
}

function getSortIcon(field) {
  if (currentSort.field === field) {
    return currentSort.direction === 'asc' ? '↑' : '↓';
  }
  return '';
}

function clearAllWiFiFilters() {
  currentFilter = { 
    status: 'all', 
    security: 'all', 
    threatLevel: 'all',
    province: 'all',
    frequency: 'all'
  };
  searchQuery = '';
  renderWiFiNetworks('wifi-networks-container');
}

function goToWiFiPage(page) {
  currentPage = Math.max(1, Math.min(page, totalPages));
  renderWiFiNetworks('wifi-networks-container');
}

function generatePageNumbers(currentPage, totalPages) {
  const pages = [];
  if (totalPages <= 5) {
    for (let i = 1; i <= totalPages; i++) {
      pages.push(i);
    }
  } else {
    if (currentPage <= 3) {
      pages.push(1, 2, 3, '...', totalPages);
    } else if (currentPage >= totalPages - 2) {
      pages.push(1, '...', totalPages - 2, totalPages - 1, totalPages);
    } else {
      pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
    }
  }
  return pages.map(p => {
    if (p === '...') return `<span class="wifi-page-btn">...</span>`;
    if (p === currentPage) return `<span class="wifi-page-btn active">${p}</span>`;
    return `<button class="wifi-page-btn" onclick="goToWiFiPage(${p})">${p}</button>`;
  });
}

// Core functions for data viewing and whitelist management
function viewWiFiNetworkDetails(id) {
  const network = wifiNetworksData.find(n => n.id === id);
  if (network) {
    const details = `
      Network: ${network.ssid}
      BSSID: ${network.bssid}
      Location: ${network.location}, ${network.province}
      Security: ${network.security} (${network.encryption})
      Signal: ${network.signal} dBm (${network.coverage})
      Frequency: ${network.frequency}
      Status: ${network.status}
      Threat Level: ${network.threatLevel}
      Connected Devices: ${network.connectedDevices}
      Last Seen: ${network.lastSeen}
    `;
    alert(details);
  }
}

function addWiFiNetworkToWhitelist(id) {
  const network = wifiNetworksData.find(n => n.id === id);
  if (network) {
    if (confirm(`Add "${network.ssid}" to whitelist?`)) {
      // In a real application, this would call your whitelist API
      showToast(`"${network.ssid}" added to whitelist successfully!`, 'success');
      
      // Optionally navigate to whitelist section to show the addition
      setTimeout(() => {
        if (typeof window.showSection === 'function') {
          window.showSection('whitelist');
        }
      }, 1500);
    }
  }
}

function exportWiFiNetworks() {
  try {
    const csvContent = generateCSVContent();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `wifi-networks-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('WiFi networks data exported successfully!', 'success');
  } catch (error) {
    console.error('Export failed:', error);
    showToast('Export failed. Please try again.', 'error');
  }
}

function generateCSVContent() {
  const headers = ['SSID', 'BSSID', 'Location', 'Province', 'Signal (dBm)', 'Security', 'Encryption', 'Frequency', 'Status', 'Threat Level', 'Connected Devices', 'Last Seen'];
  const csvRows = [headers.join(',')];
  
  const filteredData = getFilteredAndSearchedWiFiData();
  
  filteredData.forEach(network => {
    const row = [
      `"${network.ssid}"`,
      network.bssid,
      `"${network.location}"`,
      network.province,
      network.signal,
      network.security,
      network.encryption,
      network.frequency,
      network.status,
      network.threatLevel,
      network.connectedDevices,
      network.lastSeen
    ];
    csvRows.push(row.join(','));
  });
  
  return csvRows.join('\n');
}

// Enhanced interactive functionality
function handleWiFiSort(field) {
  if (currentSortColumn === field) {
    currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
  } else {
    currentSortColumn = field;
    currentSortDirection = 'asc';
  }
  
  showWiFiFilterToast(`Sorted by ${field} (${currentSortDirection})`);
  renderWiFiNetworks('wifi-networks-container');
}

function showWiFiFilterToast(message) {
  // Remove existing toast
  const existingToast = document.querySelector('.wifi-filter-toast');
  if (existingToast) {
    existingToast.remove();
  }
  
  // Create new toast
  const toast = document.createElement('div');
  toast.className = 'wifi-filter-toast';
  toast.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    color: white;
    padding: 12px 16px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    z-index: 1000;
    opacity: 0;
    transform: translateX(100%);
    transition: all 0.3s ease;
    box-shadow: 0 8px 32px rgba(59, 130, 246, 0.3);
  `;
  toast.textContent = message;
  
  document.body.appendChild(toast);
  
  // Animate in
  setTimeout(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  }, 100);
  
  // Remove after 3 seconds
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (toast.parentElement) {
        document.body.removeChild(toast);
      }
    }, 300);
  }, 3000);
}

function refreshWiFiNetworks() {
  showWiFiFilterToast('Refreshing network data...');
  
  // Simulate refresh with loading state
  const container = document.getElementById('wifi-networks-container');
  if (container) {
    container.style.opacity = '0.7';
    
    setTimeout(() => {
      // Update last seen times
      wifiNetworksData.forEach(network => {
        const randomMinutes = Math.floor(Math.random() * 10);
        const now = new Date();
        now.setMinutes(now.getMinutes() - randomMinutes);
        network.lastSeen = now.toISOString().slice(0, 19).replace('T', ' ');
      });
      
      renderWiFiNetworks('wifi-networks-container');
      container.style.opacity = '1';
      showWiFiFilterToast('Network data refreshed successfully!');
    }, 1000);
  }
}

// Enhanced network actions with better feedback
window.viewWiFiNetworkDetails = function(id) {
  const network = wifiNetworksData.find(n => n.id === id);
  if (!network) {
    showWiFiFilterToast('Network not found!');
    return;
  }

  // Create detailed modal
  const modal = document.createElement('div');
  modal.className = 'wifi-detail-modal';
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2000;
    opacity: 0;
    transition: opacity 0.3s ease;
  `;
  
  const statusColor = {
    'Verified': '#10b981',
    'Pending': '#f59e0b',
    'Suspicious': '#ef4444'
  }[network.status] || '#6b7280';
  
  modal.innerHTML = `
    <div class="wifi-detail-content" style="
      background: white;
      border-radius: 16px;
      padding: 32px;
      max-width: 600px;
      width: 90%;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
      transform: scale(0.9);
      transition: transform 0.3s ease;
    ">
      <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px;">
        <h2 style="margin: 0; color: #111827; font-size: 24px; font-weight: 700;">
          ${network.ssid}
        </h2>
        <button onclick="closeWiFiModal()" style="
          background: #f3f4f6;
          border: none;
          border-radius: 50%;
          width: 36px;
          height: 36px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: background 0.2s ease;
        ">
          <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
        <div style="
          background: linear-gradient(135deg, ${statusColor}15 0%, ${statusColor}25 100%);
          border: 2px solid ${statusColor}40;
          border-radius: 12px;
          padding: 16px;
          text-align: center;
        ">
          <div style="color: ${statusColor}; font-weight: 700; font-size: 18px; margin-bottom: 4px;">
            ${network.status}
          </div>
          <div style="color: #6b7280; font-size: 14px;">Network Status</div>
        </div>
        
        <div style="
          background: linear-gradient(135deg, #10b98115 0%, #10b98125 100%);
          border: 2px solid #10b98140;
          border-radius: 12px;
          padding: 16px;
          text-align: center;
        ">
          <div style="color: #3b82f6; font-weight: 700; font-size: 18px; margin-bottom: 4px;">
            ${network.signal} dBm
          </div>
          <div style="color: #6b7280; font-size: 14px;">Signal Strength</div>
        </div>
      </div>
      
      <div style="display: grid; grid-template-columns: auto 1fr; gap: 16px 24px; margin-bottom: 24px;">
        <div style="font-weight: 600; color: #374151;">BSSID:</div>
        <div style="font-family: monospace; color: #111827;">${network.bssid}</div>
        
        <div style="font-weight: 600; color: #374151;">Location:</div>
        <div style="color: #111827;">${network.location}, ${network.province}</div>
        
        <div style="font-weight: 600; color: #374151;">Security:</div>
        <div style="color: #111827;">${network.security} (${network.encryption})</div>
        
        <div style="font-weight: 600; color: #374151;">Frequency:</div>
        <div style="color: #111827;">${network.frequency}</div>
        
        <div style="font-weight: 600; color: #374151;">Connected Devices:</div>
        <div style="color: #111827;">${network.connectedDevices}</div>
        
        <div style="font-weight: 600; color: #374151;">Threat Level:</div>
        <div style="color: #111827;">${network.threatLevel}</div>
        
        <div style="font-weight: 600; color: #374151;">Last Seen:</div>
        <div style="color: #111827;">${formatDateTime(network.lastSeen)}</div>
        
        <div style="font-weight: 600; color: #374151;">Whitelist Status:</div>
        <div style="color: ${network.isWhitelisted ? '#10b981' : '#6b7280'};">
          ${network.isWhitelisted ? '✓ Whitelisted' : '○ Not Whitelisted'}
        </div>
      </div>
      
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        ${!network.isWhitelisted ? `
          <button onclick="addWiFiNetworkToWhitelist(${network.id}); closeWiFiModal();" style="
            padding: 10px 20px;
            background: #10b981;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s ease;
          ">
            Add to Whitelist
          </button>
        ` : `
          <button onclick="removeWiFiNetworkFromWhitelist(${network.id}); closeWiFiModal();" style="
            padding: 10px 20px;
            background: #ef4444;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s ease;
          ">
            Remove from Whitelist
          </button>
        `}
        <button onclick="closeWiFiModal()" style="
          padding: 10px 20px;
          background: #f3f4f6;
          color: #374151;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
        ">
          Close
        </button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // Animate in
  setTimeout(() => {
    modal.style.opacity = '1';
    modal.querySelector('.wifi-detail-content').style.transform = 'scale(1)';
  }, 100);
  
  // Close on backdrop click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeWiFiModal();
    }
  });
};

window.closeWiFiModal = function() {
  const modal = document.querySelector('.wifi-detail-modal');
  if (modal) {
    modal.style.opacity = '0';
    modal.querySelector('.wifi-detail-content').style.transform = 'scale(0.9)';
    setTimeout(() => {
      document.body.removeChild(modal);
    }, 300);
  }
};

// Enhanced whitelist management with better feedback
window.addWiFiNetworkToWhitelist = function(id) {
  const network = wifiNetworksData.find(n => n.id === id);
  if (!network) return;
  
  if (network.isWhitelisted) {
    showWiFiFilterToast('Network is already whitelisted');
    return;
  }
  
  // Add to whitelist
  whitelistedNetworks.push({
    id: network.id,
    bssid: network.bssid,
    ssid: network.ssid,
    addedDate: new Date().toISOString().split('T')[0],
    addedBy: 'Admin'
  });
  
  // Update network status
  network.isWhitelisted = true;
  
  // Re-render
  renderWiFiNetworks('wifi-networks-container');
  showWiFiFilterToast(`Added "${network.ssid}" to whitelist`);
};

window.removeWiFiNetworkFromWhitelist = function(id) {
  const network = wifiNetworksData.find(n => n.id === id);
  if (!network) return;
  
  if (!network.isWhitelisted) {
    showWiFiFilterToast('Network is not whitelisted');
    return;
  }
  
  // Remove from whitelist
  whitelistedNetworks = whitelistedNetworks.filter(wn => wn.id !== id);
  
  // Update network status
  network.isWhitelisted = false;
  
  // Re-render
  renderWiFiNetworks('wifi-networks-container');
  showWiFiFilterToast(`Removed "${network.ssid}" from whitelist`);
};

// Expose enhanced functions globally
window.renderWiFiNetworks = renderWiFiNetworks;
window.refreshWiFiNetworks = refreshWiFiNetworks;
window.handleWiFiSort = handleWiFiSort;
window.exportWiFiNetworks = exportWiFiNetworks;

// To use: call renderWiFiNetworks('wifi-networks-container') where you want the networks to appear. 
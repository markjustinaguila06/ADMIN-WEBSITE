// WhitelistTable.js - Enhanced Whitelist Management Table for DICT WiFi
// Modern design with sort/filter functionality instead of search

const whitelistData = [
  { 
    name: 'DICT WiFi - Batangas', 
    location: 'Batangas City', 
    status: 'Active', 
    mac: '00:11:22:33:44:55',
    addedDate: '2024-01-15',
    lastUpdated: '2024-03-20',
    priority: 'High'
  },
  { 
    name: 'DICT WiFi - Lipa', 
    location: 'Lipa City', 
    status: 'Active', 
    mac: '66:77:88:99:AA:BB',
    addedDate: '2024-02-10',
    lastUpdated: '2024-03-18',
    priority: 'Medium'
  },
  { 
    name: 'DICT WiFi - Tanauan', 
    location: 'Tanauan City', 
    status: 'Inactive', 
    mac: 'CC:DD:EE:FF:00:11',
    addedDate: '2024-01-20',
    lastUpdated: '2024-03-15',
    priority: 'Low'
  },
  { 
    name: 'DICT WiFi - Cavite', 
    location: 'Cavite City', 
    status: 'Active', 
    mac: 'AA:BB:CC:DD:EE:FF',
    addedDate: '2024-02-25',
    lastUpdated: '2024-03-22',
    priority: 'High'
  },
  { 
    name: 'DICT WiFi - Laguna', 
    location: 'San Pablo City', 
    status: 'Pending', 
    mac: '11:22:33:44:55:66',
    addedDate: '2024-03-10',
    lastUpdated: '2024-03-21',
    priority: 'Medium'
  }
];

let currentSort = { field: 'name', direction: 'asc' };
let currentFilter = { status: 'all', priority: 'all' };
let isRendering = false;

function renderWhitelistTable(containerId) {
  if (isRendering) return;
  
  try {
    isRendering = true;
    const container = document.getElementById(containerId);
    if (!container) {
      console.error(`Container with ID ${containerId} not found`);
      return;
    }

    // Add enhanced styles
    if (!document.getElementById('whitelist-enhanced-styles')) {
      const style = document.createElement('style');
      style.id = 'whitelist-enhanced-styles';
      style.innerHTML = `
        .whitelist-container {
          background: #ffffff;
          border-radius: 16px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
          overflow: hidden;
        }
        
        .whitelist-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 24px 32px;
          position: relative;
        }
        
        .whitelist-header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
          opacity: 0.3;
        }
        
        .whitelist-header-content {
          position: relative;
          z-index: 1;
        }
        
        .whitelist-title {
          font-size: 28px;
          font-weight: 700;
          margin: 0 0 8px 0;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .whitelist-subtitle {
          font-size: 16px;
          opacity: 0.9;
          margin: 0;
        }
        
        .whitelist-stats {
          display: flex;
          gap: 24px;
          margin-top: 20px;
        }
        
        .stat-item {
          display: flex;
          align-items: center;
          gap: 8px;
          background: rgba(255, 255, 255, 0.15);
          padding: 8px 16px;
          border-radius: 20px;
          backdrop-filter: blur(10px);
        }
        
        .stat-number {
          font-weight: 700;
          font-size: 18px;
        }
        
        .whitelist-controls {
          padding: 24px 32px;
          background: #f8fafc;
          border-bottom: 1px solid #e2e8f0;
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 16px;
        }
        
        .filter-group {
          display: flex;
          gap: 12px;
          align-items: center;
        }
        
        .filter-label {
          font-weight: 600;
          color: #374151;
          font-size: 14px;
        }
        
        .filter-select {
          background: white;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          padding: 8px 12px;
          font-size: 14px;
          color: #374151;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 120px;
        }
        
        .filter-select:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .btn-modern {
          border: none;
          border-radius: 8px;
          padding: 10px 20px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          text-decoration: none;
        }
        
        .btn-modern-primary {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          box-shadow: 0 4px 6px -1px rgba(102, 126, 234, 0.3);
        }
        
        .btn-modern-primary:hover {
          transform: translateY(-1px);
          box-shadow: 0 6px 12px -1px rgba(102, 126, 234, 0.4);
        }
        
        .btn-modern-secondary {
          background: white;
          color: #374151;
          border: 2px solid #e5e7eb;
        }
        
        .btn-modern-secondary:hover {
          border-color: #667eea;
          color: #667eea;
        }
        
        .btn-modern-danger {
          background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
          color: white;
        }
        
        .btn-modern-danger:hover {
          transform: translateY(-1px);
          box-shadow: 0 4px 6px -1px rgba(239, 68, 68, 0.3);
        }
        
        .whitelist-table-container {
          overflow-x: auto;
        }
        
        .whitelist-table {
          width: 100%;
          border-collapse: collapse;
          background: white;
        }
        
        .whitelist-table th {
          background: #f8fafc;
          padding: 16px 20px;
          text-align: left;
          font-weight: 600;
          color: #374151;
          font-size: 14px;
          border-bottom: 2px solid #e2e8f0;
          cursor: pointer;
          transition: background 0.2s;
          position: relative;
        }
        
        .whitelist-table th:hover {
          background: #f1f5f9;
        }
        
        .whitelist-table th.sortable::after {
          content: '↕';
          position: absolute;
          right: 8px;
          opacity: 0.5;
          font-size: 12px;
        }
        
        .whitelist-table th.sort-asc::after {
          content: '↑';
          opacity: 1;
          color: #667eea;
        }
        
        .whitelist-table th.sort-desc::after {
          content: '↓';
          opacity: 1;
          color: #667eea;
        }
        
        .whitelist-table td {
          padding: 16px 20px;
          border-bottom: 1px solid #f1f5f9;
          vertical-align: middle;
        }
        
        .whitelist-table tbody tr {
          transition: background 0.2s;
        }
        
        .whitelist-table tbody tr:hover {
          background: #f8fafc;
        }
        
        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .status-active {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          color: white;
        }
        
        .status-inactive {
          background: #f3f4f6;
          color: #6b7280;
        }
        
        .status-pending {
          background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
          color: white;
        }
        
        .priority-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 8px;
          border-radius: 12px;
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
        }
        
        .priority-high {
          background: #fee2e2;
          color: #dc2626;
        }
        
        .priority-medium {
          background: #fef3c7;
          color: #d97706;
        }
        
        .priority-low {
          background: #dbeafe;
          color: #2563eb;
        }
        
        .mac-address {
          font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
          font-size: 13px;
          color: #6b7280;
          background: #f9fafb;
          padding: 4px 8px;
          border-radius: 4px;
        }
        
        .action-buttons {
          display: flex;
          gap: 8px;
        }
        
        .btn-icon {
          width: 32px;
          height: 32px;
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: none;
          cursor: pointer;
          transition: all 0.2s;
          font-size: 14px;
        }
        
        .btn-edit {
          background: #dbeafe;
          color: #2563eb;
        }
        
        .btn-edit:hover {
          background: #bfdbfe;
          transform: scale(1.05);
        }
        
        .btn-delete {
          background: #fee2e2;
          color: #dc2626;
        }
        
        .btn-delete:hover {
          background: #fecaca;
          transform: scale(1.05);
        }
        
        .empty-state {
          text-align: center;
          padding: 60px 20px;
          color: #6b7280;
        }
        
        .empty-state-icon {
          font-size: 48px;
          margin-bottom: 16px;
          opacity: 0.5;
        }
        
        .empty-state-text {
          font-size: 16px;
          margin-bottom: 8px;
        }
        
        .empty-state-subtext {
          font-size: 14px;
          opacity: 0.7;
        }
        
        @media (max-width: 768px) {
          .whitelist-controls {
            flex-direction: column;
            align-items: stretch;
          }
          
          .filter-group {
            justify-content: space-between;
          }
          
          .whitelist-stats {
            flex-wrap: wrap;
          }
          
          .action-buttons {
            flex-direction: column;
          }
        }
      `;
      document.head.appendChild(style);
    }

    // Get filtered and sorted data
    const filteredData = getFilteredData();
    const sortedData = getSortedData(filteredData);

    const tableHTML = `
      <div class="whitelist-container">
        <div class="whitelist-header">
          <div class="whitelist-header-content">
            <h1 class="whitelist-title">
              <svg width="28" height="28" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
              </svg>
              Whitelist Management
            </h1>
            <p class="whitelist-subtitle">Manage trusted Wi-Fi networks and their security status</p>
            <div class="whitelist-stats">
              <div class="stat-item">
                <span class="stat-number">${whitelistData.length}</span>
                <span>Total Networks</span>
              </div>
              <div class="stat-item">
                <span class="stat-number">${whitelistData.filter(n => n.status === 'Active').length}</span>
                <span>Active</span>
              </div>
              <div class="stat-item">
                <span class="stat-number">${whitelistData.filter(n => n.status === 'Pending').length}</span>
                <span>Pending</span>
              </div>
            </div>
          </div>
        </div>
        
        <div class="whitelist-controls">
          <div class="filter-group">
            <label class="filter-label">Status:</label>
            <select class="filter-select" id="statusFilter">
              <option value="all">All Status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Pending">Pending</option>
            </select>
            
            <label class="filter-label">Priority:</label>
            <select class="filter-select" id="priorityFilter">
              <option value="all">All Priorities</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
          
          <button class="btn-modern btn-modern-primary" onclick="showWhitelistModal()">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
            </svg>
            Add Network
          </button>
        </div>
        
        <div class="whitelist-table-container">
          ${sortedData.length === 0 ? `
            <div class="empty-state">
              <div class="empty-state-icon">📋</div>
              <div class="empty-state-text">No networks found</div>
              <div class="empty-state-subtext">Try adjusting your filters or add a new network</div>
            </div>
          ` : `
            <table class="whitelist-table">
              <thead>
                <tr>
                  <th class="sortable" data-field="name">Network Name</th>
                  <th class="sortable" data-field="location">Location</th>
                  <th class="sortable" data-field="status">Status</th>
                  <th class="sortable" data-field="priority">Priority</th>
                  <th>MAC Address</th>
                  <th class="sortable" data-field="addedDate">Added Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                ${sortedData.map((item, index) => `
                  <tr>
                    <td>
                      <div style="font-weight: 600; color: #1f2937;">${item.name}</div>
                    </td>
                    <td>${item.location}</td>
                    <td>
                      <span class="status-badge status-${item.status.toLowerCase()}">
                        <svg width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <circle cx="12" cy="12" r="10"/>
                          <path d="M8 12l3 3 5-5"/>
                        </svg>
                        ${item.status}
                      </span>
                    </td>
                    <td>
                      <span class="priority-badge priority-${item.priority.toLowerCase()}">
                        ${item.priority}
                      </span>
                    </td>
                    <td>
                      <span class="mac-address">${item.mac}</span>
                    </td>
                    <td>${formatDate(item.addedDate)}</td>
                    <td>
                      <div class="action-buttons">
                        <button class="btn-icon btn-edit" onclick="editWhitelistEntry(${index})" title="Edit">
                          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                          </svg>
                        </button>
                        <button class="btn-icon btn-delete" onclick="deleteWhitelistEntry(${index})" title="Delete">
                          <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                          </svg>
                        </button>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          `}
        </div>
      </div>
    `;

    container.innerHTML = tableHTML;

    // Add event listeners
    setupEventListeners();
    updateSortIndicators();

  } catch (error) {
    console.error('Error rendering whitelist table:', error);
  } finally {
    isRendering = false;
  }
}

function getFilteredData() {
  return whitelistData.filter(item => {
    const statusMatch = currentFilter.status === 'all' || item.status === currentFilter.status;
    const priorityMatch = currentFilter.priority === 'all' || item.priority === currentFilter.priority;
    return statusMatch && priorityMatch;
  });
}

function getSortedData(data) {
  return [...data].sort((a, b) => {
    let aVal = a[currentSort.field];
    let bVal = b[currentSort.field];
    
    if (typeof aVal === 'string') {
      aVal = aVal.toLowerCase();
      bVal = bVal.toLowerCase();
    }
    
    if (currentSort.direction === 'asc') {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });
}

function setupEventListeners() {
  // Filter event listeners
  const statusFilter = document.getElementById('statusFilter');
  const priorityFilter = document.getElementById('priorityFilter');
  
  if (statusFilter) {
    statusFilter.value = currentFilter.status;
    statusFilter.addEventListener('change', (e) => {
      currentFilter.status = e.target.value;
      renderWhitelistTable('whitelist-table-container');
    });
  }
  
  if (priorityFilter) {
    priorityFilter.value = currentFilter.priority;
    priorityFilter.addEventListener('change', (e) => {
      currentFilter.priority = e.target.value;
      renderWhitelistTable('whitelist-table-container');
    });
  }
  
  // Sort event listeners
  const sortableHeaders = document.querySelectorAll('.whitelist-table th.sortable');
  sortableHeaders.forEach(header => {
    header.addEventListener('click', () => {
      const field = header.dataset.field;
      if (currentSort.field === field) {
        currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
      } else {
        currentSort.field = field;
        currentSort.direction = 'asc';
      }
      renderWhitelistTable('whitelist-table-container');
    });
  });
}

function updateSortIndicators() {
  const headers = document.querySelectorAll('.whitelist-table th.sortable');
  headers.forEach(header => {
    header.classList.remove('sort-asc', 'sort-desc');
    if (header.dataset.field === currentSort.field) {
      header.classList.add(`sort-${currentSort.direction}`);
    }
  });
}

function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

function showWhitelistModal(index = null) {
  try {
    const modal = document.getElementById('whitelistModal');
    if (!modal) {
      console.error('Whitelist modal not found');
      return;
    }
    
    // Add enhanced modal styles
    if (!document.getElementById('whitelist-modal-styles')) {
      const style = document.createElement('style');
      style.id = 'whitelist-modal-styles';
      style.innerHTML = `
        .modal-overlay {
          position: fixed;
          top: 0; left: 0; right: 0; bottom: 0;
          background: rgba(0, 0, 0, 0.6);
          backdrop-filter: blur(4px);
          z-index: 1000;
          display: flex;
          align-items: center;
          justify-content: center;
          animation: fadeIn 0.3s ease-out;
        }
        
        @keyframes fadeIn {
          from { opacity: 0; } to { opacity: 1; }
        }
        
        .modal-content-modern {
          background: white;
          border-radius: 16px;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
          padding: 0;
          min-width: 480px;
          max-width: 95vw;
          max-height: 90vh;
          overflow: hidden;
          position: relative;
          animation: modalSlideIn 0.3s ease-out;
        }
        
        @keyframes modalSlideIn {
          from { 
            transform: scale(0.95) translateY(-20px); 
            opacity: 0; 
          } 
          to { 
            transform: scale(1) translateY(0); 
            opacity: 1; 
          }
        }
        
        .modal-header {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          padding: 24px 32px;
          position: relative;
        }
        
        .modal-header::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
          opacity: 0.3;
        }
        
        .modal-header-content {
          position: relative;
          z-index: 1;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .modal-title-modern {
          font-size: 24px;
          font-weight: 700;
          margin: 0;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .modal-close-x {
          background: rgba(255, 255, 255, 0.2);
          border: none;
          color: white;
          width: 32px;
          height: 32px;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
          transition: all 0.2s;
          backdrop-filter: blur(10px);
        }
        
        .modal-close-x:hover {
          background: rgba(255, 255, 255, 0.3);
          transform: scale(1.05);
        }
        
        .modal-body {
          padding: 32px;
        }
        
        .form-group {
          margin-bottom: 24px;
        }
        
        .form-label {
          display: block;
          margin-bottom: 8px;
          font-weight: 600;
          color: #374151;
          font-size: 14px;
        }
        
        .form-control {
          width: 100%;
          padding: 12px 16px;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          font-size: 14px;
          color: #374151;
          background: white;
          transition: all 0.2s;
          box-sizing: border-box;
        }
        
        .form-control:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-control.error {
          border-color: #ef4444;
        }
        
        .form-text {
          font-size: 12px;
          color: #6b7280;
          margin-top: 4px;
        }
        
        .form-text.error {
          color: #ef4444;
        }
        
        .modal-footer-modern {
          display: flex;
          justify-content: flex-end;
          gap: 12px;
          padding: 24px 32px;
          background: #f8fafc;
          border-top: 1px solid #e2e8f0;
        }
        
        .btn-modern-success {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          color: white;
          box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.3);
        }
        
        .btn-modern-success:hover {
          transform: translateY(-1px);
          box-shadow: 0 6px 12px -1px rgba(16, 185, 129, 0.4);
        }
        
        .priority-options {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 8px;
        }
        
        .priority-option {
          padding: 12px;
          border: 2px solid #e5e7eb;
          border-radius: 8px;
          text-align: center;
          cursor: pointer;
          transition: all 0.2s;
          background: white;
        }
        
        .priority-option:hover {
          border-color: #667eea;
          background: #f8fafc;
        }
        
        .priority-option.selected {
          border-color: #667eea;
          background: #dbeafe;
          color: #2563eb;
        }
        
        .priority-option.high.selected {
          border-color: #ef4444;
          background: #fee2e2;
          color: #dc2626;
        }
        
        .priority-option.medium.selected {
          border-color: #f59e0b;
          background: #fef3c7;
          color: #d97706;
        }
        
        .priority-option.low.selected {
          border-color: #2563eb;
          background: #dbeafe;
          color: #2563eb;
        }
        
        .priority-label {
          font-weight: 600;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .priority-description {
          font-size: 11px;
          opacity: 0.7;
          margin-top: 2px;
        }
      `;
      document.head.appendChild(style);
    }
    
    // Add overlay
    modal.innerHTML = `<div class='modal-overlay' id='whitelistModalOverlay'></div>`;
    const isEdit = index !== null;
    const entry = isEdit ? whitelistData[index] : null;
    
    const modalContent = `
      <div class="modal-content-modern">
        <div class="modal-header">
          <div class="modal-header-content">
            <div class="modal-title-modern">
              <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
              </svg>
              ${isEdit ? 'Edit Network' : 'Add New Network'}
            </div>
            <button class="modal-close-x" onclick="closeWhitelistModal()">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>
        
        <div class="modal-body">
          <form id="whitelistForm">
            <div class="form-group">
              <label class="form-label">Network Name</label>
              <input type="text" class="form-control" name="name" value="${entry ? entry.name : ''}" required placeholder="Enter network name">
            </div>
            
            <div class="form-group">
              <label class="form-label">Location</label>
              <input type="text" class="form-control" name="location" value="${entry ? entry.location : ''}" required placeholder="Enter location">
            </div>
            
            <div class="form-group">
              <label class="form-label">Status</label>
              <select class="form-control" name="status" required>
                <option value="Active" ${entry && entry.status === 'Active' ? 'selected' : ''}>Active</option>
                <option value="Inactive" ${entry && entry.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                <option value="Pending" ${entry && entry.status === 'Pending' ? 'selected' : ''}>Pending</option>
              </select>
            </div>
            
            <div class="form-group">
              <label class="form-label">Priority Level</label>
              <div class="priority-options">
                <div class="priority-option high ${entry && entry.priority === 'High' ? 'selected' : ''}" data-value="High">
                  <div class="priority-label">High</div>
                  <div class="priority-description">Critical networks</div>
                </div>
                <div class="priority-option medium ${entry && entry.priority === 'Medium' ? 'selected' : ''}" data-value="Medium">
                  <div class="priority-label">Medium</div>
                  <div class="priority-description">Standard networks</div>
                </div>
                <div class="priority-option low ${entry && entry.priority === 'Low' ? 'selected' : ''}" data-value="Low">
                  <div class="priority-label">Low</div>
                  <div class="priority-description">Low priority</div>
                </div>
              </div>
              <input type="hidden" name="priority" value="${entry ? entry.priority : 'Medium'}">
            </div>
            
            <div class="form-group">
              <label class="form-label">MAC Address</label>
              <input type="text" class="form-control" name="mac" value="${entry ? entry.mac : ''}" required placeholder="00:11:22:33:44:55" pattern="^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$" title="Please enter a valid MAC address (e.g., 00:11:22:33:44:55)">
              <div class="form-text">Format: XX:XX:XX:XX:XX:XX</div>
            </div>
          </form>
        </div>
        
        <div class="modal-footer-modern">
          <button type="button" class="btn-modern btn-modern-secondary" onclick="closeWhitelistModal()">Cancel</button>
          <button type="submit" form="whitelistForm" class="btn-modern btn-modern-success">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
            </svg>
            ${isEdit ? 'Save Changes' : 'Add Network'}
          </button>
        </div>
      </div>
    `;
    
    // Insert modal content into overlay
    setTimeout(() => {
      const overlay = document.getElementById('whitelistModalOverlay');
      if (overlay) overlay.innerHTML = modalContent;
    }, 0);
    
    modal.style.display = 'block';
    
    // Add form validation and priority selection
    setTimeout(() => {
      const form = document.getElementById('whitelistForm');
      const priorityOptions = document.querySelectorAll('.priority-option');
      const priorityInput = document.querySelector('input[name="priority"]');
      
      if (form) {
        form.addEventListener('submit', (e) => {
          e.preventDefault();
          submitWhitelistForm(index);
        });
      }
      
      // Priority selection
      priorityOptions.forEach(option => {
        option.addEventListener('click', () => {
          priorityOptions.forEach(opt => opt.classList.remove('selected'));
          option.classList.add('selected');
          priorityInput.value = option.dataset.value;
        });
      });
      
      // Close modal on overlay click
      const overlay = document.getElementById('whitelistModalOverlay');
      if (overlay) {
        overlay.addEventListener('click', (e) => {
          if (e.target === overlay) {
            closeWhitelistModal();
          }
        });
      }
    }, 10);
    
  } catch (error) {
    console.error('Error showing whitelist modal:', error);
  }
}

function closeWhitelistModal() {
  try {
    const modal = document.getElementById('whitelistModal');
    if (modal) {
      modal.style.display = 'none';
      modal.innerHTML = '';
    }
  } catch (error) {
    console.error('Error closing whitelist modal:', error);
  }
}

function editWhitelistEntry(index) {
  try {
    showWhitelistModal(index);
  } catch (error) {
    console.error('Error editing whitelist entry:', error);
  }
}

function deleteWhitelistEntry(index) {
  try {
    const entry = whitelistData[index];
    const networkName = entry ? entry.name : 'this network';
    
    // Create a custom confirmation dialog
    const confirmDialog = document.createElement('div');
    confirmDialog.className = 'modal-overlay';
    confirmDialog.innerHTML = `
      <div class="modal-content-modern" style="max-width: 400px;">
        <div class="modal-header">
          <div class="modal-header-content">
            <div class="modal-title-modern">
              <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
              </svg>
              Confirm Deletion
            </div>
            <button class="modal-close-x" onclick="this.closest('.modal-overlay').remove()">
              <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
              </svg>
            </button>
          </div>
        </div>
        
        <div class="modal-body">
          <p style="margin: 0; color: #374151; line-height: 1.6;">
            Are you sure you want to delete <strong>"${networkName}"</strong> from the whitelist?
          </p>
          <p style="margin: 16px 0 0 0; color: #6b7280; font-size: 14px;">
            This action cannot be undone.
          </p>
        </div>
        
        <div class="modal-footer-modern">
          <button type="button" class="btn-modern btn-modern-secondary" onclick="this.closest('.modal-overlay').remove()">
            Cancel
          </button>
          <button type="button" class="btn-modern btn-modern-danger" onclick="confirmDelete(${index})">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
            </svg>
            Delete Network
          </button>
        </div>
      </div>
    `;
    
    document.body.appendChild(confirmDialog);
    
    // Close on overlay click
    confirmDialog.addEventListener('click', (e) => {
      if (e.target === confirmDialog) {
        confirmDialog.remove();
      }
    });
    
  } catch (error) {
    console.error('Error showing delete confirmation:', error);
    showToast('An error occurred while showing the confirmation dialog', 'error');
  }
}

function confirmDelete(index) {
  try {
    const entry = whitelistData[index];
    whitelistData.splice(index, 1);
    
    // Remove the confirmation dialog
    const dialog = document.querySelector('.modal-overlay');
    if (dialog) dialog.remove();
    
    renderWhitelistTable('whitelist-table-container');
    showToast(`Deleted network "${entry.name}" successfully`, 'success');
    
  } catch (error) {
    console.error('Error deleting whitelist entry:', error);
    showToast('An error occurred while deleting the network', 'error');
  }
}

function submitWhitelistForm(index = null) {
  try {
    const form = document.getElementById('whitelistForm');
    if (!form) {
      console.error('Whitelist form not found');
      return;
    }

    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const formData = new FormData(form);
    const entry = {
      name: formData.get('name'),
      location: formData.get('location'),
      status: formData.get('status'),
      priority: formData.get('priority'),
      mac: formData.get('mac'),
      addedDate: index === null ? new Date().toISOString().split('T')[0] : whitelistData[index].addedDate,
      lastUpdated: new Date().toISOString().split('T')[0]
    };

    if (index !== null) {
      whitelistData[index] = entry;
    } else {
      whitelistData.push(entry);
    }

    closeWhitelistModal();
    renderWhitelistTable('whitelist-table-container');

    // Show enhanced success message
    showToast(`${index !== null ? 'Updated' : 'Added'} network "${entry.name}" successfully`, 'success');
    
  } catch (error) {
    console.error('Error submitting whitelist form:', error);
    showToast('An error occurred while saving the network', 'error');
  }
}

function showToast(message, type = 'success') {
  // Remove existing toasts
  const existingToasts = document.querySelectorAll('.whitelist-toast');
  existingToasts.forEach(toast => toast.remove());
  
  const toast = document.createElement('div');
  toast.className = `whitelist-toast whitelist-toast-${type}`;
  
  const icon = type === 'success' ? 
    '<svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>' :
    '<svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
  
  toast.innerHTML = `
    <div class="toast-content">
      ${icon}
      <span>${message}</span>
    </div>
  `;
  
  // Add toast styles if not already added
  if (!document.getElementById('whitelist-toast-styles')) {
    const style = document.createElement('style');
    style.id = 'whitelist-toast-styles';
    style.innerHTML = `
      .whitelist-toast {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
      }
      
      @keyframes slideInRight {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
      
      .toast-content {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 16px 20px;
        border-radius: 12px;
        color: white;
        font-weight: 500;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        min-width: 300px;
      }
      
      .whitelist-toast-success .toast-content {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      }
      
      .whitelist-toast-error .toast-content {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
      }
      
      .whitelist-toast svg {
        flex-shrink: 0;
      }
    `;
    document.head.appendChild(style);
  }
  
  document.body.appendChild(toast);
  
  // Auto remove after 4 seconds
  setTimeout(() => {
    if (toast.parentNode) {
      toast.style.animation = 'slideOutRight 0.3s ease-in forwards';
      setTimeout(() => toast.remove(), 300);
    }
  }, 4000);
  
  // Add slide out animation
  if (!document.querySelector('#whitelist-toast-styles')) {
    const style = document.createElement('style');
    style.innerHTML = `
      @keyframes slideOutRight {
        from {
          transform: translateX(0);
          opacity: 1;
        }
        to {
          transform: translateX(100%);
          opacity: 0;
        }
      }
    `;
    document.head.appendChild(style);
  }
}

// Expose functions globally
window.renderWhitelistTable = renderWhitelistTable;
window.showWhitelistModal = showWhitelistModal;
window.closeWhitelistModal = closeWhitelistModal;
window.editWhitelistEntry = editWhitelistEntry;
window.deleteWhitelistEntry = deleteWhitelistEntry;
window.confirmDelete = confirmDelete;
window.submitWhitelistForm = submitWhitelistForm;
window.showToast = showToast;

// To use: call renderWhitelistTable('whitelist-table-container') where you want the table to appear. 
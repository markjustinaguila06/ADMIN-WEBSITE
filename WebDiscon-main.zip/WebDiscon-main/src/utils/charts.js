// Enhanced Charts Utility Functions for Interactive Dashboard
let charts = {};
let trendsSelectListenerAdded = false;
let chartClickHandlers = {};

console.log('Enhanced charts utility loading...');

// Generate sample data based on timeframe
function generateTrendData(timeframe) {
    const now = new Date();
    let labels = [];
    let dataPoints = 0;
    
    switch(timeframe) {
        case 'Last 30 Days':
            dataPoints = 30;
            for (let i = dataPoints - 1; i >= 0; i--) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            }
            break;
        case 'Last 90 Days':
            dataPoints = 90;
            for (let i = dataPoints - 1; i >= 0; i--) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            }
            break;
        default: // Last 7 Days
            dataPoints = 7;
            for (let i = dataPoints - 1; i >= 0; i--) {
                const date = new Date(now);
                date.setDate(date.getDate() - i);
                labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
            }
    }

    // Generate realistic-looking data with trends
    const generateDataset = (baseValue, variance, trend) => {
        return Array.from({ length: dataPoints }, (_, i) => {
            const randomFactor = Math.random() * variance;
            const trendFactor = (i / dataPoints) * trend;
            return Math.round(baseValue + randomFactor + trendFactor);
        });
    };

    return {
        labels,
        datasets: [
            {
                label: 'Verified Networks',
                data: generateDataset(65, 15, 10),
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 5
            },
            {
                label: 'Pending Verification',
                data: generateDataset(28, 20, -5),
                borderColor: '#f59e0b',
                backgroundColor: 'rgba(245, 158, 11, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 5
            },
            {
                label: 'Suspicious Activities',
                data: generateDataset(12, 8, 2),
                borderColor: '#ef4444',
                backgroundColor: 'rgba(239, 68, 68, 0.1)',
                borderWidth: 2,
                tension: 0.4,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 5
            }
        ]
    };
}

export function renderTrendsChart(timeframe = 'Last 7 Days') {
    const ctx = document.getElementById('detectionTrendsChart');
    if (!ctx) return;

    // Destroy existing chart if it exists
    if (charts.trends) {
        charts.trends.destroy();
    }

    const data = generateTrendData(timeframe);
    
    console.log(`Rendering interactive trends chart for: ${timeframe}`);

    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    right: 56 // More right padding
                }
            },
            interaction: {
                intersect: false,
                mode: 'index'
            },
            plugins: {
                legend: {
                    display: true,
                    position: 'bottom',
                    align: 'start',
                    labels: {
                        usePointStyle: false,
                        boxWidth: 40,
                        boxHeight: 2,
                        padding: 20,
                        color: '#64748b',
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(255, 255, 255, 0.9)',
                    titleColor: '#1e293b',
                    bodyColor: '#475569',
                    borderColor: '#e2e8f0',
                    borderWidth: 1,
                    padding: 10,
                    boxPadding: 4,
                    usePointStyle: true,
                    titleFont: { size: 12 },
                    bodyFont: { size: 12 },
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.parsed.y} networks`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#64748b',
                        maxRotation: 45,
                        minRotation: 45,
                        font: { size: 12 }
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#e2e8f0'
                    },
                    ticks: {
                        color: '#64748b',
                        font: { size: 12 },
                        callback: function(value) {
                            return value;
                        }
                    }
                }
            },
            animation: {
                duration: 1000,
                easing: 'easeInOutQuart'
            },
            onHover: (event, activeElements) => {
                ctx.style.cursor = activeElements.length > 0 ? 'pointer' : 'default';
            },
            onClick: (event, activeElements) => {
                if (activeElements.length > 0) {
                    const datasetIndex = activeElements[0].datasetIndex;
                    const dataIndex = activeElements[0].index;
                    const dataset = data.datasets[datasetIndex];
                    const label = data.labels[dataIndex];
                    const value = dataset.data[dataIndex];
                    
                    handleChartClick(dataset.label, label, value, timeframe);
                }
            }
        }
    };

    charts.trends = new Chart(ctx, config);
    
    // Add chart interaction feedback
    if (window.showToast) {
        window.showToast(`Detection trends chart updated for ${timeframe}`, 'info');
    }

    // Only add the event listener once
    const trendsSelect = document.getElementById('trendsSelect');
    if (trendsSelect && !trendsSelectListenerAdded) {
        trendsSelect.addEventListener('change', (e) => {
            renderTrendsChart(e.target.value);
        });
        trendsSelectListenerAdded = true;
    }
}

// Handle chart click interactions
function handleChartClick(datasetLabel, timeLabel, value, timeframe) {
    console.log(`Chart clicked: ${datasetLabel} on ${timeLabel} with value ${value}`);
    
    const actionMap = {
        'Verified Networks': () => {
            if (window.showToast) {
                window.showToast(`Showing ${value} verified networks for ${timeLabel}`, 'success');
            }
            setTimeout(() => {
                if (window.showSection) {
                    window.showSection('networks');
                }
            }, 1000);
        },
        'Pending Networks': () => {
            if (window.showToast) {
                window.showToast(`Showing ${value} pending networks for ${timeLabel}`, 'warning');
            }
            setTimeout(() => {
                if (window.showSection) {
                    window.showSection('networks');
                }
            }, 1000);
        },
        'Suspicious Activities': () => {
            if (window.showToast) {
                window.showToast(`Showing ${value} suspicious activities for ${timeLabel}`, 'error');
            }
            setTimeout(() => {
                if (window.showSection) {
                    window.showSection('threats');
                }
            }, 1000);
        }
    };
    
    const action = actionMap[datasetLabel];
    if (action) {
        action();
    } else {
        if (window.showToast) {
            window.showToast(`${datasetLabel}: ${value} on ${timeLabel}`, 'info');
        }
    }
}

// Enhanced chart animations and effects
function addChartAnimations() {
    // Add subtle glow effect to chart container
    const chartContainers = document.querySelectorAll('.chart-container');
    chartContainers.forEach(container => {
        container.addEventListener('mouseenter', () => {
            container.style.boxShadow = '0 8px 25px rgba(59, 130, 246, 0.15)';
            container.style.transform = 'translateY(-2px)';
            container.style.transition = 'all 0.3s ease';
        });
        
        container.addEventListener('mouseleave', () => {
            container.style.boxShadow = '';
            container.style.transform = 'translateY(0)';
        });
    });
}

// Initialize chart interactions
function initializeChartInteractions() {
    // Setup chart container animations
    setTimeout(addChartAnimations, 500);
    
    // Setup trends select enhancement
    const trendsSelect = document.getElementById('trendsSelect');
    if (trendsSelect) {
        trendsSelect.addEventListener('change', (e) => {
            const container = e.target.closest('.card');
            if (container) {
                container.style.opacity = '0.7';
                setTimeout(() => {
                    container.style.opacity = '1';
                }, 500);
            }
        });
    }
}

// Export functions
window.renderTrendsChart = renderTrendsChart;
window.handleChartClick = handleChartClick;
window.initializeChartInteractions = initializeChartInteractions;

// Initialize chart interactions when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeChartInteractions, 1500);
});

export function cleanupChart() {
    Object.values(charts).forEach(chart => {
        if (chart) {
            chart.destroy();
        }
    });
    charts = {};
} 
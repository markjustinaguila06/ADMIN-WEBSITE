// Enhanced Interactive Threat Activity System
// Modern threat monitoring with real-time detection and beautiful UI

console.log('Enhanced Threat Activity System loading...');

// Global threat state management
let threatState = {
    threats: [],
    filters: {
        severity: 'all',
        type: 'all',
        status: 'all',
        timeRange: '24h',
        search: ''
    },
    sorting: {
        field: 'timestamp',
        direction: 'desc'
    },
    pagination: {
        page: 1,
        itemsPerPage: 15
    },
    realTimeEnabled: true,
    selectedThreats: new Set()
};

// Enhanced threat data with realistic scenarios
const threatTypes = [
    'Evil Twin Attack',
    'Rogue Access Point',
    'Deauth Attack',
    'WPS Brute Force',
    'Suspicious Probe',
    'Man-in-the-Middle',
    'Captive Portal Attack',
    'DNS Spoofing',
    'Beacon Flooding',
    'Association Flooding'
];

const threatLocations = [
    { name: 'SM City Batangas', coords: [13.75, 121.05], area: 'Batangas' },
    { name: 'Ayala Malls Solenad', coords: [14.15, 121.25], area: 'Laguna' },
    { name: 'Robinson\'s Imus', coords: [14.43, 120.94], area: 'Cavite' },
    { name: 'Eastwood City', coords: [14.62, 121.30], area: 'Rizal' },
    { name: 'SM City Lucena', coords: [13.93, 121.61], area: 'Quezon' },
    { name: 'Festival Mall', coords: [14.17, 121.24], area: 'Laguna' },
    { name: 'Gateway Mall', coords: [14.65, 121.05], area: 'Rizal' }
];

// Initialize Enhanced Threat System
function initializeEnhancedThreats() {
    console.log('Initializing Enhanced Threat Activity System...');
    
    // Generate initial threat data
    generateInitialThreats();
    
    // Start real-time threat monitoring
    startRealTimeThreatMonitoring();
    
    // Setup threat event listeners
    setupThreatEventListeners();
    
    console.log('Enhanced Threat System initialized with', threatState.threats.length, 'threats');
}

// Generate realistic initial threat data
function generateInitialThreats() {
    const now = new Date();
    
    for (let i = 0; i < 25; i++) {
        const location = threatLocations[Math.floor(Math.random() * threatLocations.length)];
        const threatType = threatTypes[Math.floor(Math.random() * threatTypes.length)];
        const timestamp = new Date(now.getTime() - Math.random() * 24 * 60 * 60 * 1000);
        
        const threat = {
            id: `threat_${Date.now()}_${i}`,
            type: threatType,
            severity: Math.random() > 0.7 ? 'High' : Math.random() > 0.4 ? 'Medium' : 'Low',
            status: Math.random() > 0.8 ? 'Resolved' : Math.random() > 0.6 ? 'Investigating' : 'Active',
            timestamp: timestamp,
            location: location.name,
            area: location.area,
            coordinates: location.coords,
            ssid: generateRandomSSID(),
            bssid: generateRandomBSSID(),
            signal: Math.floor(Math.random() * 50) - 90,
            affectedDevices: Math.floor(Math.random() * 15) + 1,
            confidence: Math.floor(Math.random() * 30) + 70,
            description: generateThreatDescription(threatType),
            mitigation: generateMitigationSteps(threatType),
            forensics: generateForensicsData(),
            risk_score: Math.floor(Math.random() * 40) + 60
        };
        
        threatState.threats.push(threat);
    }
    
    // Sort by timestamp (newest first)
    threatState.threats.sort((a, b) => b.timestamp - a.timestamp);
}

// Generate random SSID
function generateRandomSSID() {
    const ssids = [
        'FREE_WIFI',
        'Public-WiFi',
        'Hotel_Guest',
        'Coffee_Shop',
        'DICT_WiFi',
        'Mall_WiFi',
        'Guest_Network',
        'OpenWifi',
        'HotSpot',
        'WiFi_Access'
    ];
    return ssids[Math.floor(Math.random() * ssids.length)];
}

// Generate random BSSID
function generateRandomBSSID() {
    return Array(6).fill(0)
        .map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0'))
        .join(':').toUpperCase();
}

// Generate threat descriptions
function generateThreatDescription(type) {
    const descriptions = {
        'Evil Twin Attack': 'Malicious access point mimicking legitimate network to steal credentials',
        'Rogue Access Point': 'Unauthorized wireless access point detected in secure area',
        'Deauth Attack': 'Deauthentication frames being sent to disconnect users',
        'WPS Brute Force': 'Multiple WPS PIN attempts detected from suspicious device',
        'Suspicious Probe': 'Device probing for multiple hidden networks',
        'Man-in-the-Middle': 'Traffic interception attempt detected',
        'Captive Portal Attack': 'Fake captive portal collecting user credentials',
        'DNS Spoofing': 'DNS responses being modified by malicious actor',
        'Beacon Flooding': 'Excessive beacon frames causing network disruption',
        'Association Flooding': 'Mass association requests overwhelming access point'
    };
    return descriptions[type] || 'Suspicious network activity detected';
}

// Generate mitigation steps
function generateMitigationSteps(type) {
    const steps = {
        'Evil Twin Attack': ['Block malicious BSSID', 'Alert users', 'Increase monitoring'],
        'Rogue Access Point': ['Locate physical device', 'Disable network', 'Investigate source'],
        'Deauth Attack': ['Enable 802.11w protection', 'Monitor source device', 'Block attacker'],
        'WPS Brute Force': ['Disable WPS', 'Block attacking device', 'Update security policy'],
        'Suspicious Probe': ['Monitor device behavior', 'Check device legitimacy', 'Possible blacklist'],
        'Man-in-the-Middle': ['Force HTTPS', 'Certificate pinning', 'Network segmentation'],
        'Captive Portal Attack': ['Block fake portal', 'User education', 'DNS filtering'],
        'DNS Spoofing': ['Secure DNS configuration', 'Monitor DNS traffic', 'Block malicious responses'],
        'Beacon Flooding': ['Rate limiting', 'Source identification', 'Signal jamming detection'],
        'Association Flooding': ['Connection rate limiting', 'Access control', 'DDoS protection']
    };
    return steps[type] || ['Investigate further', 'Monitor situation', 'Apply security measures'];
}

// Generate forensics data
function generateForensicsData() {
    return {
        packetCount: Math.floor(Math.random() * 1000) + 100,
        duration: Math.floor(Math.random() * 3600) + 60, // seconds
        protocols: ['802.11', 'TCP', 'UDP', 'HTTP', 'HTTPS'].filter(() => Math.random() > 0.5),
        sourceIP: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
        targetIPs: Array(Math.floor(Math.random() * 5) + 1).fill(0)
            .map(() => `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`)
    };
}

// Render Enhanced Threats Dashboard
function renderEnhancedThreats(containerId) {
    const container = document.getElementById(containerId);
    if (!container) {
        console.error('Threats container not found:', containerId);
        return;
    }
    
    const filteredThreats = getFilteredThreats();
    const paginatedThreats = getPaginatedThreats(filteredThreats);
    
    const html = `
        <div class="enhanced-threats-container">
            <!-- Header Section -->
            <div class="threats-header">
                <div class="threats-header-content">
                    <div class="threats-title-section">
                        <h1 class="threats-main-title">
                            <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                            </svg>
                            Threat Activity Center
                        </h1>
                        <p class="threats-subtitle">Real-time security monitoring and threat analysis</p>
                    </div>
                    
                    <div class="threats-status-section">
                        <div class="threat-status-card">
                            <div class="status-indicator ${threatState.realTimeEnabled ? 'active' : 'inactive'}"></div>
                            <div class="status-text">
                                <div class="status-label">${threatState.realTimeEnabled ? 'Live Monitoring' : 'Offline'}</div>
                                <div class="status-value">${threatState.threats.filter(t => t.status === 'Active').length} Active Threats</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Statistics Cards -->
                <div class="threats-stats-grid">
                    <div class="threat-stat-card high">
                        <div class="stat-icon">⚠️</div>
                        <div class="stat-content">
                            <div class="stat-value">${threatState.threats.filter(t => t.severity === 'High').length}</div>
                            <div class="stat-label">High Severity</div>
                        </div>
                    </div>
                    <div class="threat-stat-card medium">
                        <div class="stat-icon">🔶</div>
                        <div class="stat-content">
                            <div class="stat-value">${threatState.threats.filter(t => t.severity === 'Medium').length}</div>
                            <div class="stat-label">Medium Severity</div>
                        </div>
                    </div>
                    <div class="threat-stat-card low">
                        <div class="stat-icon">🔷</div>
                        <div class="stat-content">
                            <div class="stat-value">${threatState.threats.filter(t => t.severity === 'Low').length}</div>
                            <div class="stat-label">Low Severity</div>
                        </div>
                    </div>
                    <div class="threat-stat-card resolved">
                        <div class="stat-icon">✅</div>
                        <div class="stat-content">
                            <div class="stat-value">${threatState.threats.filter(t => t.status === 'Resolved').length}</div>
                            <div class="stat-label">Resolved</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Controls Section -->
            <div class="threats-controls">
                <div class="threats-search-section">
                    <div class="search-input-container">
                        <svg class="search-icon" width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                        <input type="text" class="threats-search-input" placeholder="🔍 Search threats by type, location, SSID..." id="threatsSearchInput">
                    </div>
                </div>
                
                <div class="threats-filters-section">
                    <select class="threat-filter-select" id="severityFilter">
                        <option value="all">All Severities</option>
                        <option value="High">High</option>
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                    </select>
                    
                    <select class="threat-filter-select" id="statusFilter">
                        <option value="all">All Status</option>
                        <option value="Active">Active</option>
                        <option value="Investigating">Investigating</option>
                        <option value="Resolved">Resolved</option>
                    </select>
                    
                    <select class="threat-filter-select" id="timeRangeFilter">
                        <option value="1h">Last Hour</option>
                        <option value="24h" selected>Last 24 Hours</option>
                        <option value="7d">Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                    </select>
                </div>
                
                <div class="threats-actions-section">
                    <button class="threat-action-btn primary" onclick="refreshThreatData()">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>
                        </svg>
                        Refresh
                    </button>
                    <button class="threat-action-btn secondary" onclick="exportThreatData()">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
                        </svg>
                        Export
                    </button>
                    <button class="threat-action-btn ${threatState.realTimeEnabled ? 'danger' : 'success'}" onclick="toggleRealTimeMonitoring()">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            ${threatState.realTimeEnabled ? 
                                '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"/>' :
                                '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-5-10V3a1 1 0 011-1h1a1 1 0 011 1v1M7 21h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v12a2 2 0 002 2z"/>'
                            }
                        </svg>
                        ${threatState.realTimeEnabled ? 'Stop Monitoring' : 'Start Monitoring'}
                    </button>
                </div>
            </div>
            
            <!-- Threats Table -->
            <div class="threats-table-container">
                <div class="threats-table-header">
                    <div class="table-info">
                        <span class="table-count">Showing ${paginatedThreats.length} of ${filteredThreats.length} threats</span>
                        <span class="table-updated">Last updated: ${new Date().toLocaleTimeString()}</span>
                    </div>
                    <div class="table-actions">
                        <button class="table-action-btn" onclick="selectAllThreats()">Select All</button>
                        <button class="table-action-btn" onclick="clearSelection()">Clear Selection</button>
                    </div>
                </div>
                
                <div class="threats-table-wrapper">
                    <table class="threats-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAllCheckbox" onchange="handleSelectAll()"></th>
                                <th class="sortable" data-sort="severity">Severity</th>
                                <th class="sortable" data-sort="type">Threat Type</th>
                                <th class="sortable" data-sort="timestamp">Time</th>
                                <th class="sortable" data-sort="location">Location</th>
                                <th class="sortable" data-sort="ssid">Network</th>
                                <th class="sortable" data-sort="status">Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${paginatedThreats.map(threat => createThreatRow(threat)).join('')}
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="threats-pagination">
                    <div class="pagination-info">
                        Page ${threatState.pagination.page} of ${Math.ceil(filteredThreats.length / threatState.pagination.itemsPerPage)}
                    </div>
                    <div class="pagination-controls">
                        <button class="pagination-btn" onclick="changePage(-1)" ${threatState.pagination.page === 1 ? 'disabled' : ''}>
                            Previous
                        </button>
                        <button class="pagination-btn" onclick="changePage(1)" ${threatState.pagination.page >= Math.ceil(filteredThreats.length / threatState.pagination.itemsPerPage) ? 'disabled' : ''}>
                            Next
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    container.innerHTML = html;
    setupThreatEventListeners();
}

// Create individual threat row
function createThreatRow(threat) {
    const timeAgo = getTimeAgo(threat.timestamp);
    const isSelected = threatState.selectedThreats.has(threat.id);
    
    return `
        <tr class="threat-row ${isSelected ? 'selected' : ''}" data-threat-id="${threat.id}">
            <td><input type="checkbox" class="threat-checkbox" data-threat-id="${threat.id}" ${isSelected ? 'checked' : ''}></td>
            <td>
                <span class="severity-badge ${threat.severity.toLowerCase()}">${threat.severity}</span>
            </td>
            <td>
                <div class="threat-type-cell">
                    <span class="threat-type">${threat.type}</span>
                    <span class="threat-confidence">${threat.confidence}% confidence</span>
                </div>
            </td>
            <td>
                <div class="time-cell">
                    <span class="time-ago">${timeAgo}</span>
                    <span class="full-time">${threat.timestamp.toLocaleString()}</span>
                </div>
            </td>
            <td>
                <div class="location-cell">
                    <span class="location-name">${threat.location}</span>
                    <span class="location-area">${threat.area}</span>
                </div>
            </td>
            <td>
                <div class="network-cell">
                    <span class="ssid">${threat.ssid}</span>
                    <span class="bssid">${threat.bssid}</span>
                </div>
            </td>
            <td>
                <span class="status-badge ${threat.status.toLowerCase().replace(' ', '-')}">${threat.status}</span>
            </td>
            <td>
                <div class="threat-actions">
                    <button class="action-btn view" onclick="viewThreatDetails('${threat.id}')" title="View Details">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                        </svg>
                    </button>
                    <button class="action-btn investigate" onclick="investigateThreat('${threat.id}')" title="Investigate">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16l2.879-2.879m0 0a3 3 0 104.243-4.242 3 3 0 00-4.243 4.242zM21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </button>
                    <button class="action-btn ${threat.status === 'Resolved' ? 'reopen' : 'resolve'}" onclick="resolveThreat('${threat.id}')" title="${threat.status === 'Resolved' ? 'Reopen' : 'Resolve'}">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            ${threat.status === 'Resolved' ? 
                                '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/>' :
                                '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>'
                            }
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
}

// Utility functions
function getTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
}

function getRiskLevel(score) {
    if (score >= 80) return 'high';
    if (score >= 60) return 'medium';
    return 'low';
}

function getFilteredThreats() {
    return threatState.threats.filter(threat => {
        // Apply all filters
        const matchesSeverity = threatState.filters.severity === 'all' || threat.severity === threatState.filters.severity;
        const matchesStatus = threatState.filters.status === 'all' || threat.status === threatState.filters.status;
        const matchesSearch = !threatState.filters.search || 
            threat.type.toLowerCase().includes(threatState.filters.search.toLowerCase()) ||
            threat.location.toLowerCase().includes(threatState.filters.search.toLowerCase()) ||
            threat.ssid.toLowerCase().includes(threatState.filters.search.toLowerCase());
        
        // Time range filter
        const now = new Date();
        let matchesTime = true;
        switch (threatState.filters.timeRange) {
            case '1h':
                matchesTime = (now - threat.timestamp) <= 3600000;
                break;
            case '24h':
                matchesTime = (now - threat.timestamp) <= 86400000;
                break;
            case '7d':
                matchesTime = (now - threat.timestamp) <= 604800000;
                break;
            case '30d':
                matchesTime = (now - threat.timestamp) <= 2592000000;
                break;
        }
        
        return matchesSeverity && matchesStatus && matchesSearch && matchesTime;
    });
}

function getPaginatedThreats(filteredThreats) {
    const start = (threatState.pagination.page - 1) * threatState.pagination.itemsPerPage;
    const end = start + threatState.pagination.itemsPerPage;
    return filteredThreats.slice(start, end);
}

// Global functions for threat management
window.refreshThreatData = function() {
    showThreatToast('Refreshing threat data...', 'info');
    // Simulate refresh
    setTimeout(() => {
        renderEnhancedThreats('threats-section');
        showThreatToast('Threat data refreshed successfully!', 'success');
    }, 1000);
};

window.exportThreatData = function() {
    const data = threatState.threats.map(threat => ({
        timestamp: threat.timestamp.toISOString(),
        type: threat.type,
        severity: threat.severity,
        status: threat.status,
        location: threat.location,
        ssid: threat.ssid,
        bssid: threat.bssid,
        risk_score: threat.risk_score,
        confidence: threat.confidence
    }));
    
    const csv = convertToCSV(data);
    downloadCSV(csv, `threats-${new Date().toISOString().split('T')[0]}.csv`);
    showThreatToast('Threat data exported successfully!', 'success');
};

window.toggleRealTimeMonitoring = function() {
    threatState.realTimeEnabled = !threatState.realTimeEnabled;
    renderEnhancedThreats('threats-section');
    showThreatToast(`Real-time monitoring ${threatState.realTimeEnabled ? 'enabled' : 'disabled'}`, 'info');
};

window.viewThreatDetails = function(threatId) {
    const threat = threatState.threats.find(t => t.id === threatId);
    if (!threat) return;
    
    showThreatDetailsModal(threat);
};

// Setup event listeners
function setupThreatEventListeners() {
    // Search input
    const searchInput = document.getElementById('threatsSearchInput');
    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                threatState.filters.search = e.target.value;
                threatState.pagination.page = 1;
                renderEnhancedThreats('threats-section');
            }, 300);
        });
    }
    
    // Filter selects
    ['severityFilter', 'statusFilter', 'timeRangeFilter'].forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', (e) => {
                const filterType = filterId.replace('Filter', '').replace('timeRange', 'timeRange');
                threatState.filters[filterType] = e.target.value;
                threatState.pagination.page = 1;
                renderEnhancedThreats('threats-section');
            });
        }
    });
}

// Real-time threat monitoring
function startRealTimeThreatMonitoring() {
    setInterval(() => {
        if (threatState.realTimeEnabled && Math.random() < 0.1) { // 10% chance every interval
            generateNewThreat();
        }
    }, 10000); // Check every 10 seconds
}

function generateNewThreat() {
    const location = threatLocations[Math.floor(Math.random() * threatLocations.length)];
    const threatType = threatTypes[Math.floor(Math.random() * threatTypes.length)];
    
    const newThreat = {
        id: `threat_${Date.now()}_${Math.random()}`,
        type: threatType,
        severity: Math.random() > 0.8 ? 'High' : Math.random() > 0.5 ? 'Medium' : 'Low',
        status: 'Active',
        timestamp: new Date(),
        location: location.name,
        area: location.area,
        coordinates: location.coords,
        ssid: generateRandomSSID(),
        bssid: generateRandomBSSID(),
        signal: Math.floor(Math.random() * 50) - 90,
        affectedDevices: Math.floor(Math.random() * 10) + 1,
        confidence: Math.floor(Math.random() * 30) + 70,
        description: generateThreatDescription(threatType),
        mitigation: generateMitigationSteps(threatType),
        forensics: generateForensicsData(),
        risk_score: Math.floor(Math.random() * 40) + 60
    };
    
    threatState.threats.unshift(newThreat);
    
    // Show notification for new high-severity threats
    if (newThreat.severity === 'High') {
        showThreatNotification(newThreat);
    }
    
    // Re-render if on threats page
    const threatsSection = document.getElementById('threats-section');
    if (threatsSection && threatsSection.style.display !== 'none') {
        renderEnhancedThreats('threats-section');
    }
}

function showThreatNotification(threat) {
    const notification = document.createElement('div');
    notification.className = 'threat-notification';
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #fee2e2 0%, #fef2f2 100%);
        border: 2px solid #ef4444;
        color: #dc2626;
        padding: 16px;
        border-radius: 12px;
        font-size: 14px;
        z-index: 1001;
        max-width: 350px;
        box-shadow: 0 8px 24px rgba(239, 68, 68, 0.3);
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    notification.innerHTML = `
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <div style="color: #ef4444;">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
            </div>
            <div>
                <div style="font-weight: 600; margin-bottom: 4px;">🚨 ${threat.severity} Threat Detected</div>
                <div style="font-size: 13px; margin-bottom: 2px;">${threat.type}</div>
                <div style="font-size: 12px; opacity: 0.8;">${threat.location} • ${threat.ssid}</div>
                <button onclick="this.parentElement.parentElement.parentElement.remove(); showSection('threats');" 
                        style="margin-top: 8px; background: #ef4444; color: white; border: none; padding: 4px 8px; border-radius: 4px; font-size: 12px; cursor: pointer;">
                    View Details
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 10 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 10000);
}

function showThreatToast(message, type = 'info') {
    const colors = {
        info: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' },
        success: { bg: '#d1fae5', border: '#10b981', text: '#065f46' },
        error: { bg: '#fee2e2', border: '#ef4444', text: '#dc2626' }
    };
    
    const color = colors[type] || colors.info;
    
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${color.bg};
        border: 2px solid ${color.border};
        color: ${color.text};
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 1003;
        opacity: 0;
        transform: translateY(100%);
        transition: all 0.3s ease;
    `;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 100);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(100%)';
        setTimeout(() => {
            if (toast.parentElement) {
                document.body.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

// Utility functions
function convertToCSV(data) {
    if (!data.length) return '';
    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => row[header]).join(','))
    ];
    return csvContent.join('\n');
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Initialize system
window.initializeEnhancedThreats = initializeEnhancedThreats;
window.renderEnhancedThreats = renderEnhancedThreats;

console.log('Enhanced Threat Activity System loaded successfully');


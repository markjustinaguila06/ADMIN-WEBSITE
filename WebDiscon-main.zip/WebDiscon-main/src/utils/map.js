// Enhanced Interactive Map Utility Functions
let dashboardMap = null;
let coverageMap = null;
let currentMarkers = new Map(); // Store current markers for better management
let activeProvinceHighlight = null;
let mapLayers = {
    verified: null,
    pending: null,
    suspicious: null,
    clusters: null
};
let isMapInteractive = false;

console.log('Enhanced interactive map utils loading...');

// Enhanced Interactive Map Controls
const MapControls = {
    createLegend: function(map) {
        const legend = L.control({ position: 'bottomright' });
        legend.onAdd = function() {
            const div = L.DomUtil.create('div', 'map-legend interactive-legend');
            div.innerHTML = `
                <div class="legend-title">Network Status</div>
                <div class="legend-item clickable" data-filter="verified" title="Click to toggle verified networks">
                    <div class="legend-marker verified"></div>
                    <div class="legend-label">Verified</div>
                    <div class="legend-count" id="verifiedCount">987</div>
                </div>
                <div class="legend-item clickable" data-filter="pending" title="Click to toggle pending networks">
                    <div class="legend-marker pending"></div>
                    <div class="legend-label">Pending</div>
                    <div class="legend-count" id="pendingCount">230</div>
                </div>
                <div class="legend-item clickable" data-filter="suspicious" title="Click to toggle suspicious networks">
                    <div class="legend-marker suspicious"></div>
                    <div class="legend-label">Suspicious</div>
                    <div class="legend-count" id="suspiciousCount">37</div>
                </div>
                <div class="legend-separator"></div>
                <div class="legend-item clickable" data-filter="signal-strong" title="Click to toggle strong signal networks">
                    <div class="legend-marker signal-strong"></div>
                    <div class="legend-label">Strong Signal</div>
                </div>
                <div class="legend-item clickable" data-filter="signal-weak" title="Click to toggle weak signal networks">
                    <div class="legend-marker signal-weak"></div>
                    <div class="legend-label">Weak Signal</div>
                </div>
            `;
            
            // Add click event listeners for interactive legend
            setTimeout(() => {
                const legendItems = div.querySelectorAll('.legend-item.clickable');
                legendItems.forEach(item => {
                    item.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const filter = item.dataset.filter;
                        toggleMapLayer(filter, item);
                    });
                    
                    item.addEventListener('mouseenter', () => {
                        item.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
                        item.style.cursor = 'pointer';
                    });
                    
                    item.addEventListener('mouseleave', () => {
                        item.style.backgroundColor = '';
                    });
                });
            }, 100);
            
            return div;
        };
        legend.addTo(map);
        return legend;
    },

    createScale: function(map) {
        L.control.scale({
            imperial: false,
            position: 'bottomleft'
        }).addTo(map);
    },

    createFullscreen: function(map) {
        if (L.control.fullscreen) {
            L.control.fullscreen({
                position: 'topright',
                title: {
                    'false': 'View Fullscreen',
                    'true': 'Exit Fullscreen'
                }
            }).addTo(map);
        }
    }
};

// Define CALABARZON bounds and provinces
const CALABARZON_BOUNDS = [
    [13.4, 120.5], // Southwest corner
    [14.8, 122.3]  // Northeast corner
];

const PROVINCES = [
    {
        name: 'Cavite',
        color: '#3b82f6',
        networks: 287,
        verified: 231,
        suspicious: 28,
        coverage: '76%',
        polygon: [
            [14.15, 120.75], [14.15, 121.00], [14.50, 121.00], [14.50, 120.75], [14.15, 120.75]
        ],
        center: [14.32, 120.88]
    },
    {
        name: 'Laguna',
        color: '#10b981',
        networks: 342,
        verified: 298,
        suspicious: 12,
        coverage: '82%',
        polygon: [
            [13.95, 121.05], [13.95, 121.60], [14.45, 121.60], [14.45, 121.05], [13.95, 121.05]
        ],
        center: [14.20, 121.33]
    },
    {
        name: 'Batangas',
        color: '#f59e0b',
        networks: 215,
        verified: 187,
        suspicious: 8,
        coverage: '68%',
        polygon: [
            [13.55, 120.55], [13.55, 121.35], [14.15, 121.35], [14.15, 120.55], [13.55, 120.55]
        ],
        center: [13.85, 120.95]
    },
    {
        name: 'Rizal',
        color: '#8b5cf6',
        networks: 263,
        verified: 209,
        suspicious: 9,
        coverage: '73%',
        polygon: [
            [14.45, 121.05], [14.45, 121.55], [14.80, 121.55], [14.80, 121.05], [14.45, 121.05]
        ],
        center: [14.62, 121.30]
    },
    {
        name: 'Quezon',
        color: '#ec4899',
        networks: 147,
        verified: 62,
        suspicious: 3,
        coverage: '42%',
        polygon: [
            [13.60, 121.25], [13.60, 122.25], [14.40, 122.25], [14.40, 121.25], [13.60, 121.25]
        ],
        center: [14.00, 121.75]
    }
];

// Enhanced comprehensive access points data
const ACCESS_POINTS = [
    // Verified Networks - Cavite
    {
        id: 'ap_001',
        name: 'SM Molino Town Center',
        ssid: 'SM_Molino_Free_WiFi',
        location: [14.42, 120.96],
        signal: -62,
        status: 'verified',
        province: 'Cavite',
        devices: 125,
        lastSeen: '1 min ago',
        bssid: '00:1B:2F:A2:C5:12',
        frequency: '2.4 GHz',
        security: 'WPA2-PSK'
    },
    {
        id: 'ap_002',
        name: 'Robinsons Imus',
        ssid: 'Robinsons_Imus_WiFi',
        location: [14.43, 120.94],
        signal: -68,
        status: 'verified',
        province: 'Cavite',
        devices: 89,
        lastSeen: '3 min ago',
        bssid: '00:1D:7E:B4:C6:23',
        frequency: '5 GHz',
        security: 'WPA2-PSK'
    },
    
    // Verified Networks - Laguna
    {
        id: 'ap_003',
        name: 'Ayala Malls Solenad',
        ssid: 'Solenad_Guest_WiFi',
        location: [14.15, 121.25],
        signal: -55,
        status: 'verified',
        province: 'Laguna',
        devices: 156,
        lastSeen: '2 min ago',
        bssid: '00:2A:3B:C7:D8:34',
        frequency: '5 GHz',
        security: 'WPA3-PSK'
    },
    {
        id: 'ap_004',
        name: 'SM Center Sta. Rosa',
        ssid: 'SM_SantaRosa_Free',
        location: [14.31, 121.10],
        signal: -60,
        status: 'verified',
        province: 'Laguna',
        devices: 134,
        lastSeen: '4 min ago',
        bssid: '00:3C:4D:E9:F0:45',
        frequency: '2.4 GHz',
        security: 'WPA2-PSK'
    },
    
    // Verified Networks - Batangas
    {
        id: 'ap_005',
        name: 'SM City Lipa',
        ssid: 'SM_Lipa_Guest',
        location: [13.94, 121.17],
        signal: -64,
        status: 'verified',
        province: 'Batangas',
        devices: 98,
        lastSeen: '2 min ago',
        bssid: '00:4E:5F:A1:B2:56',
        frequency: '5 GHz',
        security: 'WPA2-PSK'
    },
    {
        id: 'ap_006',
        name: 'Robinsons Place Lipa',
        ssid: 'RPL_Free_WiFi',
        location: [13.95, 121.15],
        signal: -67,
        status: 'verified',
        province: 'Batangas',
        devices: 76,
        lastSeen: '5 min ago',
        bssid: '00:5F:60:C3:D4:67',
        frequency: '2.4 GHz',
        security: 'WPA2-PSK'
    },
    
    // Pending Networks
    {
        id: 'ap_007',
        name: 'Local Coffee Shop',
        ssid: 'CoffeeShop_Guest',
        location: [14.20, 121.20],
        signal: -72,
        status: 'pending',
        province: 'Laguna',
        devices: 23,
        lastSeen: '8 min ago',
        bssid: '00:71:82:E5:F6:78',
        frequency: '2.4 GHz',
        security: 'WPA2-PSK'
    },
    {
        id: 'ap_008',
        name: 'University Network',
        ssid: 'UPLB_Student_WiFi',
        location: [14.17, 121.24],
        signal: -69,
        status: 'pending',
        province: 'Laguna',
        devices: 45,
        lastSeen: '12 min ago',
        bssid: '00:83:94:A7:B8:89',
        frequency: '5 GHz',
        security: 'WPA2-Enterprise'
    },
    
    // Suspicious Networks
    {
        id: 'ap_009',
        name: 'Evil Twin Network',
        ssid: 'SM_Molino_Free_WiFi',
        location: [14.41, 120.97],
        signal: -85,
        status: 'suspicious',
        province: 'Cavite',
        devices: 5,
        lastSeen: '15 min ago',
        bssid: '00:95:A6:C9:DA:9A',
        frequency: '2.4 GHz',
        security: 'Open',
        threat: 'Evil Twin Attack'
    },
    {
        id: 'ap_010',
        name: 'Rogue Access Point',
        ssid: 'Free_WiFi_Here',
        location: [14.30, 121.30],
        signal: -78,
        status: 'suspicious',
        province: 'Rizal',
        devices: 8,
        lastSeen: '20 min ago',
        bssid: '00:A7:B8:DB:EC:AB',
        frequency: '2.4 GHz',
        security: 'Open',
        threat: 'Rogue AP'
    },
    {
        id: 'ap_011',
        name: 'Suspicious Hotspot',
        ssid: 'Public-WiFi',
        location: [13.85, 121.05],
        signal: -82,
        status: 'suspicious',
        province: 'Batangas',
        devices: 3,
        lastSeen: '25 min ago',
        bssid: '00:B9:CA:ED:FE:BC',
        frequency: '2.4 GHz',
        security: 'WEP',
        threat: 'Weak Security'
    }
];

// Interactive layer toggle functionality
function toggleMapLayer(filter, legendItem) {
    console.log(`Toggling layer: ${filter}`);
    
    const currentMap = dashboardMap || coverageMap;
    if (!currentMap) return;
    
    const isActive = legendItem.classList.contains('active');
    
    if (isActive) {
        // Hide layer
        legendItem.classList.remove('active');
        legendItem.style.opacity = '0.5';
        hideAccessPointsByStatus(filter);
        showToast(`${filter} networks hidden`, 'info');
    } else {
        // Show layer
        legendItem.classList.add('active');
        legendItem.style.opacity = '1';
        showAccessPointsByStatus(filter);
        showToast(`${filter} networks shown`, 'success');
    }
}

// Show access points by status
function showAccessPointsByStatus(status) {
    const filteredAPs = ACCESS_POINTS.filter(ap => {
        if (status === 'signal-strong') return ap.signal > -70;
        if (status === 'signal-weak') return ap.signal <= -70;
        return ap.status === status;
    });
    
    filteredAPs.forEach(ap => {
        if (currentMarkers.has(ap.id)) {
            const marker = currentMarkers.get(ap.id);
            marker.addTo(dashboardMap || coverageMap);
        }
    });
}

// Hide access points by status
function hideAccessPointsByStatus(status) {
    const filteredAPs = ACCESS_POINTS.filter(ap => {
        if (status === 'signal-strong') return ap.signal > -70;
        if (status === 'signal-weak') return ap.signal <= -70;
        return ap.status === status;
    });
    
    filteredAPs.forEach(ap => {
        if (currentMarkers.has(ap.id)) {
            const marker = currentMarkers.get(ap.id);
            const currentMap = dashboardMap || coverageMap;
            if (currentMap && currentMap.hasLayer(marker)) {
                currentMap.removeLayer(marker);
            }
        }
    });
}

// Enhanced access point popup content
function createAPPopupContent(ap) {
    const signalStrength = getSignalStrength(ap.signal);
    const statusColor = getStatusColor(ap.status);
    const securityIcon = getSecurityIcon(ap.security);
    
    return `
        <div class="ap-popup">
            <div class="ap-popup-header">
                <div class="ap-name">${ap.name}</div>
                <div class="ap-status ${ap.status}" style="background: ${statusColor};">
                    ${ap.status.toUpperCase()}
                </div>
            </div>
            <div class="ap-popup-content">
                <div class="ap-detail">
                    <span class="ap-label">SSID:</span>
                    <span class="ap-value">${ap.ssid}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">BSSID:</span>
                    <span class="ap-value">${ap.bssid}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Signal:</span>
                    <span class="ap-value">${ap.signal} dBm (${signalStrength})</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Frequency:</span>
                    <span class="ap-value">${ap.frequency}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Security:</span>
                    <span class="ap-value">${securityIcon} ${ap.security}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Connected Devices:</span>
                    <span class="ap-value">${ap.devices}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Last Seen:</span>
                    <span class="ap-value">${ap.lastSeen}</span>
                </div>
                <div class="ap-detail">
                    <span class="ap-label">Province:</span>
                    <span class="ap-value">${ap.province}</span>
                </div>
                ${ap.threat ? `
                    <div class="ap-threat">
                        <span class="ap-label">⚠️ Threat:</span>
                        <span class="ap-value threat">${ap.threat}</span>
                    </div>
                ` : ''}
            </div>
            <div class="ap-popup-actions">
                <button onclick="viewAPDetails('${ap.id}')" class="ap-action-btn primary">
                    View Details
                </button>
                ${ap.status === 'suspicious' ? `
                    <button onclick="blockAP('${ap.id}')" class="ap-action-btn danger">
                        Block Network
                    </button>
                ` : ''}
                ${ap.status === 'pending' ? `
                    <button onclick="verifyAP('${ap.id}')" class="ap-action-btn success">
                        Verify Network
                    </button>
                ` : ''}
            </div>
        </div>
    `;
}

// Helper functions for popup content
function getSignalStrength(signal) {
    if (signal > -50) return 'Excellent';
    if (signal > -60) return 'Good';
    if (signal > -70) return 'Fair';
    return 'Poor';
}

function getStatusColor(status) {
    const colors = {
        verified: '#10b981',
        pending: '#f59e0b', 
        suspicious: '#ef4444'
    };
    return colors[status] || '#6b7280';
}

function getSecurityIcon(security) {
    if (security.includes('WPA3')) return '🔒';
    if (security.includes('WPA2')) return '🔒';
    if (security.includes('WEP')) return '⚠️';
    if (security === 'Open') return '🔓';
    return '🔒';
}

// Enhanced province polygon styling
function getProvinceStyle(province, isHighlighted = false) {
    const baseStyle = {
        color: province.color,
        weight: isHighlighted ? 4 : 2,
        opacity: isHighlighted ? 1 : 0.8,
        fillOpacity: isHighlighted ? 0.4 : 0.15,
        fillColor: province.color,
        dashArray: isHighlighted ? null : '5, 5'
    };
    
    return baseStyle;
}

// Initialize map with enhanced functionality - IDENTICAL for both dashboard and coverage maps
export function initializeMap(containerId) {
    try {
        console.log(`Initializing map for container: ${containerId}`);
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`Container ${containerId} not found`);
            return null;
        }

        // Clear existing map instance if it exists
        if (containerId === 'dashboardMap' && dashboardMap) {
            dashboardMap.remove();
            dashboardMap = null;
            console.log('Cleared existing dashboard map');
        } else if (containerId === 'coverageMap' && coverageMap) {
            coverageMap.remove();
            coverageMap = null;
            console.log('Cleared existing coverage map');
        }

        // Create map with enhanced configuration - IDENTICAL for both maps
        const map = L.map(containerId, {
            center: [14.2, 121.2], // Center of CALABARZON
            zoom: 9,
            zoomControl: false,
            attributionControl: true,
            maxBounds: CALABARZON_BOUNDS,
            maxBoundsViscosity: 1.0,
            minZoom: containerId === 'coverageMap' ? 10 : 9, // More restrictive zoom out for both maps
            maxZoom: 16,
            zoomAnimation: true,
            fadeAnimation: true,
            markerZoomAnimation: true
        });

        // Add OpenStreetMap tiles - IDENTICAL for both maps
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 16
        }).addTo(map);

        // Add custom controls - IDENTICAL for both maps
        MapControls.createScale(map);

        // Add ALL features to BOTH maps - NO DIFFERENCES
        console.log('Adding province boundaries with full functionality...');
        PROVINCES.forEach(province => {
            // First add subtle coverage polygons to BOTH maps - BEHIND main polygons
            const coveragePolygon = L.polygon(province.polygon, {
                color: province.color,
                weight: 1,
                opacity: 0.2,
                fillOpacity: 0.02,
                className: 'coverage-polygon',
                dashArray: '15, 10',
                interactive: false, // Make this non-interactive so clicks pass through
                pane: 'overlayPane'
            }).addTo(map);

            // Create MAIN province boundary polygon with CLICKABLE styling
            const polygon = L.polygon(province.polygon, {
                ...getProvinceStyle(province),
                interactive: true, // Ensure this is clickable
                bubblingMouseEvents: false, // Prevent event conflicts
                pane: 'overlayPane'
            }).addTo(map);

            // Add province label with enhanced styling - IDENTICAL for both
            const labelIcon = L.divIcon({
                className: 'province-label clickable',
                html: `<div style="
                    color: ${province.color}; 
                    font-weight: bold; 
                    font-size: 14px;
                    text-shadow: 2px 2px 4px rgba(255,255,255,0.8);
                    padding: 4px 8px;
                    background: rgba(255,255,255,0.9);
                    border-radius: 4px;
                    border: 1px solid ${province.color};
                    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                    cursor: pointer;
                    transition: all 0.2s ease;
                ">${province.name}</div>`,
                iconSize: [120, 30],
                iconAnchor: [60, 15]
            });
            
            const provinceLabel = L.marker(province.center, { 
                icon: labelIcon,
                interactive: true,
                riseOnHover: true
            }).addTo(map);

            // Add coverage percentage label to BOTH maps - OFFSET to avoid overlap
            const coverageLabel = L.marker([province.center[0] - 0.08, province.center[1]], {
                icon: L.divIcon({
                    className: 'coverage-label',
                    html: `<div style="
                        background: ${province.color};
                        color: white;
                        padding: 2px 6px;
                        border-radius: 12px;
                        font-size: 11px;
                        font-weight: bold;
                        box-shadow: 0 1px 3px rgba(0,0,0,0.3);
                        text-align: center;
                        pointer-events: none;
                    ">${province.coverage}</div>`,
                    iconSize: [40, 20],
                    iconAnchor: [20, 10]
                }),
                interactive: false // Make coverage label non-interactive
            }).addTo(map);

            // Enhanced hover effects for MAIN polygon - IDENTICAL for both
            polygon.on('mouseover', function(e) {
                console.log(`Province hovered: ${province.name}`);
                this.setStyle({
                    fillOpacity: 0.3,
                    weight: 3,
                    dashArray: null,
                    color: province.color
                });
                // Removed hover tooltip to avoid duplicate white bubble under popup
            });

            polygon.on('mouseout', function(e) {
                this.setStyle(getProvinceStyle(province));
                // No tooltip to close
            });

            // Enhanced click event for MAIN polygon - IDENTICAL for both maps
            polygon.on('click', function(e) {
                console.log(`Province clicked: ${province.name} in ${containerId}`);
                
                // Prevent event bubbling immediately
                L.DomEvent.stopPropagation(e);
                L.DomEvent.preventDefault(e);
                
                // Visual feedback - flash the province
                this.setStyle({
                    fillOpacity: 0.6,
                    weight: 4,
                    color: '#ffffff'
                });
                
                setTimeout(() => {
                    this.setStyle(getProvinceStyle(province));
                }, 200);
                
                // Remove previous highlight if exists
                if (activeProvinceHighlight && map.hasLayer(activeProvinceHighlight)) {
                    map.removeLayer(activeProvinceHighlight);
                }

                // Create new highlight with enhanced styling
                activeProvinceHighlight = L.polygon(province.polygon, {
                    color: province.color,
                    weight: 5,
                    opacity: 1,
                    fillOpacity: 0.5,
                    fillColor: province.color,
                    dashArray: null,
                    className: 'province-highlight',
                    interactive: false
                }).addTo(map);

                // Enhanced popup with IDENTICAL detailed information
                const popupContent = `
                    <div class="province-popup enhanced">
                        <h3 style="color: ${province.color}; margin: 0 0 12px 0; font-size: 18px;">
                            🏛️ ${province.name} Province
                        </h3>
                        <div class="province-stats">
                            <div class="stat-row">
                                <span class="stat-label">Total Networks:</span>
                                <span class="stat-value">${province.networks}</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label">Verified:</span>
                                <span class="stat-value verified">✅ ${province.verified}</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label">Suspicious:</span>
                                <span class="stat-value suspicious">⚠️ ${province.suspicious}</span>
                            </div>
                            <div class="stat-row">
                                <span class="stat-label">Coverage:</span>
                                <span class="stat-value coverage">📶 ${province.coverage}</span>
                            </div>
                        </div>
                        <div style="margin-top: 12px; display: flex; gap: 8px; flex-wrap: wrap;">
                            <button onclick="showProvinceDetails('${province.name}')" 
                                    style="padding: 6px 12px; background: ${province.color}; 
                                    color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;
                                    transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
                                    onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.2)'"
                                    onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0,0,0,0.1)'">
                                📊 View Details
                            </button>
                            <button onclick="showProvinceNetworks('${province.name}')" 
                                    style="padding: 6px 12px; background: #6b7280; 
                                    color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;
                                    transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
                                    onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.2)'"
                                    onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0,0,0,0.1)'">
                                📡 Show Networks
                            </button>
                            <button onclick="exportProvinceData('${province.name}')" 
                                    style="padding: 6px 12px; background: #059669; 
                                    color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;
                                    transition: all 0.2s; box-shadow: 0 2px 4px rgba(0,0,0,0.1);"
                                    onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.2)'"
                                    onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0,0,0,0.1)'">
                                💾 Export Data
                            </button>
                        </div>
                    </div>
                `;

                activeProvinceHighlight.bindPopup(popupContent, {
                    maxWidth: 350,
                    className: 'province-popup-container'
                }).openPopup();

                // Center map on the province with smooth animation - IDENTICAL
                map.fitBounds(polygon.getBounds(), { 
                    padding: [50, 50],
                    animation: true,
                    duration: 0.5
                });
            });

            // Also make the province LABEL clickable
            provinceLabel.on('click', function(e) {
                console.log(`Province label clicked: ${province.name}`);
                L.DomEvent.stopPropagation(e);
                
                // Trigger the same click event as the polygon
                polygon.fire('click', e);
            });

            // Store polygon reference for later use
            polygon.provinceData = province;
            polygon.provinceName = province.name; // Add name for easier debugging
        });

        // Add access points to BOTH maps - IDENTICAL functionality
        console.log('Adding access points with full functionality...');
        ACCESS_POINTS.forEach(ap => {
            try {
                const marker = createAccessPointMarker(ap, map);
                currentMarkers.set(ap.id, marker);
            } catch (error) {
                console.error(`Error creating marker for ${ap.name}:`, error);
            }
        });

        // Initialize search functionality - IDENTICAL for both
        initializeSearch(map, containerId);

        // Store map instance
        if (containerId === 'dashboardMap') {
            dashboardMap = map;
            console.log('Dashboard map initialized with FULL functionality');
        } else if (containerId === 'coverageMap') {
            coverageMap = map;
            console.log('Coverage map initialized with FULL functionality');
        }

        // Add zoom controls - IDENTICAL for both
        setupZoomControls(map, containerId);

        // Set initial view to CALABARZON bounds - IDENTICAL
        map.fitBounds(CALABARZON_BOUNDS);

        // Add map interaction feedback and zoom restrictions
        map.on('zoomstart', () => {
            console.log(`${containerId} zoom started`);
        });

        map.on('zoomend', () => {
            console.log(`${containerId} zoom level: ${map.getZoom()}`);
            
            // Additional visual feedback for both maps zoom restrictions
            const currentZoomLevel = map.getZoom();
            const mapMinZoom = map.getMinZoom();
            const zoomOutBtnId = containerId === 'coverageMap' ? 'coverageZoomOut' : 'dashboardZoomOut';
            const zoomOutButton = document.getElementById(zoomOutBtnId);
            
            if (zoomOutButton) {
                if (currentZoomLevel <= mapMinZoom) {
                    zoomOutButton.style.opacity = '0.5';
                    zoomOutButton.style.cursor = 'not-allowed';
                    zoomOutButton.title = 'Maximum zoom out reached';
                } else {
                    zoomOutButton.style.opacity = '';
                    zoomOutButton.style.cursor = '';
                    zoomOutButton.title = 'Zoom out';
                }
            }
        });
        
        // Add wheel zoom restrictions for both maps
        map.on('zoom', (e) => {
            const currentZoomValue = map.getZoom();
            const minZoomValue = map.getMinZoom();
            
            // Prevent further zoom out if at minimum level
            if (currentZoomValue < minZoomValue) {
                map.setZoom(minZoomValue);
            }
        });

        console.log(`${containerId} initialized with ALL features: clickable provinces, access points, search, coverage labels, and full interactivity`);
        return map;
    } catch (error) {
        console.error('Error initializing map:', error);
        return null;
    }
}

// Enhanced zoom controls setup
function setupZoomControls(map, containerId) {
    const zoomInBtn = document.getElementById(containerId === 'dashboardMap' ? 'dashboardZoomIn' : 'coverageZoomIn');
    const zoomOutBtn = document.getElementById(containerId === 'dashboardMap' ? 'dashboardZoomOut' : 'coverageZoomOut');
    
    if (zoomInBtn) {
        // Remove existing listeners
        const newZoomInBtn = zoomInBtn.cloneNode(true);
        zoomInBtn.parentNode.replaceChild(newZoomInBtn, zoomInBtn);
        
        newZoomInBtn.addEventListener('click', (e) => {
            e.preventDefault();
            map.zoomIn();
            console.log(`${containerId} zoomed in to level: ${map.getZoom()}`);
        });
    }
    
    if (zoomOutBtn) {
        // Remove existing listeners
        const newZoomOutBtn = zoomOutBtn.cloneNode(true);
        zoomOutBtn.parentNode.replaceChild(newZoomOutBtn, zoomOutBtn);
        
        newZoomOutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            
            // Additional zoom out restrictions for both maps
            const currentZoom = map.getZoom();
            const minZoom = map.getMinZoom();
            
            if (currentZoom <= minZoom) {
                // Add visual feedback when zoom limit is reached
                newZoomOutBtn.style.opacity = '0.5';
                newZoomOutBtn.style.cursor = 'not-allowed';
                
                // Show temporary tooltip
                const tooltip = document.createElement('div');
                tooltip.textContent = 'Maximum zoom out reached';
                tooltip.style.cssText = `
                    position: absolute;
                    background: rgba(0,0,0,0.8);
                    color: white;
                    padding: 6px 12px;
                    border-radius: 4px;
                    font-size: 12px;
                    pointer-events: none;
                    z-index: 10000;
                    bottom: 60px;
                    right: 0;
                    white-space: nowrap;
                `;
                newZoomOutBtn.parentElement.appendChild(tooltip);
                
                setTimeout(() => {
                    newZoomOutBtn.style.opacity = '';
                    newZoomOutBtn.style.cursor = '';
                    if (tooltip.parentElement) {
                        tooltip.parentElement.removeChild(tooltip);
                    }
                }, 2000);
                
                console.log(`${containerId} zoom out restricted - at minimum zoom level: ${currentZoom}`);
                return;
            }
            
            map.zoomOut();
            console.log(`${containerId} zoomed out to level: ${map.getZoom()}`);
            
            // Update button state for both maps
            const newZoomLevel = map.getZoom();
            const minZoomLevel = map.getMinZoom();
            if (newZoomLevel <= minZoomLevel) {
                newZoomOutBtn.style.opacity = '0.5';
                setTimeout(() => {
                    newZoomOutBtn.style.opacity = '';
                }, 1000);
            }
        });
    }
}

// Initialize coverage map with IDENTICAL features (no additional features)
export function initializeCoverageMap() {
    console.log('Initializing coverage map with IDENTICAL functionality to dashboard map...');
    const map = initializeMap('coverageMap');
    // Remove the addCoverageLayers call - all features are now in initializeMap
    if (map) {
        console.log('Coverage map initialized with SAME features as dashboard map');
    }
    return map;
}

// Enhanced access point marker creation
function createAccessPointMarker(ap, map) {
    try {
        const signalStrength = Math.abs(ap.signal);
        const signalClass = signalStrength < 70 ? 'signal-strong' : 'signal-weak';
        const statusClass = ap.status === 'verified' ? 'verified' : ap.status === 'suspicious' ? 'suspicious' : 'pending';
        
        const markerIcon = L.divIcon({
            className: `access-point-marker ${signalClass} ${statusClass}`,
            html: `
                <div class="marker-pulse ${statusClass}"></div>
                <div class="marker-core"></div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });
        
        const marker = L.marker(ap.location, { icon: markerIcon }).addTo(map);

        // Enhanced popup with comprehensive information
        const popupContent = createAPPopupContent(ap);

        marker.bindPopup(popupContent, {
            maxWidth: 400,
            minWidth: 350,
            className: 'network-popup-container'
        });

        // Add optimized hover behavior with small delay to prevent jitter
        if (window.innerWidth > 768) {
            let hoverTimer = null;
            marker.on('mouseover', function() {
                // Delay opening to avoid flicker when cursor passes over markers
                hoverTimer = setTimeout(() => {
                    if (marker && marker.openPopup) {
                        marker.openPopup();
                    }
                }, 180);
            });
            marker.on('mouseout', function() {
                if (hoverTimer) {
                    clearTimeout(hoverTimer);
                    hoverTimer = null;
                }
            });
        }

        return marker;
    } catch (error) {
        console.error('Error creating access point marker:', error);
        return null;
    }
}

// Enhanced search functionality
function initializeSearch(map, containerId) {
    const searchInput = document.getElementById(
        containerId === 'dashboardMap' ? 'dashboardMapSearchInput' : 'coverageMapSearchInput'
    );
    
    if (!searchInput) {
        console.warn(`Search input not found for ${containerId}`);
        return;
    }

    console.log(`Initializing search for ${containerId}`);

    // Remove any existing event listeners
    const newSearchInput = searchInput.cloneNode(true);
    searchInput.parentNode.replaceChild(newSearchInput, searchInput);

    // Add enhanced search functionality with debouncing
    let searchTimeout;
    
    newSearchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            const searchTerm = newSearchInput.value.trim().toLowerCase();
            if (!searchTerm) return;

            console.log(`Searching for: ${searchTerm} in ${containerId}`);
            try {
                performSearch(map, searchTerm);
            } catch (error) {
                console.error('Search error:', error);
            }
        }
    });

    // Add debounced search suggestions on input
    newSearchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        const searchTerm = e.target.value.trim().toLowerCase();
        
        if (searchTerm.length > 2) {
            searchTimeout = setTimeout(() => {
                try {
                    showSearchSuggestions(searchTerm, containerId);
                } catch (error) {
                    console.error('Search suggestions error:', error);
                }
            }, 300); // 300ms debounce
        }
    });
}

// Enhanced search function - prioritizing WiFi access points
function performSearch(map, searchTerm) {
    try {
        // Clear previous highlights
        if (activeProvinceHighlight && map.hasLayer(activeProvinceHighlight)) {
            map.removeLayer(activeProvinceHighlight);
            activeProvinceHighlight = null;
        }

        // Clear previous access point highlights
        currentMarkers.forEach((marker, id) => {
            try {
                const element = marker.getElement && marker.getElement();
                if (element && element.classList) {
                    element.classList.remove('search-highlight-marker');
                }
            } catch (error) {
                console.warn(`Could not clear highlight for marker ${id}:`, error);
            }
        });

        // Find matching access points (primary search target)
        const matchingAPs = ACCESS_POINTS.filter(ap => 
            ap.name.toLowerCase().includes(searchTerm) ||
            ap.ssid.toLowerCase().includes(searchTerm) ||
            ap.location?.toLowerCase().includes(searchTerm) ||
            ap.province.toLowerCase().includes(searchTerm) ||
            ap.bssid?.toLowerCase().includes(searchTerm)
        );

        // Find matching province (secondary fallback)
        const province = PROVINCES.find(p => 
            p.name.toLowerCase() === searchTerm || 
            p.name.toLowerCase().includes(searchTerm)
        );

        // Prioritize WiFi access points over provinces
        if (matchingAPs.length > 0) {
            console.log(`Found ${matchingAPs.length} matching WiFi access points`);
            
            // Show first matching access point and zoom to it
            const firstAP = matchingAPs[0];
            const firstMarker = currentMarkers.get(firstAP.id);
            
            if (firstMarker) {
                // Zoom to the first access point
                map.setView([firstAP.lat, firstAP.lng], 15, {
                    animate: true,
                    duration: 1.0
                });
                
                // Open popup for the first result
                setTimeout(() => {
                    firstMarker.openPopup();
                }, 500);
            }
            
            // Highlight all matching access points
            matchingAPs.forEach((ap, index) => {
                try {
                    const marker = currentMarkers.get(ap.id);
                    if (marker && marker.getElement) {
                        // Add pulse animation with safety check
                        const element = marker.getElement();
                        if (element) {
                            element.classList.add('search-highlight-marker');
                            
                            // Open popup for first result after animation
                            if (index === 0) {
                                setTimeout(() => {
                                    if (marker.openPopup) {
                                        marker.openPopup();
                                    }
                                }, 1000);
                            }
                            
                            // Remove highlight after 5 seconds
                            setTimeout(() => {
                                const currentElement = marker.getElement();
                                if (currentElement && currentElement.classList) {
                                    currentElement.classList.remove('search-highlight-marker');
                                }
                            }, 5000);
                        }
                    }
                } catch (error) {
                    console.error(`Error highlighting marker for ${ap.name}:`, error);
                }
            });
            
            // Show summary popup if multiple results
            if (matchingAPs.length > 1) {
                setTimeout(() => {
                    const center = map.getCenter();
                    map.openPopup(`
                        <div class="wifi-search-results">
                            <h4>🔍 WiFi Search Results</h4>
                            <p>Found <strong>${matchingAPs.length}</strong> access points matching "${searchTerm}"</p>
                            <p>📍 Zoomed to: <strong>${firstAP.name || firstAP.ssid}</strong></p>
                            <p><em>Click markers to see details</em></p>
                        </div>
                    `, center);
                }, 2000);
            }
        } else if (province) {
            // Fallback to province search if no WiFi access points found
            console.log(`No WiFi access points found, showing province: ${province.name}`);
            
            // Highlight province
            activeProvinceHighlight = L.polygon(province.polygon, {
                color: province.color,
                weight: 4,
                opacity: 1,
                fillOpacity: 0.4,
                fillColor: province.color,
                dashArray: null,
                className: 'search-highlight'
            }).addTo(map);

            // Show popup
            activeProvinceHighlight.bindPopup(`
                <div class="province-popup search-result">
                    <h3 style="color: ${province.color};">📍 ${province.name}</h3>
                    <p><strong>Networks:</strong> ${province.networks}</p>
                    <p><strong>Coverage:</strong> ${province.coverage}</p>
                    <p><em>No specific WiFi access points found for "${searchTerm}"</em></p>
                </div>
            `).openPopup();

            // Zoom to province
            map.fitBounds(activeProvinceHighlight.getBounds(), {
                padding: [50, 50],
                maxZoom: 12,
                animation: true
            });
        }

        if (!province && matchingAPs.length === 0) {
            console.log(`No WiFi access points or locations found for: ${searchTerm}`);
            // Show "no results" message
            const center = map.getCenter();
            if (center) {
                map.openPopup(`
                    <div class="search-no-results">
                        <h4>🔍 No WiFi Access Points Found</h4>
                        <p>No WiFi access points found for "<strong>${searchTerm}</strong>"</p>
                        <p>Try searching for:</p>
                        <ul style="text-align: left; margin: 8px 0; padding-left: 20px;">
                            <li>SSID names (e.g., "WiFi-2024", "Office-Network")</li>
                            <li>Access point names (e.g., "AP-Main-Building")</li>
                            <li>Locations (e.g., "Manila", "Makati")</li>
                            <li>BSSID addresses</li>
                        </ul>
                    </div>
                `, center);
            }
        }
    } catch (error) {
        console.error('Error performing search:', error);
        alert('Search encountered an error. Please try again.');
    }
}

// Show search suggestions
function showSearchSuggestions(searchTerm, containerId) {
    // This could be enhanced to show a dropdown with suggestions
    console.log(`Search suggestions for "${searchTerm}" in ${containerId}`);
}

// Global helper functions
window.showProvinceDetails = function(provinceName) {
    console.log(`Showing details for ${provinceName}`);
    alert(`Detailed view for ${provinceName} would open here.\n\nThis would show:\n- Network distribution maps\n- Historical data trends\n- Security analysis reports\n- Performance metrics`);
};

window.showProvinceNetworks = function(provinceName) {
    const province = PROVINCES.find(p => p.name === provinceName);
    const networks = ACCESS_POINTS.filter(ap => ap.province === provinceName);
    console.log(`Showing networks for ${provinceName}:`, networks);
    
    let networkList = `Networks in ${provinceName}:\n\n`;
    if (networks.length > 0) {
        networks.forEach((network, index) => {
            networkList += `${index + 1}. ${network.name}\n   SSID: ${network.ssid}\n   Status: ${network.status}\n   Signal: ${network.signal} dBm\n\n`;
        });
    } else {
        networkList += "No access points currently mapped in this province.";
    }
    
    alert(networkList);
};

window.exportProvinceData = function(provinceName) {
    const province = PROVINCES.find(p => p.name === provinceName);
    const networks = ACCESS_POINTS.filter(ap => ap.province === provinceName);
    console.log(`Exporting data for ${provinceName}:`, { province, networks });
    
    const data = {
        province: provinceName,
        statistics: {
            totalNetworks: province.networks,
            verifiedNetworks: province.verified,
            suspiciousNetworks: province.suspicious,
            coverage: province.coverage
        },
        accessPoints: networks,
        exportDate: new Date().toISOString()
    };
    
    // Simulate data export
    const dataStr = JSON.stringify(data, null, 2);
    console.log('Exported data:', dataStr);
    alert(`Data for ${provinceName} has been prepared for export.\n\nIncluded:\n- Province statistics\n- ${networks.length} access points\n- Coverage analysis\n- Timestamp: ${new Date().toLocaleString()}\n\nIn a real application, this would download a CSV/JSON file.`);
};

window.viewNetworkDetails = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    console.log(`Viewing details for network ${apId}:`, ap);
    
    if (ap) {
        alert(`Network Details: ${ap.name}\n\nSSID: ${ap.ssid}\nLocation: ${ap.province}\nSignal Strength: ${ap.signal} dBm\nStatus: ${ap.status}\nConnected Devices: ${ap.devices}\nLast Seen: ${ap.lastSeen}\n\nThis would open a detailed network analysis window.`);
    } else {
        alert(`Network details for ${apId} would open here.`);
    }
};

window.reportThreat = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    console.log(`Reporting threat for ${apId}:`, ap);
    
    if (ap) {
        alert(`Threat Report for: ${ap.name}\n\nSSID: ${ap.ssid}\nLocation: ${ap.province}\nReason: Suspicious activity detected\n\nThis would open the threat reporting interface and notify security teams.`);
    } else {
        alert(`Threat report for ${apId} would be submitted.`);
    }
};

window.verifyNetwork = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    console.log(`Verifying network ${apId}:`, ap);
    
    if (ap) {
        alert(`Network Verification: ${ap.name}\n\nSSID: ${ap.ssid}\nThis network would be marked as verified and added to the trusted networks list.\n\nVerification includes:\n- Security protocol validation\n- Owner authentication\n- Signal legitimacy check`);
    } else {
        alert(`Network ${apId} would be marked as verified.`);
    }
};

// Cleanup function
export function cleanupMap() {
    console.log('Cleaning up maps...');
    if (dashboardMap) {
        dashboardMap.remove();
        dashboardMap = null;
    }
    if (coverageMap) {
        coverageMap.remove();
        coverageMap = null;
    }
    currentMarkers.clear();
    activeProvinceHighlight = null;
}

// Utility functions for external use
export function addMarker(lat, lng, options = {}) {
    if (!dashboardMap) return null;
    return L.marker([lat, lng], options).addTo(dashboardMap);
}

export function addCircle(lat, lng, radius, options = {}) {
    if (!dashboardMap) return null;
    return L.circle([lat, lng], { radius, ...options }).addTo(dashboardMap);
}

export function setView(lat, lng, zoom) {
    if (!dashboardMap) return;
    dashboardMap.setView([lat, lng], zoom);
}

export function zoomToProvince(name) {
    const currentMap = dashboardMap || coverageMap;
    if (!currentMap) {
        console.warn('No map available for province zoom');
        return;
    }
    
    if (!name) {
        console.warn('No province name provided');
        return;
    }
    
    console.log(`Zooming to province: ${name}`);
    
    // Try exact match (case-insensitive)
    let prov = PROVINCES.find(
        p => p.name.toLowerCase() === name.trim().toLowerCase()
    );
    
    // If not found, try partial match (case-insensitive)
    if (!prov) {
        prov = PROVINCES.find(
            p => p.name.toLowerCase().includes(name.trim().toLowerCase())
        );
    }
    
    if (prov) {
        console.log(`Found province: ${prov.name}`);
        currentMap.fitBounds(prov.polygon, {
            padding: [50, 50],
            maxZoom: 12,
            animation: true
        });
        
        // Highlight the province
        if (activeProvinceHighlight && currentMap.hasLayer(activeProvinceHighlight)) {
            currentMap.removeLayer(activeProvinceHighlight);
        }
        
        activeProvinceHighlight = L.polygon(prov.polygon, {
            color: prov.color,
            weight: 4,
            opacity: 1,
            fillOpacity: 0.3,
            fillColor: prov.color,
            className: 'province-search-highlight'
        }).addTo(currentMap);
        
        setTimeout(() => {
            if (activeProvinceHighlight && currentMap.hasLayer(activeProvinceHighlight)) {
                currentMap.removeLayer(activeProvinceHighlight);
                activeProvinceHighlight = null;
            }
        }, 3000);
    } else {
        console.warn(`Province not found: ${name}`);
        alert(`Province not found: ${name}. Available provinces: ${PROVINCES.map(p => p.name).join(', ')}`);
    }
}

// Interactive popup action handlers
window.viewAPDetails = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    if (!ap) return;
    
    console.log(`Viewing details for AP: ${ap.name}`);
    
    if (window.showToast) {
        window.showToast(`Loading details for ${ap.name}...`, 'info');
    }
    
    // Navigate to networks section with filter
    setTimeout(() => {
        if (window.showSection) {
            window.showSection('networks');
            // Filter to show this specific network
            if (window.filterWiFiNetworks) {
                window.filterWiFiNetworks('ssid', ap.ssid);
            }
        }
    }, 1000);
};

window.blockAP = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    if (!ap) return;
    
    console.log(`Blocking AP: ${ap.name}`);
    
    const confirmBlock = confirm(`Are you sure you want to block "${ap.name}" (${ap.ssid})?\n\nThis will prevent users from connecting to this network.`);
    
    if (confirmBlock) {
        // Simulate blocking the AP
        const marker = currentMarkers.get(apId);
        if (marker) {
            const currentMap = dashboardMap || coverageMap;
            if (currentMap && currentMap.hasLayer(marker)) {
                currentMap.removeLayer(marker);
            }
        }
        
        if (window.showToast) {
            window.showToast(`Network "${ap.name}" has been blocked`, 'warning');
        }
        
        // Update dashboard stats
        if (window.updateDashboardStats) {
            window.updateDashboardStats();
        }
    }
};

window.verifyAP = function(apId) {
    const ap = ACCESS_POINTS.find(a => a.id === apId);
    if (!ap) return;
    
    console.log(`Verifying AP: ${ap.name}`);
    
    // Update the AP status
    ap.status = 'verified';
    
    // Update the marker appearance
    const marker = currentMarkers.get(apId);
    if (marker) {
        // Remove and recreate marker with new status
        const currentMap = dashboardMap || coverageMap;
        if (currentMap && currentMap.hasLayer(marker)) {
            currentMap.removeLayer(marker);
        }
        
        const newMarker = createAccessPointMarker(ap, currentMap);
        currentMarkers.set(apId, newMarker);
    }
    
    if (window.showToast) {
        window.showToast(`Network "${ap.name}" has been verified`, 'success');
    }
    
    // Update dashboard stats
    if (window.dashboardData) {
        window.dashboardData.stats.verifiedNetworks++;
        window.dashboardData.stats.suspiciousNetworks = Math.max(0, window.dashboardData.stats.suspiciousNetworks - 1);
        if (window.updateStatCardsDisplay) {
            window.updateStatCardsDisplay();
        }
    }
};

// Enhanced map interaction features
function initializeMapInteractions() {
    console.log('Initializing enhanced map interactions...');
    
    // Add keyboard shortcuts for map navigation
    document.addEventListener('keydown', (e) => {
        const currentMap = dashboardMap || coverageMap;
        if (!currentMap) return;
        
        // Only if no input is focused
        if (document.activeElement.tagName === 'INPUT') return;
        
        switch(e.key) {
            case '+':
            case '=':
                e.preventDefault();
                currentMap.zoomIn();
                break;
            case '-':
                e.preventDefault();
                currentMap.zoomOut();
                break;
            case 'r':
            case 'R':
                e.preventDefault();
                currentMap.fitBounds(CALABARZON_BOUNDS);
                if (window.showToast) {
                    window.showToast('Map view reset to CALABARZON', 'info');
                }
                break;
        }
    });
}

// Initialize enhanced map interactions when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(initializeMapInteractions, 2000);
});

// Global utility functions
window.toggleMapLayer = toggleMapLayer;
window.showAccessPointsByStatus = showAccessPointsByStatus;
window.hideAccessPointsByStatus = hideAccessPointsByStatus;
window.ACCESS_POINTS = ACCESS_POINTS; 
// dashboard.js - Interactive Dashboard Functionality for DisCon-X
// Makes the main dashboard fully functional and interactive

console.log('Dashboard utils loading...');

// Dashboard data management
let dashboardData = {
    stats: {
        totalNetworks: 1254,
        verifiedNetworks: 987,
        suspiciousNetworks: 37,
        activeUsers: 13542,
        lastUpdated: new Date()
    },
    trends: {
        totalNetworksChange: 8.2,
        verifiedChange: 12.5,
        suspiciousChange: 4.8,
        activeUsersChange: 18.3
    },
    regionalData: [
        { province: 'Cavite', networks: 287, verified: 231, suspicious: 28, coverage: 76 },
        { province: 'Laguna', networks: 342, verified: 298, suspicious: 12, coverage: 82 },
        { province: 'Batangas', networks: 215, verified: 187, suspicious: 8, coverage: 68 },
        { province: 'Rizal', networks: 263, verified: 209, suspicious: 9, coverage: 73 },
        { province: 'Quezon', networks: 147, verified: 62, suspicious: 3, coverage: 42 }
    ]
};

// Initialize interactive dashboard features
function initializeDashboard() {
    console.log('Initializing interactive dashboard...');
    
    // Make stat cards clickable
    setupStatCardInteractions();
    
    // Initialize real-time updates
    startRealTimeUpdates();
    
    // Setup quick actions
    setupQuickActions();
    
    // Setup system status monitoring
    setupSystemStatusMonitoring();
    
    // Initialize regional statistics interactions
    setupRegionalStatsInteractions();

    // Quick Actions: Add Whitelist should navigate to Wi‑Fi Networks
    try {
        const addWhitelistBtn = document.getElementById('addWhitelistBtn');
        const verifyPendingBtn = document.getElementById('verifyPendingBtn');
        const viewThreatsBtn = document.getElementById('viewThreatsBtn');
        const syncMobileBtn = document.getElementById('syncMobileBtn');
        if (addWhitelistBtn) {
            addWhitelistBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (typeof window.showSection === 'function') {
                    window.showSection('networks');
                } else {
                    // Fallback: navigate by hash if router not available
                    location.hash = '#networks';
                }
                // Optionally focus on upload area if available after render
                setTimeout(() => {
                    const uploadBtn = document.getElementById('wifiWhitelistUploadBtn');
                    if (uploadBtn) {
                        uploadBtn.focus();
                    }
                }, 400);
            });
        }
        if (verifyPendingBtn) {
            verifyPendingBtn.addEventListener('click', () => {
                if (typeof window.showSection === 'function') {
                    window.showSection('networks');
                }
                setTimeout(() => {
                    // Optional: filter to Pending if function exists
                    if (window.filterWiFiNetworks) {
                        window.filterWiFiNetworks('pending');
                    }
                }, 300);
            });
        }
        if (viewThreatsBtn) {
            viewThreatsBtn.addEventListener('click', () => {
                if (typeof window.showSection === 'function') {
                    window.showSection('threats');
                }
            });
        }
        if (syncMobileBtn) {
            syncMobileBtn.addEventListener('click', () => {
                // Placeholder: trigger a mobile sync routine
                showToast('Syncing mobile data...', 'info');
                setTimeout(() => showToast('Mobile data synchronized', 'success'), 1200);
            });
        }
    } catch (err) {
        console.warn('Quick action binding failed:', err);
    }
    
    console.log('Dashboard initialization completed');
}

// Make statistics cards interactive
function setupStatCardInteractions() {
    const statCards = document.querySelectorAll('.stat-card');
    
    statCards.forEach((card, index) => {
        // Add hover effects
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-2px)';
            card.style.boxShadow = '0 8px 24px rgba(0, 0, 0, 0.15)';
            card.style.cursor = 'pointer';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
            card.style.boxShadow = 'none';
        });
        
        // Add click functionality
        card.addEventListener('click', () => {
            handleStatCardClick(index);
        });
        
        // Add keyboard accessibility
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'button');
        card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleStatCardClick(index);
            }
        });
    });
}

// Handle stat card clicks
function handleStatCardClick(cardIndex) {
    const actions = [
        () => {
            showToast('Navigating to Networks section...', 'info');
            setTimeout(() => showSection('networks'), 500);
        },
        () => {
            showToast('Showing verified networks...', 'success');
            setTimeout(() => {
                showSection('networks');
                // Filter to show only verified networks
                if (window.filterWiFiNetworks) {
                    window.filterWiFiNetworks('verified');
                }
            }, 500);
        },
        () => {
            showToast('Showing threat activity...', 'warning');
            setTimeout(() => showSection('threats'), 500);
        },
        () => {
            showToast('Showing analytics & reports...', 'info');
            setTimeout(() => showSection('analytics-reports'), 500);
        }
    ];
    
    if (actions[cardIndex]) {
        actions[cardIndex]();
    }
}

// Real-time data updates
function startRealTimeUpdates() {
    // Update dashboard stats every 30 seconds
    setInterval(() => {
        updateDashboardStats();
    }, 30000);
    
    // Update last seen times every 60 seconds
    setInterval(() => {
        updateLastSeenTimes();
    }, 60000);
    
    // Simulate occasional new threat detection
    setInterval(() => {
        simulateNewThreatDetection();
    }, 120000); // Every 2 minutes
}

// Update dashboard statistics
function updateDashboardStats() {
    // Simulate small changes in data
    const changes = {
        totalNetworks: Math.floor(Math.random() * 10) - 5, // -5 to +5
        verifiedNetworks: Math.floor(Math.random() * 6) - 1, // -1 to +5
        suspiciousNetworks: Math.floor(Math.random() * 3) - 1, // -1 to +2
        activeUsers: Math.floor(Math.random() * 100) - 50 // -50 to +50
    };
    
    // Apply changes
    dashboardData.stats.totalNetworks += changes.totalNetworks;
    dashboardData.stats.verifiedNetworks += changes.verifiedNetworks;
    dashboardData.stats.suspiciousNetworks += changes.suspiciousNetworks;
    dashboardData.stats.activeUsers += changes.activeUsers;
    
    // Ensure valid ranges
    dashboardData.stats.totalNetworks = Math.max(1000, dashboardData.stats.totalNetworks);
    dashboardData.stats.verifiedNetworks = Math.max(800, Math.min(dashboardData.stats.verifiedNetworks, dashboardData.stats.totalNetworks - 100));
    dashboardData.stats.suspiciousNetworks = Math.max(10, Math.min(dashboardData.stats.suspiciousNetworks, 100));
    dashboardData.stats.activeUsers = Math.max(10000, dashboardData.stats.activeUsers);
    
    // Update the UI
    updateStatCardsDisplay();
    
    console.log('Dashboard stats updated:', dashboardData.stats);
}

// Update stat cards display
function updateStatCardsDisplay() {
    const statValues = document.querySelectorAll('.stat-value');
    const stats = dashboardData.stats;
    
    if (statValues.length >= 4) {
        // Animate the value changes
        animateValueChange(statValues[0], stats.totalNetworks.toLocaleString());
        animateValueChange(statValues[1], stats.verifiedNetworks.toLocaleString());
        animateValueChange(statValues[2], stats.suspiciousNetworks.toLocaleString());
        animateValueChange(statValues[3], stats.activeUsers.toLocaleString());
    }
    
    // Update last updated timestamp
    dashboardData.stats.lastUpdated = new Date();
    
    // Show brief update notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 8px 16px;
        border-radius: 6px;
        font-size: 14px;
        z-index: 1000;
        opacity: 0;
        transition: opacity 0.3s ease;
    `;
    notification.textContent = 'Dashboard updated';
    document.body.appendChild(notification);
    
    // Animate notification
    setTimeout(() => notification.style.opacity = '1', 100);
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 2000);
}

// Animate value changes
function animateValueChange(element, newValue) {
    element.style.transform = 'scale(1.1)';
    element.style.color = '#3b82f6';
    
    setTimeout(() => {
        element.textContent = newValue;
        element.style.transform = 'scale(1)';
        element.style.color = '#1e293b';
    }, 200);
}

// Update last seen times
function updateLastSeenTimes() {
    const lastSeenElements = document.querySelectorAll('[data-last-seen]');
    const now = new Date();
    
    lastSeenElements.forEach(element => {
        const lastSeen = new Date(element.dataset.lastSeen);
        const timeDiff = now - lastSeen;
        const minutes = Math.floor(timeDiff / 60000);
        
        if (minutes < 60) {
            element.textContent = `${minutes}m ago`;
        } else {
            const hours = Math.floor(minutes / 60);
            element.textContent = `${hours}h ago`;
        }
    });
}

// Simulate new threat detection
function simulateNewThreatDetection() {
    if (Math.random() < 0.3) { // 30% chance
        const threatTypes = ['Evil Twin', 'Rogue AP', 'Suspicious Activity'];
        const locations = ['Manila', 'Quezon City', 'Makati', 'Taguig', 'Pasig'];
        
        const newThreat = {
            type: threatTypes[Math.floor(Math.random() * threatTypes.length)],
            location: locations[Math.floor(Math.random() * locations.length)],
            severity: Math.random() > 0.7 ? 'High' : 'Medium',
            time: new Date().toLocaleTimeString()
        };
        
        // Show threat notification
        showThreatNotification(newThreat);
        
        // Update suspicious networks count
        dashboardData.stats.suspiciousNetworks++;
        updateStatCardsDisplay();
        
        // Update recent threat activity if function exists
        if (window.addNewThreatToTable) {
            window.addNewThreatToTable(newThreat);
        }
    }
}

// Show threat notification
function showThreatNotification(threat) {
    const notification = document.createElement('div');
    notification.className = 'threat-notification';
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: linear-gradient(135deg, #fee2e2 0%, #fef2f2 100%);
        border: 2px solid #ef4444;
        color: #dc2626;
        padding: 16px;
        border-radius: 12px;
        font-size: 14px;
        z-index: 1001;
        max-width: 300px;
        box-shadow: 0 8px 24px rgba(239, 68, 68, 0.3);
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    notification.innerHTML = `
        <div style="display: flex; align-items: flex-start; gap: 12px;">
            <div style="color: #ef4444;">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                </svg>
            </div>
            <div>
                <div style="font-weight: 600; margin-bottom: 4px;">⚠️ ${threat.severity} Threat Detected</div>
                <div style="font-size: 13px; margin-bottom: 2px;">${threat.type} in ${threat.location}</div>
                <div style="font-size: 12px; opacity: 0.8;">Detected at ${threat.time}</div>
                <button onclick="this.parentElement.parentElement.parentElement.remove(); showSection('threats');" 
                        style="margin-top: 8px; background: #ef4444; color: white; border: none; padding: 4px 8px; border-radius: 4px; font-size: 12px; cursor: pointer;">
                    View Details
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 10 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentElement) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 10000);
}

// Setup quick actions functionality
function setupQuickActions() {
    const addWhitelistBtn = document.querySelector('.quick-blue');
    const exportDataBtn = document.querySelector('.quick-purple');
    
    if (addWhitelistBtn) {
        addWhitelistBtn.addEventListener('click', () => {
            showAddWhitelistModal();
        });
    }
    
    if (exportDataBtn) {
        exportDataBtn.addEventListener('click', () => {
            exportDashboardData();
        });
    }
}

// Show add whitelist modal
function showAddWhitelistModal() {
    const modal = document.createElement('div');
    modal.className = 'dashboard-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.6);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1002;
        opacity: 0;
        transition: opacity 0.3s ease;
    `;
    
    modal.innerHTML = `
        <div class="modal-content" style="
            background: white;
            border-radius: 16px;
            padding: 24px;
            max-width: 400px;
            width: 90%;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            transform: scale(0.9);
            transition: transform 0.3s ease;
        ">
            <h3 style="margin: 0 0 16px 0; color: #1f2937; font-size: 20px;">Add Network to Whitelist</h3>
            <div style="margin-bottom: 16px;">
                <label style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500;">SSID:</label>
                <input type="text" id="whitelistSSID" placeholder="Enter network SSID" style="
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 16px;
                    outline: none;
                    transition: border-color 0.2s;
                " />
            </div>
            <div style="margin-bottom: 24px;">
                <label style="display: block; margin-bottom: 6px; color: #374151; font-weight: 500;">BSSID:</label>
                <input type="text" id="whitelistBSSID" placeholder="Enter BSSID (optional)" style="
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #e5e7eb;
                    border-radius: 8px;
                    font-size: 16px;
                    outline: none;
                    transition: border-color 0.2s;
                " />
            </div>
            <div style="display: flex; gap: 12px; justify-content: flex-end;">
                <button onclick="this.closest('.dashboard-modal').remove()" style="
                    padding: 10px 20px;
                    border: 2px solid #e5e7eb;
                    background: white;
                    color: #374151;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: all 0.2s;
                ">Cancel</button>
                <button onclick="addToWhitelist()" style="
                    padding: 10px 20px;
                    border: none;
                    background: #3b82f6;
                    color: white;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: all 0.2s;
                ">Add to Whitelist</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Animate in
    setTimeout(() => {
        modal.style.opacity = '1';
        modal.querySelector('.modal-content').style.transform = 'scale(1)';
    }, 100);
    
    // Focus on first input
    setTimeout(() => {
        modal.querySelector('#whitelistSSID').focus();
    }, 200);
    
    // Add to whitelist function
    window.addToWhitelist = function() {
        const ssid = document.getElementById('whitelistSSID').value.trim();
        const bssid = document.getElementById('whitelistBSSID').value.trim();
        
        if (!ssid) {
            showToast('Please enter an SSID', 'error');
            return;
        }
        
        // Simulate adding to whitelist
        showToast(`Added "${ssid}" to whitelist successfully!`, 'success');
        modal.remove();
        
        // Update verified networks count
        dashboardData.stats.verifiedNetworks++;
        updateStatCardsDisplay();
    };
}

// Export dashboard data
function exportDashboardData() {
    const data = {
        exportDate: new Date().toISOString(),
        statistics: dashboardData.stats,
        trends: dashboardData.trends,
        regionalData: dashboardData.regionalData,
        exportType: 'dashboard_summary'
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `disconx-dashboard-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showToast('Dashboard data exported successfully!', 'success');
}

// Setup system status monitoring
function setupSystemStatusMonitoring() {
    const statusItems = document.querySelectorAll('.status-item');
    
    // Simulate system status changes
    setInterval(() => {
        statusItems.forEach((item, index) => {
            if (Math.random() < 0.1) { // 10% chance of status change
                const indicator = item.querySelector('.status-indicator');
                const value = item.querySelector('.status-value');
                
                if (index < 3) { // Service status items
                    const isActive = Math.random() > 0.1; // 90% uptime
                    indicator.className = `status-indicator ${isActive ? 'active' : 'inactive'}`;
                    value.className = `status-value ${isActive ? 'active' : 'inactive'}`;
                    value.textContent = isActive ? 'Active' : 'Inactive';
                }
            }
        });
    }, 60000); // Check every minute
}

// Setup regional statistics interactions
function setupRegionalStatsInteractions() {
    const regionalTable = document.querySelector('.data-table');
    if (!regionalTable) return;
    
    const rows = regionalTable.querySelectorAll('tbody tr');
    
    rows.forEach((row, index) => {
        row.style.cursor = 'pointer';
        row.addEventListener('click', () => {
            const province = row.cells[0].textContent;
            showProvinceDetails(province);
        });
        
        row.addEventListener('mouseenter', () => {
            row.style.backgroundColor = '#f3f4f6';
        });
        
        row.addEventListener('mouseleave', () => {
            row.style.backgroundColor = '';
        });
    });
}

// Show province details
function showProvinceDetails(provinceName) {
    const provinceData = dashboardData.regionalData.find(p => p.province === provinceName);
    if (!provinceData) return;
    
    showToast(`Loading details for ${provinceName}...`, 'info');
    
    // Simulate navigation to coverage map with province highlighted
    setTimeout(() => {
        showSection('coverage-map');
        if (window.zoomToProvince) {
            window.zoomToProvince(provinceName);
        }
    }, 500);
}

// Utility function for showing toast notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const colors = {
        info: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' },
        success: { bg: '#d1fae5', border: '#10b981', text: '#065f46' },
        warning: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e' },
        error: { bg: '#fee2e2', border: '#ef4444', text: '#dc2626' }
    };
    
    const color = colors[type] || colors.info;
    
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${color.bg};
        border: 2px solid ${color.border};
        color: ${color.text};
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        z-index: 1003;
        opacity: 0;
        transform: translateY(100%);
        transition: all 0.3s ease;
        max-width: 300px;
    `;
    
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Animate in
    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 100);
    
    // Auto remove
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(100%)';
        setTimeout(() => {
            if (toast.parentElement) {
                document.body.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

// Enhanced detection trends select functionality
function setupTrendsSelectInteraction() {
    const trendsSelect = document.getElementById('trendsSelect');
    if (trendsSelect) {
        trendsSelect.addEventListener('change', (e) => {
            const period = e.target.value;
            showToast(`Updating trends for ${period}...`, 'info');
            
            // Update chart if function exists
            if (window.renderTrendsChart) {
                window.renderTrendsChart(period);
            }
        });
    }
}

// Initialize dashboard when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        initializeDashboard();
        setupTrendsSelectInteraction();
    }, 1000);
});

// Export functions for global access
window.initializeDashboard = initializeDashboard;
window.dashboardData = dashboardData;
window.showToast = showToast;
window.updateDashboardStats = updateDashboardStats;

console.log('Dashboard utils loaded successfully');


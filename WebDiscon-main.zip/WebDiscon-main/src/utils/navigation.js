// Navigation Utility Functions
let currentSection = 'dashboard';
let isInitialized = false;

export function initializeNavigation() {
    try {
        if (isInitialized) {
            return; // Prevent duplicate initialization
        }

        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                const section = item.dataset.section;
                if (section) {
                    navigateToSection(section);
                }
            });
        });

        isInitialized = true;
    } catch (error) {
        console.error('Error initializing navigation:', error);
    }
}

export function navigateToSection(section) {
    try {
        if (section === currentSection) return;

        // Update active state
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.classList.toggle('active', item.dataset.section === section);
        });

        // Update current section
        currentSection = section;

        // Dispatch section change event
        const event = new CustomEvent('sectionLoaded', {
            detail: { section }
        });
        document.dispatchEvent(event);
    } catch (error) {
        console.error('Error navigating to section:', error);
    }
}

export function getCurrentSection() {
    return currentSection;
}

export function setupNavigation() {
    try {
        // Initialize mobile menu
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');

        if (menuToggle && sidebar && overlay) {
            // Remove existing listeners to prevent duplicates
            const newMenuToggle = menuToggle.cloneNode(true);
            menuToggle.parentNode.replaceChild(newMenuToggle, menuToggle);
            
            newMenuToggle.addEventListener('click', () => {
                try {
                    sidebar.classList.toggle('open');
                    overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
                } catch (error) {
                    console.error('Error toggling mobile menu:', error);
                }
            });

            const newOverlay = overlay.cloneNode(true);
            overlay.parentNode.replaceChild(newOverlay, overlay);
            
            newOverlay.addEventListener('click', () => {
                try {
                    sidebar.classList.remove('open');
                    newOverlay.style.display = 'none';
                } catch (error) {
                    console.error('Error closing mobile menu:', error);
                }
            });
        }
    } catch (error) {
        console.error('Error setting up navigation:', error);
    }
}

// Reset initialization flag (useful for testing or re-initialization)
export function resetNavigation() {
    isInitialized = false;
} 
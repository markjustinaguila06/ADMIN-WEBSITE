// Advanced Search and Filtering System
// Provides powerful search capabilities with filters, sorting, and fuzzy matching

class AdvancedSearch {
    constructor() {
        this.filters = new Map();
        this.sortOptions = new Map();
        this.searchHistory = [];
        this.maxHistorySize = 50;
        this.loadSearchHistory();
    }

    // Main search function with multiple criteria
    search(data, query, options = {}) {
        const {
            fields = [],
            filters = {},
            sort = null,
            fuzzy = false,
            caseSensitive = false,
            limit = null,
            offset = 0,
            highlight = false
        } = options;

        let results = [...data];

        // Apply text search
        if (query && query.trim()) {
            results = this.textSearch(results, query, fields, { fuzzy, caseSensitive, highlight });
            this.addToHistory(query);
        }

        // Apply filters
        if (Object.keys(filters).length > 0) {
            results = this.applyFilters(results, filters);
        }

        // Apply sorting
        if (sort) {
            results = this.sortResults(results, sort);
        }

        // Apply pagination
        if (limit) {
            const start = offset;
            const end = offset + limit;
            results = results.slice(start, end);
        }

        return {
            results,
            total: data.length,
            filtered: results.length,
            query,
            filters,
            sort
        };
    }

    // Text search with optional fuzzy matching
    textSearch(data, query, fields = [], options = {}) {
        const { fuzzy, caseSensitive, highlight } = options;
        const searchTerm = caseSensitive ? query : query.toLowerCase();

        return data.filter(item => {
            // If no specific fields, search all string fields
            const searchFields = fields.length > 0 ? fields : Object.keys(item);
            
            return searchFields.some(field => {
                const value = this.getNestedValue(item, field);
                if (value === null || value === undefined) return false;
                
                const stringValue = String(value);
                const compareValue = caseSensitive ? stringValue : stringValue.toLowerCase();
                
                let matches = false;
                
                if (fuzzy) {
                    matches = this.fuzzyMatch(compareValue, searchTerm);
                } else {
                    matches = compareValue.includes(searchTerm);
                }
                
                // Add highlight if requested
                if (matches && highlight && typeof item[field] === 'string') {
                    item[`${field}_highlighted`] = this.highlightMatch(stringValue, query, caseSensitive);
                }
                
                return matches;
            });
        });
    }

    // Fuzzy string matching using Levenshtein distance
    fuzzyMatch(str, pattern, threshold = 0.8) {
        const distance = this.levenshteinDistance(str, pattern);
        const maxLength = Math.max(str.length, pattern.length);
        const similarity = 1 - (distance / maxLength);
        return similarity >= threshold;
    }

    // Calculate Levenshtein distance between two strings
    levenshteinDistance(str1, str2) {
        const matrix = [];
        
        for (let i = 0; i <= str2.length; i++) {
            matrix[i] = [i];
        }
        
        for (let j = 0; j <= str1.length; j++) {
            matrix[0][j] = j;
        }
        
        for (let i = 1; i <= str2.length; i++) {
            for (let j = 1; j <= str1.length; j++) {
                if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
                    matrix[i][j] = matrix[i - 1][j - 1];
                } else {
                    matrix[i][j] = Math.min(
                        matrix[i - 1][j - 1] + 1,
                        matrix[i][j - 1] + 1,
                        matrix[i - 1][j] + 1
                    );
                }
            }
        }
        
        return matrix[str2.length][str1.length];
    }

    // Apply multiple filters
    applyFilters(data, filters) {
        return data.filter(item => {
            return Object.entries(filters).every(([field, filter]) => {
                const value = this.getNestedValue(item, field);
                return this.evaluateFilter(value, filter);
            });
        });
    }

    // Evaluate a single filter condition
    evaluateFilter(value, filter) {
        if (filter === null || filter === undefined) return true;
        
        // Handle different filter types
        if (typeof filter === 'object' && !Array.isArray(filter)) {
            // Complex filter object
            const { operator, value: filterValue, min, max, contains, startsWith, endsWith } = filter;
            
            switch (operator) {
                case 'eq':
                case '=':
                    return value === filterValue;
                case 'ne':
                case '!=':
                    return value !== filterValue;
                case 'gt':
                case '>':
                    return value > filterValue;
                case 'gte':
                case '>=':
                    return value >= filterValue;
                case 'lt':
                case '<':
                    return value < filterValue;
                case 'lte':
                case '<=':
                    return value <= filterValue;
                case 'between':
                    return value >= min && value <= max;
                case 'in':
                    return Array.isArray(filterValue) && filterValue.includes(value);
                case 'notIn':
                    return Array.isArray(filterValue) && !filterValue.includes(value);
                case 'contains':
                    return String(value).toLowerCase().includes(String(contains).toLowerCase());
                case 'startsWith':
                    return String(value).toLowerCase().startsWith(String(startsWith).toLowerCase());
                case 'endsWith':
                    return String(value).toLowerCase().endsWith(String(endsWith).toLowerCase());
                case 'regex':
                    return new RegExp(filterValue).test(String(value));
                default:
                    return true;
            }
        } else if (Array.isArray(filter)) {
            // Array means value should be in the array
            return filter.includes(value);
        } else {
            // Simple equality check
            return value === filter;
        }
    }

    // Sort results
    sortResults(data, sortConfig) {
        const { field, order = 'asc', type = 'auto' } = 
            typeof sortConfig === 'string' 
                ? { field: sortConfig } 
                : sortConfig;

        return [...data].sort((a, b) => {
            const aValue = this.getNestedValue(a, field);
            const bValue = this.getNestedValue(b, field);
            
            let comparison = 0;
            
            switch (type) {
                case 'number':
                    comparison = (Number(aValue) || 0) - (Number(bValue) || 0);
                    break;
                case 'date':
                    comparison = new Date(aValue).getTime() - new Date(bValue).getTime();
                    break;
                case 'string':
                default:
                    comparison = String(aValue).localeCompare(String(bValue));
            }
            
            return order === 'desc' ? -comparison : comparison;
        });
    }

    // Get nested object value using dot notation
    getNestedValue(obj, path) {
        return path.split('.').reduce((current, key) => current?.[key], obj);
    }

    // Highlight search matches in text
    highlightMatch(text, query, caseSensitive = false) {
        const regex = new RegExp(`(${query})`, caseSensitive ? 'g' : 'gi');
        return text.replace(regex, '<mark class="search-highlight">$1</mark>');
    }

    // Search history management
    addToHistory(query) {
        if (!query || query.trim().length < 2) return;
        
        // Remove duplicates
        this.searchHistory = this.searchHistory.filter(item => item.query !== query);
        
        // Add to beginning
        this.searchHistory.unshift({
            query,
            timestamp: new Date().toISOString()
        });
        
        // Limit history size
        if (this.searchHistory.length > this.maxHistorySize) {
            this.searchHistory = this.searchHistory.slice(0, this.maxHistorySize);
        }
        
        this.saveSearchHistory();
    }

    loadSearchHistory() {
        try {
            const saved = localStorage.getItem('searchHistory');
            if (saved) {
                this.searchHistory = JSON.parse(saved);
            }
        } catch (error) {
            console.error('Failed to load search history:', error);
        }
    }

    saveSearchHistory() {
        try {
            localStorage.setItem('searchHistory', JSON.stringify(this.searchHistory));
        } catch (error) {
            console.error('Failed to save search history:', error);
        }
    }

    getSearchHistory(limit = 10) {
        return this.searchHistory.slice(0, limit);
    }

    clearSearchHistory() {
        this.searchHistory = [];
        localStorage.removeItem('searchHistory');
    }

    // Create advanced search UI component
    createSearchInterface(containerId, onSearch, options = {}) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const {
            placeholder = 'Search...',
            fields = [],
            filters = [],
            showHistory = true,
            showFilters = true,
            showSort = true
        } = options;

        const searchInterface = document.createElement('div');
        searchInterface.className = 'advanced-search-interface';
        searchInterface.innerHTML = `
            <div class="search-main">
                <div class="search-input-group">
                    <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                    <input type="text" class="search-input" placeholder="${placeholder}" />
                    <button class="search-clear" style="display: none;">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                  d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                ${showHistory ? '<div class="search-history-dropdown" style="display: none;"></div>' : ''}
            </div>
            
            ${showFilters ? `
                <div class="search-filters">
                    <button class="filter-toggle">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                  d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z">
                            </path>
                        </svg>
                        Filters
                        <span class="filter-count" style="display: none;">0</span>
                    </button>
                    <div class="filter-panel" style="display: none;">
                        <!-- Filters will be added here -->
                    </div>
                </div>
            ` : ''}
            
            ${showSort ? `
                <div class="search-sort">
                    <select class="sort-select">
                        <option value="">Sort by...</option>
                        <!-- Sort options will be added here -->
                    </select>
                </div>
            ` : ''}
        `;

        // Add styles
        this.addSearchStyles();

        // Setup event handlers
        const searchInput = searchInterface.querySelector('.search-input');
        const clearButton = searchInterface.querySelector('.search-clear');
        const historyDropdown = searchInterface.querySelector('.search-history-dropdown');
        
        // Search input handling
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const query = e.target.value;
            
            // Show/hide clear button
            clearButton.style.display = query ? 'block' : 'none';
            
            // Show search history
            if (showHistory && !query && this.searchHistory.length > 0) {
                this.showSearchHistory(historyDropdown, searchInput);
            } else {
                historyDropdown.style.display = 'none';
            }
            
            // Debounced search
            searchTimeout = setTimeout(() => {
                onSearch(query, this.getActiveFilters(searchInterface));
            }, 300);
        });

        // Clear button
        if (clearButton) {
            clearButton.addEventListener('click', () => {
                searchInput.value = '';
                clearButton.style.display = 'none';
                onSearch('', this.getActiveFilters(searchInterface));
            });
        }

        // Focus events for history
        if (showHistory) {
            searchInput.addEventListener('focus', () => {
                if (!searchInput.value && this.searchHistory.length > 0) {
                    this.showSearchHistory(historyDropdown, searchInput);
                }
            });

            document.addEventListener('click', (e) => {
                if (!searchInterface.contains(e.target)) {
                    historyDropdown.style.display = 'none';
                }
            });
        }

        container.appendChild(searchInterface);
        return searchInterface;
    }

    showSearchHistory(dropdown, input) {
        const history = this.getSearchHistory(5);
        if (history.length === 0) {
            dropdown.style.display = 'none';
            return;
        }

        dropdown.innerHTML = `
            <div class="search-history-header">
                <span>Recent Searches</span>
                <button class="clear-history">Clear</button>
            </div>
            ${history.map(item => `
                <div class="search-history-item" data-query="${item.query}">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span>${item.query}</span>
                </div>
            `).join('')}
        `;

        dropdown.style.display = 'block';

        // Handle history item clicks
        dropdown.querySelectorAll('.search-history-item').forEach(item => {
            item.addEventListener('click', () => {
                input.value = item.dataset.query;
                input.dispatchEvent(new Event('input'));
                dropdown.style.display = 'none';
            });
        });

        // Handle clear history
        const clearBtn = dropdown.querySelector('.clear-history');
        if (clearBtn) {
            clearBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.clearSearchHistory();
                dropdown.style.display = 'none';
            });
        }
    }

    getActiveFilters(searchInterface) {
        // Implementation would extract active filters from the UI
        return {};
    }

    addSearchStyles() {
        if (document.getElementById('advanced-search-styles')) return;

        const style = document.createElement('style');
        style.id = 'advanced-search-styles';
        style.textContent = `
            .advanced-search-interface {
                display: flex;
                gap: 16px;
                align-items: center;
                flex-wrap: wrap;
                margin-bottom: 24px;
            }
            
            .search-main {
                flex: 1;
                min-width: 300px;
                position: relative;
            }
            
            .search-input-group {
                position: relative;
                display: flex;
                align-items: center;
            }
            
            .search-icon {
                position: absolute;
                left: 12px;
                width: 20px;
                height: 20px;
                color: #9ca3af;
                pointer-events: none;
            }
            
            .search-input {
                width: 100%;
                padding: 12px 40px 12px 44px;
                border: 2px solid #e5e7eb;
                border-radius: 12px;
                font-size: 14px;
                transition: all 0.2s;
                background: white;
            }
            
            .search-input:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
            
            .search-clear {
                position: absolute;
                right: 12px;
                width: 32px;
                height: 32px;
                padding: 6px;
                background: #f3f4f6;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                transition: all 0.2s;
            }
            
            .search-clear:hover {
                background: #e5e7eb;
            }
            
            .search-clear svg {
                width: 20px;
                height: 20px;
                color: #6b7280;
            }
            
            .search-history-dropdown {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                margin-top: 8px;
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                z-index: 1000;
                overflow: hidden;
            }
            
            .search-history-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 12px 16px;
                border-bottom: 1px solid #e5e7eb;
                font-size: 12px;
                font-weight: 600;
                color: #6b7280;
                text-transform: uppercase;
            }
            
            .clear-history {
                background: none;
                border: none;
                color: #3b82f6;
                cursor: pointer;
                font-size: 12px;
                font-weight: 600;
            }
            
            .clear-history:hover {
                text-decoration: underline;
            }
            
            .search-history-item {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px 16px;
                cursor: pointer;
                transition: background 0.2s;
            }
            
            .search-history-item:hover {
                background: #f9fafb;
            }
            
            .search-history-item svg {
                width: 16px;
                height: 16px;
                color: #9ca3af;
            }
            
            .search-highlight {
                background: #fef3c7;
                padding: 2px 4px;
                border-radius: 2px;
                font-weight: 600;
            }
            
            .filter-toggle {
                display: flex;
                align-items: center;
                gap: 8px;
                padding: 10px 16px;
                background: white;
                border: 2px solid #e5e7eb;
                border-radius: 10px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                color: #374151;
                transition: all 0.2s;
            }
            
            .filter-toggle:hover {
                border-color: #3b82f6;
                color: #3b82f6;
            }
            
            .filter-toggle svg {
                width: 18px;
                height: 18px;
            }
            
            .filter-count {
                background: #3b82f6;
                color: white;
                padding: 2px 6px;
                border-radius: 10px;
                font-size: 11px;
                font-weight: 600;
            }
            
            .sort-select {
                padding: 10px 16px;
                border: 2px solid #e5e7eb;
                border-radius: 10px;
                background: white;
                font-size: 14px;
                color: #374151;
                cursor: pointer;
                transition: all 0.2s;
            }
            
            .sort-select:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
            

        `;
        document.head.appendChild(style);
    }
}

// Create singleton instance
const advancedSearch = new AdvancedSearch();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = advancedSearch;
} else {
    window.advancedSearch = advancedSearch;
}

export default advancedSearch;

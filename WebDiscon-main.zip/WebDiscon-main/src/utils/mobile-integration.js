// Mobile App Integration Module
// Handles real-time communication with mobile app via WebSocket and API

class MobileIntegration {
    constructor() {
        this.socket = null;
        this.baseUrl = window.location.origin;
        this.isConnected = false;
        this.scanData = null;
        this.threatReports = [];
        this.callbacks = {
            scanUpdate: [],
            threatUpdate: [],
            connectionChange: []
        };
    }

    // Initialize the mobile integration
    async initialize() {
        try {
            // Test API connection
            const response = await fetch(`${this.baseUrl}/api/health`);
            if (!response.ok) throw new Error('API not available');

            // Initialize WebSocket connection
            await this.connectWebSocket();
            
            // Load initial data
            await this.loadInitialData();
            
            console.log('Mobile integration initialized successfully');
            return true;
        } catch (error) {
            console.error('Failed to initialize mobile integration:', error);
            return false;
        }
    }

    // Connect to WebSocket for real-time updates
    connectWebSocket() {
        return new Promise((resolve, reject) => {
            try {
                // Load Socket.IO from CDN if not already loaded
                if (typeof io === 'undefined') {
                    const script = document.createElement('script');
                    script.src = 'https://cdn.socket.io/4.7.2/socket.io.min.js';
                    script.onload = () => {
                        this.initializeSocket();
                        resolve();
                    };
                    script.onerror = () => reject(new Error('Failed to load Socket.IO'));
                    document.head.appendChild(script);
                } else {
                    this.initializeSocket();
                    resolve();
                }
            } catch (error) {
                reject(error);
            }
        });
    }

    // Initialize Socket.IO connection
    initializeSocket() {
        this.socket = io(this.baseUrl);

        this.socket.on('connect', () => {
            this.isConnected = true;
            console.log('Connected to mobile integration server');
            this.notifyCallbacks('connectionChange', { connected: true });
        });

        this.socket.on('disconnect', () => {
            this.isConnected = false;
            console.log('Disconnected from mobile integration server');
            this.notifyCallbacks('connectionChange', { connected: false });
        });

        this.socket.on('scanDataUpdate', (data) => {
            this.scanData = data;
            console.log('Received scan data update:', data);
            this.notifyCallbacks('scanUpdate', data);
            this.updateDashboardWithScanData(data);
        });

        this.socket.on('threatReportUpdate', (data) => {
            if (data.report) {
                this.threatReports.unshift(data.report);
                // Keep only last 50 reports
                if (this.threatReports.length > 50) {
                    this.threatReports = this.threatReports.slice(0, 50);
                }
            }
            console.log('Received threat report update:', data);
            this.notifyCallbacks('threatUpdate', data);
            this.updateDashboardWithThreatData(data);
        });

        this.socket.on('threatReportsUpdate', (data) => {
            this.threatReports = data.reports || [];
            this.notifyCallbacks('threatUpdate', data);
        });
    }

    // Load initial data from API
    async loadInitialData() {
        try {
            // Load current scan data
            const scanResponse = await fetch(`${this.baseUrl}/api/mobile/scan-data`);
            if (scanResponse.ok) {
                const scanResult = await scanResponse.json();
                if (scanResult.success) {
                    this.scanData = scanResult.data;
                    this.updateDashboardWithScanData(scanResult.data);
                }
            }

            // Load threat reports
            const threatsResponse = await fetch(`${this.baseUrl}/api/mobile/threat-reports?limit=20`);
            if (threatsResponse.ok) {
                const threatsResult = await threatsResponse.json();
                if (threatsResult.success) {
                    this.threatReports = threatsResult.data.reports || [];
                    this.updateDashboardWithThreatData(threatsResult.data);
                }
            }
        } catch (error) {
            console.error('Failed to load initial data:', error);
        }
    }

    // Update dashboard with scan data
    updateDashboardWithScanData(data) {
        if (!data || !data.networks) return;

        // Update network statistics
        this.updateNetworkStatistics(data.statistics || {});

        // Update network list
        this.updateNetworkList(data.networks);

        // Update last scan time
        if (data.lastScan) {
            this.updateLastScanTime(data.lastScan);
        }

        // Update device info
        if (data.deviceId || data.location) {
            this.updateDeviceInfo({
                deviceId: data.deviceId,
                location: data.location
            });
        }
    }

    // Update dashboard with threat data
    updateDashboardWithThreatData(data) {
        if (data.report) {
            this.displayNewThreatAlert(data.report);
        }
        
        if (data.reports) {
            this.updateThreatReportsList(data.reports);
        }
    }

    // Update network statistics cards
    updateNetworkStatistics(stats) {
        const statsMapping = {
            'total-networks': stats.totalNetworks || 0,
            'suspicious-networks': stats.suspiciousNetworks || 0,
            'verified-networks': stats.verifiedNetworks || 0,
            'threats-detected': stats.threatsDetected || 0
        };

        Object.entries(statsMapping).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
                // Add animation effect
                element.classList.add('stat-updated');
                setTimeout(() => element.classList.remove('stat-updated'), 1000);
            }
        });
    }

    // Update network list
    updateNetworkList(networks) {
        const networkContainer = document.getElementById('network-list');
        if (!networkContainer) return;

        networkContainer.innerHTML = '';

        networks.forEach(network => {
            const networkElement = this.createNetworkElement(network);
            networkContainer.appendChild(networkElement);
        });
    }

    // Create network element for display
    createNetworkElement(network) {
        const element = document.createElement('div');
        element.className = `network-item ${network.status || 'unknown'}`;
        
        const statusIcon = this.getStatusIcon(network.status);
        const signalBars = this.getSignalBars(network.signalStrength);
        
        element.innerHTML = `
            <div class="network-header">
                <div class="network-name">
                    ${statusIcon}
                    <span class="ssid">${network.name || 'Hidden Network'}</span>
                    ${network.isConnected ? '<span class="connected-badge">Connected</span>' : ''}
                </div>
                <div class="network-signal">
                    ${signalBars}
                    <span class="signal-strength">${network.signalStrength || 0} dBm</span>
                </div>
            </div>
            <div class="network-details">
                <div class="network-info">
                    <span class="security">${network.securityType || 'Unknown'}</span>
                    <span class="channel">Ch: ${network.channel || 'N/A'}</span>
                    <span class="frequency">${network.frequency || 'N/A'} MHz</span>
                </div>
                <div class="network-mac">${network.macAddress || 'Unknown'}</div>
            </div>
        `;

        return element;
    }

    // Get status icon for network
    getStatusIcon(status) {
        const icons = {
            verified: '<i class="icon-check-circle" style="color: #10b981;"></i>',
            suspicious: '<i class="icon-alert-triangle" style="color: #f59e0b;"></i>',
            blocked: '<i class="icon-x-circle" style="color: #ef4444;"></i>',
            unknown: '<i class="icon-help-circle" style="color: #6b7280;"></i>'
        };
        return icons[status] || icons.unknown;
    }

    // Get signal strength bars
    getSignalBars(strength) {
        const level = Math.min(4, Math.max(0, Math.floor((strength + 100) / 15)));
        let bars = '';
        for (let i = 0; i < 4; i++) {
            bars += `<span class="signal-bar ${i < level ? 'active' : ''}"></span>`;
        }
        return `<div class="signal-bars">${bars}</div>`;
    }

    // Update last scan time
    updateLastScanTime(scanTime) {
        const element = document.getElementById('last-scan-time');
        if (element) {
            const date = new Date(scanTime);
            element.textContent = date.toLocaleString();
            element.title = `Last scan: ${date.toISOString()}`;
        }
    }

    // Update device info
    updateDeviceInfo(info) {
        if (info.deviceId) {
            const deviceElement = document.getElementById('mobile-device-id');
            if (deviceElement) {
                deviceElement.textContent = info.deviceId;
            }
        }

        if (info.location) {
            const locationElement = document.getElementById('mobile-location');
            if (locationElement) {
                locationElement.textContent = 
                    `${info.location.latitude.toFixed(4)}, ${info.location.longitude.toFixed(4)}`;
            }
        }
    }

    // Display new threat alert
    displayNewThreatAlert(threat) {
        const alertContainer = document.getElementById('alert-container');
        if (!alertContainer) return;

        const alert = document.createElement('div');
        alert.className = 'threat-alert';
        alert.innerHTML = `
            <div class="alert-header">
                <i class="icon-alert-triangle"></i>
                <span>New Threat Detected</span>
                <button class="alert-close" onclick="this.parentElement.parentElement.remove()">&times;</button>
            </div>
            <div class="alert-body">
                <strong>${threat.network.name || 'Unknown Network'}</strong>
                <p>${threat.reportType || 'Suspicious activity detected'}</p>
                <small>Device: ${threat.deviceId} | ${new Date(threat.timestamp).toLocaleString()}</small>
            </div>
        `;

        alertContainer.appendChild(alert);

        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (alert.parentElement) {
                alert.remove();
            }
        }, 10000);
    }

    // Update threats reports list
    updateThreatReportsList(reports) {
        const reportsContainer = document.getElementById('threat-reports-list');
        if (!reportsContainer) return;

        reportsContainer.innerHTML = '';

        reports.forEach(report => {
            const reportElement = this.createThreatReportElement(report);
            reportsContainer.appendChild(reportElement);
        });
    }

    // Create threat report element
    createThreatReportElement(report) {
        const element = document.createElement('div');
        element.className = 'threat-report-item';
        
        element.innerHTML = `
            <div class="report-header">
                <span class="report-type">${report.reportType || 'Unknown'}</span>
                <span class="report-status ${report.status}">${report.status}</span>
            </div>
            <div class="report-network">
                <strong>${report.network.name || 'Hidden Network'}</strong>
                <span class="report-mac">${report.network.macAddress || 'Unknown'}</span>
            </div>
            <div class="report-details">
                <div class="report-time">${new Date(report.timestamp).toLocaleString()}</div>
                <div class="report-device">Device: ${report.deviceId}</div>
            </div>
            ${report.additionalInfo ? `<div class="report-info">${report.additionalInfo}</div>` : ''}
        `;

        return element;
    }

    // Register callback for events
    onScanUpdate(callback) {
        this.callbacks.scanUpdate.push(callback);
    }

    onThreatUpdate(callback) {
        this.callbacks.threatUpdate.push(callback);
    }

    onConnectionChange(callback) {
        this.callbacks.connectionChange.push(callback);
    }

    // Notify callbacks
    notifyCallbacks(type, data) {
        this.callbacks[type].forEach(callback => {
            try {
                callback(data);
            } catch (error) {
                console.error(`Error in ${type} callback:`, error);
            }
        });
    }

    // Request scan update from mobile
    requestScanUpdate() {
        if (this.socket && this.isConnected) {
            this.socket.emit('requestScanUpdate');
        }
    }

    // Request threat reports
    requestThreatReports(limit = 10) {
        if (this.socket && this.isConnected) {
            this.socket.emit('requestThreatReports', { limit });
        }
    }

    // Get current scan data
    getCurrentScanData() {
        return this.scanData;
    }

    // Get threat reports
    getThreatReports() {
        return this.threatReports;
    }

    // Check connection status
    isConnectedToMobile() {
        return this.isConnected;
    }

    // Disconnect
    disconnect() {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
        }
        this.isConnected = false;
    }
}

// Create global instance
window.mobileIntegration = new MobileIntegration();

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.mobileIntegration.initialize();
    });
} else {
    window.mobileIntegration.initialize();
}

export default MobileIntegration;


// Data Export Utility
// Provides export functionality for CSV, JSON, and PDF formats

class DataExporter {
    constructor() {
        this.exportFormats = ['csv', 'json', 'pdf', 'excel'];
    }

    // Main export function
    async exportData(data, format, filename = 'export') {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
        const fullFilename = `${filename}_${timestamp}`;

        switch (format.toLowerCase()) {
            case 'csv':
                return this.exportCSV(data, fullFilename);
            case 'json':
                return this.exportJSON(data, fullFilename);
            case 'pdf':
                return await this.exportPDF(data, fullFilename);
            case 'excel':
                return this.exportExcel(data, fullFilename);
            default:
                throw new Error(`Unsupported export format: ${format}`);
        }
    }

    // Export as CSV
    exportCSV(data, filename) {
        let csv = '';
        
        // Handle array of objects
        if (Array.isArray(data) && data.length > 0) {
            // Get headers from first object
            const headers = Object.keys(data[0]);
            csv = headers.join(',') + '\n';
            
            // Add data rows
            data.forEach(row => {
                const values = headers.map(header => {
                    const value = row[header];
                    // Escape values containing commas or quotes
                    if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
                        return `"${value.replace(/"/g, '""')}"`;
                    }
                    return value ?? '';
                });
                csv += values.join(',') + '\n';
            });
        } else if (typeof data === 'object') {
            // Handle single object
            const entries = Object.entries(data);
            csv = 'Key,Value\n';
            entries.forEach(([key, value]) => {
                csv += `"${key}","${value}"\n`;
            });
        }

        this.downloadFile(csv, `${filename}.csv`, 'text/csv');
        return true;
    }

    // Export as JSON
    exportJSON(data, filename) {
        const json = JSON.stringify(data, null, 2);
        this.downloadFile(json, `${filename}.json`, 'application/json');
        return true;
    }

    // Export as PDF (requires additional library)
    async exportPDF(data, filename) {
        // Check if jsPDF is available
        if (typeof window.jspdf === 'undefined') {
            await this.loadJsPDF();
        }

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        
        // Add title
        doc.setFontSize(20);
        doc.text('DisCon-X Data Export', 20, 20);
        
        // Add timestamp
        doc.setFontSize(10);
        doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);
        
        // Add data
        let yPosition = 50;
        doc.setFontSize(12);
        
        if (Array.isArray(data)) {
            // Create table for array data
            if (data.length > 0) {
                const headers = Object.keys(data[0]);
                const tableData = data.map(row => headers.map(h => String(row[h] ?? '')));
                
                doc.autoTable({
                    head: [headers],
                    body: tableData,
                    startY: yPosition,
                    styles: { fontSize: 10 },
                    headStyles: { fillColor: [59, 130, 246] }
                });
            }
        } else if (typeof data === 'object') {
            // Display object as key-value pairs
            Object.entries(data).forEach(([key, value]) => {
                if (yPosition > 250) {
                    doc.addPage();
                    yPosition = 20;
                }
                doc.text(`${key}: ${JSON.stringify(value)}`, 20, yPosition);
                yPosition += 10;
            });
        }
        
        // Save the PDF
        doc.save(`${filename}.pdf`);
        return true;
    }

    // Export as Excel (using CSV format that Excel can open)
    exportExcel(data, filename) {
        // Create a more Excel-friendly CSV
        let csv = '\uFEFF'; // UTF-8 BOM for Excel
        
        if (Array.isArray(data) && data.length > 0) {
            const headers = Object.keys(data[0]);
            csv += headers.join('\t') + '\n';
            
            data.forEach(row => {
                const values = headers.map(header => {
                    const value = row[header];
                    return value ?? '';
                });
                csv += values.join('\t') + '\n';
            });
        }
        
        this.downloadFile(csv, `${filename}.xls`, 'application/vnd.ms-excel');
        return true;
    }

    // Helper function to download file
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    }

    // Load jsPDF library dynamically
    loadJsPDF() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
            script.onload = () => {
                // Load autoTable plugin
                const autoTableScript = document.createElement('script');
                autoTableScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.31/jspdf.plugin.autotable.min.js';
                autoTableScript.onload = resolve;
                autoTableScript.onerror = reject;
                document.head.appendChild(autoTableScript);
            };
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    // Export specific data types
    async exportNetworks(networks, format = 'csv') {
        const exportData = networks.map(network => ({
            'Network Name': network.ssid,
            'MAC Address': network.bssid,
            'Signal Strength': network.signalStrength,
            'Security': network.security,
            'Status': network.status,
            'Location': network.location,
            'Last Seen': new Date(network.lastSeen).toLocaleString()
        }));
        
        return this.exportData(exportData, format, 'networks');
    }

    async exportThreats(threats, format = 'csv') {
        const exportData = threats.map(threat => ({
            'Severity': threat.severity,
            'Time': new Date(threat.time).toLocaleString(),
            'Location': threat.location,
            'SSID': threat.ssid,
            'BSSID': threat.bssid,
            'Alert Type': threat.alertType,
            'Description': threat.description,
            'Status': threat.status
        }));
        
        return this.exportData(exportData, format, 'threats');
    }

    async exportAnalytics(analytics, format = 'json') {
        return this.exportData(analytics, format, 'analytics');
    }

    // Create export menu
    createExportMenu(containerId, data, defaultFilename = 'export') {
        const container = document.getElementById(containerId);
        if (!container) return;

        const exportMenu = document.createElement('div');
        exportMenu.className = 'export-menu';
        exportMenu.innerHTML = `
            <button class="export-trigger action-btn">
                <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" width="16" height="16">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                          d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4">
                    </path>
                </svg>
                Export Data
            </button>
            <div class="export-dropdown" style="display: none;">
                <button data-format="csv" class="export-option">
                    <span class="export-icon">📊</span> Export as CSV
                </button>
                <button data-format="json" class="export-option">
                    <span class="export-icon">📄</span> Export as JSON
                </button>
                <button data-format="pdf" class="export-option">
                    <span class="export-icon">📑</span> Export as PDF
                </button>
                <button data-format="excel" class="export-option">
                    <span class="export-icon">📈</span> Export as Excel
                </button>
            </div>
        `;

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .export-menu {
                position: relative;
                display: inline-block;
            }
            .export-dropdown {
                position: absolute;
                top: 100%;
                right: 0;
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
                margin-top: 8px;
                min-width: 200px;
                z-index: 1000;
            }
            .export-option {
                display: flex;
                align-items: center;
                gap: 12px;
                width: 100%;
                padding: 12px 16px;
                border: none;
                background: none;
                text-align: left;
                cursor: pointer;
                font-size: 14px;
                color: #374151;
                transition: background 0.2s;
            }
            .export-option:hover {
                background: #f3f4f6;
            }
            .export-option:first-child {
                border-radius: 8px 8px 0 0;
            }
            .export-option:last-child {
                border-radius: 0 0 8px 8px;
            }
            .export-icon {
                font-size: 18px;
            }

        `;
        document.head.appendChild(style);

        // Add event listeners
        const trigger = exportMenu.querySelector('.export-trigger');
        const dropdown = exportMenu.querySelector('.export-dropdown');
        
        trigger.addEventListener('click', () => {
            dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', (e) => {
            if (!exportMenu.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });

        // Handle export options
        exportMenu.querySelectorAll('.export-option').forEach(option => {
            option.addEventListener('click', async () => {
                const format = option.dataset.format;
                try {
                    await this.exportData(data, format, defaultFilename);
                    dropdown.style.display = 'none';
                    this.showNotification(`Data exported successfully as ${format.toUpperCase()}`);
                } catch (error) {
                    console.error('Export failed:', error);
                    this.showNotification('Export failed. Please try again.', 'error');
                }
            });
        });

        container.appendChild(exportMenu);
        return exportMenu;
    }

    showNotification(message, type = 'success') {
        // Use existing toast notification if available
        if (window.showToast) {
            window.showToast(message, type);
        } else {
            // Fallback to simple notification
            const notification = document.createElement('div');
            notification.className = `export-notification ${type}`;
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                padding: 16px 24px;
                background: ${type === 'success' ? '#10b981' : '#ef4444'};
                color: white;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 10000;
                animation: slideIn 0.3s ease;
            `;
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
    }
}

// Create singleton instance
const dataExporter = new DataExporter();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = dataExporter;
} else {
    window.dataExporter = dataExporter;
}

export default dataExporter;

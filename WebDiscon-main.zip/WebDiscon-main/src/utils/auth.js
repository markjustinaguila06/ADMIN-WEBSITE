// Authentication utility module for DisCon-X
class AuthManager {
    constructor() {
        this.isAuthenticated = false;
        this.userEmail = null;
        this.init();
    }

    init() {
        // Check if user is logged in on page load
        this.checkAuthStatus();
        
        // Set up logout timer (24 hours)
        this.setupLogoutTimer();
    }

    checkAuthStatus() {
        const loggedIn = localStorage.getItem('disconx_logged_in');
        const userEmail = localStorage.getItem('disconx_user_email');
        const loginTime = localStorage.getItem('disconx_login_time');

        if (loggedIn === 'true' && userEmail && loginTime) {
            // Check if login is still valid (24 hours)
            const loginDate = new Date(loginTime);
            const now = new Date();
            const hoursDiff = (now - loginDate) / (1000 * 60 * 60);

            if (hoursDiff < 24) {
                this.isAuthenticated = true;
                this.userEmail = userEmail;
                return true;
            } else {
                // Session expired
                this.logout();
                return false;
            }
        } else {
            this.isAuthenticated = false;
            return false;
        }
    }

    requireAuth() {
        if (!this.checkAuthStatus()) {
            this.redirectToLogin();
            return false;
        }
        return true;
    }

    redirectToLogin() {
        // Store current page for redirect after login
        const currentPage = window.location.pathname;
        if (currentPage !== '/login.html' && currentPage !== '/') {
            localStorage.setItem('disconx_redirect_after_login', currentPage);
        }
        
        window.location.href = 'login.html';
    }

    logout() {
        // Clear authentication data
        localStorage.removeItem('disconx_logged_in');
        localStorage.removeItem('disconx_user_email');
        localStorage.removeItem('disconx_login_time');
        localStorage.removeItem('disconx_redirect_after_login');
        
        this.isAuthenticated = false;
        this.userEmail = null;
        
        // Show logout message
        this.showLogoutMessage();
        
        // Redirect to login page
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
    }

    showLogoutMessage() {
        // Create logout notification
        const logoutNotification = document.createElement('div');
        logoutNotification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #1e1b4b, #4c1d95);
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 10000;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 14px;
            font-weight: 500;
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            animation: slideInRight 0.3s ease-out;
        `;
        
        logoutNotification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                </svg>
                <span>You have been logged out. Redirecting...</span>
            </div>
        `;

        // Add animation styles
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
        
        document.body.appendChild(logoutNotification);
        
        // Remove notification after animation
        setTimeout(() => {
            if (logoutNotification.parentNode) {
                logoutNotification.remove();
            }
        }, 2500);
    }

    setupLogoutTimer() {
        // Auto-logout after 24 hours
        const loginTime = localStorage.getItem('disconx_login_time');
        if (loginTime) {
            const loginDate = new Date(loginTime);
            const expiryTime = new Date(loginDate.getTime() + 24 * 60 * 60 * 1000);
            const now = new Date();
            const timeUntilExpiry = expiryTime - now;

            if (timeUntilExpiry > 0) {
                setTimeout(() => {
                    this.logout();
                }, timeUntilExpiry);
            }
        }
    }

    getUserInfo() {
        return {
            email: this.userEmail,
            isAuthenticated: this.isAuthenticated,
            loginTime: localStorage.getItem('disconx_login_time')
        };
    }

    updateUserDisplay() {
        // Update user info in the sidebar
        const userName = document.querySelector('.user-name');
        const userRole = document.querySelector('.user-role');
        const userAvatar = document.querySelector('.user-avatar');

        if (userName && this.userEmail) {
            // Extract name from email
            const name = this.userEmail.split('@')[0];
            const displayName = name.charAt(0).toUpperCase() + name.slice(1);
            userName.textContent = displayName;
            
            if (userAvatar) {
                const initials = displayName.substring(0, 2).toUpperCase();
                userAvatar.textContent = initials;
            }
        }

        if (userRole) {
            userRole.textContent = 'Administrator';
        }
    }
}

// Create global auth manager instance
window.authManager = new AuthManager();

// Export for use in modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AuthManager;
} 
// Performance Monitoring System
// Tracks and displays application performance metrics in real-time

class PerformanceMonitor {
    constructor() {
        this.metrics = {
            pageLoad: {},
            apiCalls: [],
            renderTimes: [],
            memoryUsage: [],
            networkLatency: [],
            errors: [],
            userInteractions: []
        };
        this.isMonitoring = false;
        this.observers = new Map();
        this.startTime = performance.now();
        this.init();
    }

    init() {
        // Start monitoring if Performance API is available
        if ('performance' in window) {
            this.startMonitoring();
            this.setupPerformanceObservers();
            this.monitorMemory();
            this.monitorNetwork();
            this.monitorErrors();
        }
    }

    startMonitoring() {
        this.isMonitoring = true;
        
        // Capture initial page load metrics
        window.addEventListener('load', () => {
            this.capturePageLoadMetrics();
        });

        // Monitor long tasks
        if ('PerformanceObserver' in window) {
            try {
                const longTaskObserver = new PerformanceObserver((list) => {
                    for (const entry of list.getEntries()) {
                        this.recordLongTask(entry);
                    }
                });
                longTaskObserver.observe({ entryTypes: ['longtask'] });
                this.observers.set('longtask', longTaskObserver);
            } catch (e) {
                console.warn('Long task monitoring not supported');
            }
        }
    }

    capturePageLoadMetrics() {
        const navigation = performance.getEntriesByType('navigation')[0];
        if (navigation) {
            this.metrics.pageLoad = {
                domContentLoaded: navigation.domContentLoadedEventEnd - navigation.domContentLoadedEventStart,
                loadComplete: navigation.loadEventEnd - navigation.loadEventStart,
                domInteractive: navigation.domInteractive,
                firstPaint: this.getFirstPaint(),
                firstContentfulPaint: this.getFirstContentfulPaint(),
                timeToInteractive: navigation.domInteractive - navigation.fetchStart,
                totalLoadTime: navigation.loadEventEnd - navigation.fetchStart,
                timestamp: new Date().toISOString()
            };
        }
    }

    getFirstPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const firstPaint = paintEntries.find(entry => entry.name === 'first-paint');
        return firstPaint ? firstPaint.startTime : 0;
    }

    getFirstContentfulPaint() {
        const paintEntries = performance.getEntriesByType('paint');
        const fcp = paintEntries.find(entry => entry.name === 'first-contentful-paint');
        return fcp ? fcp.startTime : 0;
    }

    setupPerformanceObservers() {
        // Observe resource timing
        if ('PerformanceObserver' in window) {
            try {
                const resourceObserver = new PerformanceObserver((list) => {
                    for (const entry of list.getEntries()) {
                        this.recordResourceTiming(entry);
                    }
                });
                resourceObserver.observe({ entryTypes: ['resource'] });
                this.observers.set('resource', resourceObserver);
            } catch (e) {
                console.warn('Resource timing monitoring not supported');
            }
        }
    }

    recordResourceTiming(entry) {
        if (entry.initiatorType === 'xmlhttprequest' || entry.initiatorType === 'fetch') {
            this.metrics.apiCalls.push({
                name: entry.name,
                duration: entry.duration,
                size: entry.transferSize,
                startTime: entry.startTime,
                responseTime: entry.responseEnd - entry.requestStart,
                timestamp: new Date().toISOString()
            });

            // Keep only last 100 API calls
            if (this.metrics.apiCalls.length > 100) {
                this.metrics.apiCalls.shift();
            }
        }
    }

    recordLongTask(entry) {
        console.warn('Long task detected:', {
            duration: entry.duration,
            startTime: entry.startTime,
            name: entry.name
        });
    }

    monitorMemory() {
        if ('memory' in performance) {
            setInterval(() => {
                const memInfo = performance.memory;
                this.metrics.memoryUsage.push({
                    usedJSHeapSize: memInfo.usedJSHeapSize,
                    totalJSHeapSize: memInfo.totalJSHeapSize,
                    jsHeapSizeLimit: memInfo.jsHeapSizeLimit,
                    timestamp: new Date().toISOString()
                });

                // Keep only last 60 samples (1 hour at 1 sample/minute)
                if (this.metrics.memoryUsage.length > 60) {
                    this.metrics.memoryUsage.shift();
                }
            }, 60000); // Check every minute
        }
    }

    monitorNetwork() {
        // Monitor network latency through API calls
        const originalFetch = window.fetch;
        window.fetch = async (...args) => {
            const startTime = performance.now();
            try {
                const response = await originalFetch(...args);
                const endTime = performance.now();
                this.recordNetworkLatency(args[0], endTime - startTime);
                return response;
            } catch (error) {
                const endTime = performance.now();
                this.recordNetworkLatency(args[0], endTime - startTime, true);
                throw error;
            }
        };
    }

    recordNetworkLatency(url, duration, failed = false) {
        this.metrics.networkLatency.push({
            url: typeof url === 'string' ? url : url.url,
            duration,
            failed,
            timestamp: new Date().toISOString()
        });

        // Keep only last 100 network requests
        if (this.metrics.networkLatency.length > 100) {
            this.metrics.networkLatency.shift();
        }
    }

    monitorErrors() {
        window.addEventListener('error', (event) => {
            this.recordError({
                message: event.message,
                source: event.filename,
                line: event.lineno,
                column: event.colno,
                stack: event.error?.stack,
                timestamp: new Date().toISOString()
            });
        });

        window.addEventListener('unhandledrejection', (event) => {
            this.recordError({
                message: `Unhandled Promise Rejection: ${event.reason}`,
                type: 'unhandledrejection',
                timestamp: new Date().toISOString()
            });
        });
    }

    recordError(error) {
        this.metrics.errors.push(error);
        
        // Keep only last 50 errors
        if (this.metrics.errors.length > 50) {
            this.metrics.errors.shift();
        }
    }

    // Track user interactions
    trackInteraction(action, target, duration = null) {
        this.metrics.userInteractions.push({
            action,
            target,
            duration,
            timestamp: new Date().toISOString()
        });

        // Keep only last 100 interactions
        if (this.metrics.userInteractions.length > 100) {
            this.metrics.userInteractions.shift();
        }
    }

    // Calculate performance score
    calculatePerformanceScore() {
        const scores = {
            pageLoad: 100,
            apiPerformance: 100,
            memoryUsage: 100,
            errorRate: 100
        };

        // Page load score (based on load time)
        const loadTime = this.metrics.pageLoad.totalLoadTime;
        if (loadTime) {
            if (loadTime < 2000) scores.pageLoad = 100;
            else if (loadTime < 4000) scores.pageLoad = 80;
            else if (loadTime < 6000) scores.pageLoad = 60;
            else if (loadTime < 8000) scores.pageLoad = 40;
            else scores.pageLoad = 20;
        }

        // API performance score (based on average response time)
        if (this.metrics.apiCalls.length > 0) {
            const avgResponseTime = this.metrics.apiCalls.reduce((sum, call) => 
                sum + call.responseTime, 0) / this.metrics.apiCalls.length;
            
            if (avgResponseTime < 200) scores.apiPerformance = 100;
            else if (avgResponseTime < 500) scores.apiPerformance = 80;
            else if (avgResponseTime < 1000) scores.apiPerformance = 60;
            else if (avgResponseTime < 2000) scores.apiPerformance = 40;
            else scores.apiPerformance = 20;
        }

        // Memory usage score
        if (this.metrics.memoryUsage.length > 0) {
            const latestMemory = this.metrics.memoryUsage[this.metrics.memoryUsage.length - 1];
            const usagePercent = (latestMemory.usedJSHeapSize / latestMemory.jsHeapSizeLimit) * 100;
            
            if (usagePercent < 30) scores.memoryUsage = 100;
            else if (usagePercent < 50) scores.memoryUsage = 80;
            else if (usagePercent < 70) scores.memoryUsage = 60;
            else if (usagePercent < 85) scores.memoryUsage = 40;
            else scores.memoryUsage = 20;
        }

        // Error rate score
        const errorRate = this.metrics.errors.length;
        if (errorRate === 0) scores.errorRate = 100;
        else if (errorRate < 5) scores.errorRate = 80;
        else if (errorRate < 10) scores.errorRate = 60;
        else if (errorRate < 20) scores.errorRate = 40;
        else scores.errorRate = 20;

        // Calculate overall score
        const overallScore = Object.values(scores).reduce((sum, score) => sum + score, 0) / Object.keys(scores).length;

        return {
            overall: Math.round(overallScore),
            breakdown: scores
        };
    }

    // Get current metrics
    getMetrics() {
        return {
            ...this.metrics,
            score: this.calculatePerformanceScore(),
            uptime: performance.now() - this.startTime,
            timestamp: new Date().toISOString()
        };
    }

    // Create performance dashboard UI
    createDashboard(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const dashboard = document.createElement('div');
        dashboard.className = 'performance-dashboard';
        dashboard.innerHTML = `
            <div class="perf-header">
                <h3>Performance Monitor</h3>
                <div class="perf-score">
                    <span class="score-label">Score:</span>
                    <span class="score-value" id="perf-score">--</span>
                </div>
            </div>
            
            <div class="perf-metrics-grid">
                <div class="perf-metric-card">
                    <div class="metric-icon">⚡</div>
                    <div class="metric-content">
                        <div class="metric-label">Page Load</div>
                        <div class="metric-value" id="page-load-time">--</div>
                        <div class="metric-detail">Total load time</div>
                    </div>
                </div>
                
                <div class="perf-metric-card">
                    <div class="metric-icon">🌐</div>
                    <div class="metric-content">
                        <div class="metric-label">API Latency</div>
                        <div class="metric-value" id="api-latency">--</div>
                        <div class="metric-detail">Average response</div>
                    </div>
                </div>
                
                <div class="perf-metric-card">
                    <div class="metric-icon">💾</div>
                    <div class="metric-content">
                        <div class="metric-label">Memory Usage</div>
                        <div class="metric-value" id="memory-usage">--</div>
                        <div class="metric-detail">JS Heap</div>
                    </div>
                </div>
                
                <div class="perf-metric-card">
                    <div class="metric-icon">⚠️</div>
                    <div class="metric-content">
                        <div class="metric-label">Errors</div>
                        <div class="metric-value" id="error-count">0</div>
                        <div class="metric-detail">Last hour</div>
                    </div>
                </div>
            </div>
            
            <div class="perf-charts">
                <canvas id="perf-timeline-chart"></canvas>
            </div>
            
            <div class="perf-details">
                <div class="detail-section">
                    <h4>Recent API Calls</h4>
                    <div id="recent-api-calls" class="detail-list"></div>
                </div>
                <div class="detail-section">
                    <h4>Recent Errors</h4>
                    <div id="recent-errors" class="detail-list"></div>
                </div>
            </div>
        `;

        // Add styles
        this.addDashboardStyles();

        container.appendChild(dashboard);

        // Start updating dashboard
        this.updateDashboard();
        setInterval(() => this.updateDashboard(), 5000);

        return dashboard;
    }

    updateDashboard() {
        const metrics = this.getMetrics();
        
        // Update score
        const scoreElement = document.getElementById('perf-score');
        if (scoreElement) {
            scoreElement.textContent = metrics.score.overall;
            scoreElement.className = `score-value ${this.getScoreClass(metrics.score.overall)}`;
        }

        // Update page load time
        const loadTimeElement = document.getElementById('page-load-time');
        if (loadTimeElement && metrics.pageLoad.totalLoadTime) {
            loadTimeElement.textContent = `${Math.round(metrics.pageLoad.totalLoadTime)}ms`;
        }

        // Update API latency
        const apiLatencyElement = document.getElementById('api-latency');
        if (apiLatencyElement && metrics.apiCalls.length > 0) {
            const avgLatency = metrics.apiCalls.reduce((sum, call) => 
                sum + call.responseTime, 0) / metrics.apiCalls.length;
            apiLatencyElement.textContent = `${Math.round(avgLatency)}ms`;
        }

        // Update memory usage
        const memoryElement = document.getElementById('memory-usage');
        if (memoryElement && metrics.memoryUsage.length > 0) {
            const latestMemory = metrics.memoryUsage[metrics.memoryUsage.length - 1];
            const usedMB = (latestMemory.usedJSHeapSize / 1024 / 1024).toFixed(1);
            const totalMB = (latestMemory.totalJSHeapSize / 1024 / 1024).toFixed(1);
            memoryElement.textContent = `${usedMB}/${totalMB} MB`;
        }

        // Update error count
        const errorCountElement = document.getElementById('error-count');
        if (errorCountElement) {
            errorCountElement.textContent = metrics.errors.length;
            errorCountElement.className = `metric-value ${metrics.errors.length > 0 ? 'has-errors' : ''}`;
        }

        // Update recent API calls
        this.updateRecentAPICalls(metrics.apiCalls.slice(-5));

        // Update recent errors
        this.updateRecentErrors(metrics.errors.slice(-5));
    }

    updateRecentAPICalls(calls) {
        const container = document.getElementById('recent-api-calls');
        if (!container) return;

        container.innerHTML = calls.map(call => `
            <div class="detail-item">
                <span class="detail-url">${this.truncateUrl(call.name)}</span>
                <span class="detail-time">${Math.round(call.responseTime)}ms</span>
            </div>
        `).join('');
    }

    updateRecentErrors(errors) {
        const container = document.getElementById('recent-errors');
        if (!container) return;

        if (errors.length === 0) {
            container.innerHTML = '<div class="no-errors">No recent errors</div>';
        } else {
            container.innerHTML = errors.map(error => `
                <div class="detail-item error-item">
                    <span class="error-message">${error.message}</span>
                    <span class="error-time">${new Date(error.timestamp).toLocaleTimeString()}</span>
                </div>
            `).join('');
        }
    }

    truncateUrl(url) {
        const maxLength = 40;
        if (url.length <= maxLength) return url;
        
        try {
            const urlObj = new URL(url);
            const path = urlObj.pathname + urlObj.search;
            if (path.length > maxLength - 10) {
                return urlObj.hostname + path.substr(0, maxLength - 10) + '...';
            }
            return urlObj.hostname + path;
        } catch {
            return url.substr(0, maxLength) + '...';
        }
    }

    getScoreClass(score) {
        if (score >= 90) return 'excellent';
        if (score >= 70) return 'good';
        if (score >= 50) return 'fair';
        return 'poor';
    }

    addDashboardStyles() {
        if (document.getElementById('performance-dashboard-styles')) return;

        const style = document.createElement('style');
        style.id = 'performance-dashboard-styles';
        style.textContent = `
            .performance-dashboard {
                background: white;
                border-radius: 12px;
                padding: 24px;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            }
            
            .perf-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 24px;
            }
            
            .perf-header h3 {
                font-size: 20px;
                font-weight: 700;
                color: #1f2937;
            }
            
            .perf-score {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .score-label {
                font-size: 14px;
                color: #6b7280;
                font-weight: 500;
            }
            
            .score-value {
                font-size: 32px;
                font-weight: 700;
            }
            
            .score-value.excellent { color: #10b981; }
            .score-value.good { color: #3b82f6; }
            .score-value.fair { color: #f59e0b; }
            .score-value.poor { color: #ef4444; }
            
            .perf-metrics-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 16px;
                margin-bottom: 24px;
            }
            
            .perf-metric-card {
                display: flex;
                align-items: center;
                gap: 16px;
                padding: 16px;
                background: #f9fafb;
                border-radius: 8px;
                border: 1px solid #e5e7eb;
            }
            
            .metric-icon {
                font-size: 32px;
            }
            
            .metric-content {
                flex: 1;
            }
            
            .metric-label {
                font-size: 12px;
                color: #6b7280;
                text-transform: uppercase;
                font-weight: 600;
                margin-bottom: 4px;
            }
            
            .metric-value {
                font-size: 24px;
                font-weight: 700;
                color: #1f2937;
            }
            
            .metric-value.has-errors {
                color: #ef4444;
            }
            
            .metric-detail {
                font-size: 11px;
                color: #9ca3af;
                margin-top: 2px;
            }
            
            .perf-charts {
                margin-bottom: 24px;
                height: 200px;
                background: #f9fafb;
                border-radius: 8px;
                padding: 16px;
            }
            
            .perf-details {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 24px;
            }
            
            .detail-section h4 {
                font-size: 14px;
                font-weight: 600;
                color: #374151;
                margin-bottom: 12px;
            }
            
            .detail-list {
                background: #f9fafb;
                border-radius: 8px;
                padding: 12px;
                max-height: 200px;
                overflow-y: auto;
            }
            
            .detail-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 8px;
                background: white;
                border-radius: 4px;
                margin-bottom: 8px;
                font-size: 12px;
            }
            
            .detail-item:last-child {
                margin-bottom: 0;
            }
            
            .detail-url {
                color: #374151;
                font-family: monospace;
                font-size: 11px;
                flex: 1;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            
            .detail-time {
                color: #6b7280;
                font-weight: 600;
                margin-left: 8px;
            }
            
            .error-item {
                background: #fee2e2;
                border: 1px solid #fecaca;
            }
            
            .error-message {
                color: #dc2626;
                flex: 1;
            }
            
            .error-time {
                color: #b91c1c;
                font-size: 10px;
            }
            
            .no-errors {
                text-align: center;
                color: #9ca3af;
                padding: 20px;
                font-size: 13px;
            }
            

            
            @media (max-width: 768px) {
                .perf-metrics-grid {
                    grid-template-columns: 1fr;
                }
                
                .perf-details {
                    grid-template-columns: 1fr;
                }
            }
        `;
        document.head.appendChild(style);
    }

    // Cleanup
    destroy() {
        this.isMonitoring = false;
        this.observers.forEach(observer => observer.disconnect());
        this.observers.clear();
    }
}

// Create singleton instance
const performanceMonitor = new PerformanceMonitor();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = performanceMonitor;
} else {
    window.performanceMonitor = performanceMonitor;
}

export default performanceMonitor;

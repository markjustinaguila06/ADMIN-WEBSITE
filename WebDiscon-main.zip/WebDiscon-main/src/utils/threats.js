// Threat-related functions
let threatData = {};  // Store threat data globally
let mockUpdateInterval = null;

let currentFilters = {
    search: '',
    severity: '',
    alertType: '',
    timeRange: ''
};
let currentPage = 1;
const itemsPerPage = 10;



// Initialize sample threat data for the dashboard
function initializeSampleThreats() {
    if (Object.keys(threatData).length === 0) {
        console.log('Initializing sample threat data...');
        
        // Generate initial sample threats
        const sampleThreats = [
            {
                severity: 'High',
                time: '7/1/2025, 8:41:53 PM',
                location: 'Data Center',
                ssid: 'SecureNet',
                bssid: 'F2:8C:DC:D8:35:59',
                signal: '-55 dBm',
                devices: '4',
                alertType: 'Unauthorized Access'
            },
            {
                severity: 'High',
                time: '7/1/2025, 8:41:08 PM',
                location: 'HQ Building',
                ssid: 'FREE_WIFI',
                bssid: '86:7B:FC:E2:DB:62',
                signal: '-54 dBm',
                devices: '5',
                alertType: 'Unauthorized Access'
            },
            {
                severity: 'High',
                time: '7/1/2025, 8:40:23 PM',
                location: 'Main Office',
                ssid: 'PublicWiFi',
                bssid: '66:B1:48:BC:E1:C2',
                signal: '-44 dBm',
                devices: '4',
                alertType: 'Suspicious Activity'
            }
        ];

        // Add enhanced data to each threat
        sampleThreats.forEach(threat => {
            threat.packetData = `Sample packet capture data for BSSID analysis...\n\n[IEEE 802.11 Frame]\nFrame Control: 0x80\nDuration: 0x0000\nDestination: ff:ff:ff:ff:ff:ff\nSource: ${threat.bssid}\nBSSID: ${threat.bssid}\n\n[Analysis]\nPacket Type: Management Frame\nSubtype: Beacon\nEncryption: ${Math.random() > 0.5 ? 'WPA2-PSK' : 'Open'}\nSignal Strength: ${threat.signal}`;
            
            threat.deviceData = [
                {
                    mac: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                    type: ['Smartphone', 'Laptop', 'Tablet', 'IoT Device', 'Smart TV'][Math.floor(Math.random() * 5)],
                    lastSeen: new Date(Date.now() - Math.random() * 300000).toLocaleString()
                },
                {
                    mac: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                    type: ['Smartphone', 'Laptop', 'Tablet', 'IoT Device', 'Smart TV'][Math.floor(Math.random() * 5)],
                    lastSeen: new Date(Date.now() - Math.random() * 600000).toLocaleString()
                }
            ];
            
            threat.comparisonData = {
                legitimate: {
                    ssid: threat.ssid,
                    bssid: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                    security: ['WPA2-PSK', 'WPA3-SAE', 'WPA-PSK'][Math.floor(Math.random() * 3)],
                    signal: `-${Math.floor(Math.random() * 20 + 30)} dBm`,
                    vendor: ['Cisco', 'Netgear', 'Linksys', 'TP-Link'][Math.floor(Math.random() * 4)],
                    firstSeen: '2024-01-15'
                },
                suspicious: {
                    ssid: threat.ssid,
                    bssid: threat.bssid,
                    security: 'Open',
                    signal: threat.signal,
                    vendor: 'Unknown',
                    firstSeen: new Date().toLocaleDateString()
                }
            };
            
            // Store in threatData
            threatData[threat.bssid] = threat;
        });
        
        console.log('Sample threat data initialized:', Object.keys(threatData).length, 'threats');
    }
}

export function renderRecentThreatActivity() {
    console.log('Rendering recent threat activity...');
    initializeSampleThreats(); // Ensure we have data
    renderThreatTable('recent-threat-table');
}

// Make applyFilters available globally
window.applyFilters = applyFilters;

export function renderThreatsTable() {
    renderThreatTable('threats-table');
    setupThreatFilters();
    setupThreatSearch();
    setupPagination();
}





function setupThreatFilters() {
    const severityFilter = document.getElementById('severityFilter');
    const alertTypeFilter = document.getElementById('alertTypeFilter');
    const timeRangeFilter = document.getElementById('timeRangeFilter');
    
    if (severityFilter) {
        severityFilter.addEventListener('change', (e) => {
            currentFilters.severity = e.target.value;
            applyFilters();
        });
    }
    
    if (alertTypeFilter) {
        alertTypeFilter.addEventListener('change', (e) => {
            currentFilters.alertType = e.target.value;
            applyFilters();
        });
    }
    
    if (timeRangeFilter) {
        timeRangeFilter.addEventListener('change', (e) => {
            currentFilters.timeRange = e.target.value;
            applyFilters();
        });
    }
}

function setupThreatSearch() {
    const searchInput = document.getElementById('threatSearchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            currentFilters.search = e.target.value.toLowerCase().trim();
            applyFilters();
        });
    }
}

function applyFilters() {
    const filteredThreats = filterThreats();
    renderFilteredThreats(filteredThreats);
    updatePagination(filteredThreats.length);
}

function filterThreats() {
    let threats = Object.values(threatData);
    
    // Apply search filter
    if (currentFilters.search) {
        threats = threats.filter(threat => 
            threat.location.toLowerCase().includes(currentFilters.search) ||
            threat.ssid.toLowerCase().includes(currentFilters.search) ||
            threat.bssid.toLowerCase().includes(currentFilters.search) ||
            threat.alertType.toLowerCase().includes(currentFilters.search)
        );
    }
    
    // Apply severity filter
    if (currentFilters.severity) {
        threats = threats.filter(threat => 
            threat.severity.toLowerCase() === currentFilters.severity.toLowerCase()
        );
    }
    
    // Apply alert type filter
    if (currentFilters.alertType) {
        threats = threats.filter(threat => 
            threat.alertType === currentFilters.alertType
        );
    }
    
    // Apply time range filter
    if (currentFilters.timeRange) {
        const now = new Date();
        const cutoffTime = new Date();
        
        switch (currentFilters.timeRange) {
            case '1h':
                cutoffTime.setHours(now.getHours() - 1);
                break;
            case '24h':
                cutoffTime.setDate(now.getDate() - 1);
                break;
            case '7d':
                cutoffTime.setDate(now.getDate() - 7);
                break;
        }
        
        threats = threats.filter(threat => 
            new Date(threat.time) >= cutoffTime
        );
    }
    
    return threats.sort((a, b) => new Date(b.time) - new Date(a.time));
}

function renderFilteredThreats(threats) {
    const tableBody = document.querySelector('#threats-table tbody');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageThreats = threats.slice(startIndex, endIndex);
    
    pageThreats.forEach(threat => {
        addThreatRow(tableBody, threat, 'threats-table');
    });
    
    // Show empty state if no threats
    if (pageThreats.length === 0) {
        showEmptyState(tableBody);
    }
}

function showEmptyState(container) {
    container.innerHTML = `
        <tr>
            <td colspan="9" class="empty-state">
                <div class="empty-state-content">
                    <div class="empty-state-icon">🔍</div>
                    <div class="empty-state-text">No threats found</div>
                    <div class="empty-state-subtext">Try adjusting your filters or search terms</div>
                </div>
            </td>
        </tr>
    `;
}

function updatePagination(totalItems) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const paginationInfo = document.getElementById('paginationInfo');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    
    if (paginationInfo) {
        const start = Math.min((currentPage - 1) * itemsPerPage + 1, totalItems);
        const end = Math.min(currentPage * itemsPerPage, totalItems);
        paginationInfo.textContent = `Showing ${start}-${end} of ${totalItems} threats`;
    }
    
    if (prevBtn) {
        prevBtn.disabled = currentPage <= 1;
    }
    
    if (nextBtn) {
        nextBtn.disabled = currentPage >= totalPages;
    }
    
    // Update pagination numbers
    updatePaginationNumbers(totalPages);
}

function updatePaginationNumbers(totalPages) {
    const numbersContainer = document.querySelector('.pagination-numbers');
    if (!numbersContainer) return;
    
    numbersContainer.innerHTML = '';
    
    for (let i = 1; i <= Math.min(totalPages, 5); i++) {
        const button = document.createElement('button');
        button.className = `pagination-number ${i === currentPage ? 'active' : ''}`;
        button.textContent = i;
        button.onclick = () => goToPage(i);
        numbersContainer.appendChild(button);
    }
    
    if (totalPages > 5) {
        const ellipsis = document.createElement('span');
        ellipsis.className = 'pagination-ellipsis';
        ellipsis.textContent = '...';
        numbersContainer.appendChild(ellipsis);
        
        const lastButton = document.createElement('button');
        lastButton.className = `pagination-number ${totalPages === currentPage ? 'active' : ''}`;
        lastButton.textContent = totalPages;
        lastButton.onclick = () => goToPage(totalPages);
        numbersContainer.appendChild(lastButton);
    }
}

function goToPage(page) {
    currentPage = page;
    applyFilters();
}

// Add pagination event listeners
function setupPagination() {
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                goToPage(currentPage - 1);
            }
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const filteredThreats = filterThreats();
            const totalPages = Math.ceil(filteredThreats.length / itemsPerPage);
            if (currentPage < totalPages) {
                goToPage(currentPage + 1);
            }
        });
    }
}

function renderThreatTable(tableId) {
    console.log(`Rendering threat table: ${tableId}`);
    const tableBody = document.querySelector(`#${tableId} tbody`);
    if (!tableBody) {
        console.error(`Table body not found for: ${tableId}`);
        return;
    }

    // Clear existing rows
    tableBody.innerHTML = '';

    // Get all threats, sorted by time descending (most recent first)
    const allThreats = Object.values(threatData).sort((a, b) => new Date(b.time) - new Date(a.time));
    console.log(`Found ${allThreats.length} threats to display`);

    // For dashboard, only show up to 3 most recent
    let threatsToShow = allThreats;
    if (tableId === 'recent-threat-table') {
        threatsToShow = allThreats.slice(0, 3);
        console.log(`Showing ${threatsToShow.length} recent threats for dashboard`);
    }

    // If no threats available, show a placeholder row
    if (threatsToShow.length === 0) {
        console.log('No threats to display, showing placeholder');
        const placeholderRow = document.createElement('tr');
        placeholderRow.innerHTML = `
            <td colspan="9" style="text-align: center; padding: 40px; color: #9ca3af;">
                <div style="display: flex; flex-direction: column; align-items: center; gap: 8px;">
                    <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="opacity: 0.5;">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span style="font-weight: 500;">No recent threats detected</span>
                    <span style="font-size: 0.875rem;">Your network is secure</span>
                </div>
            </td>
        `;
        tableBody.appendChild(placeholderRow);
        return;
    }

    // Render threats
    threatsToShow.forEach((threat, index) => {
        console.log(`Rendering threat ${index + 1}:`, threat.ssid, threat.alertType);
        addThreatRow(tableBody, threat, tableId);
    });

    // Start real-time updates if not already running
    if (!mockUpdateInterval) {
        console.log('Starting mock updates...');
        startMockUpdates();
    }
}

// Mock data generator for testing - Enhanced
function generateMockThreat() {
    const locations = ['Main Office', 'Branch Office', 'Remote Site', 'HQ Building', 'Data Center', 'Campus WiFi', 'Public Library', 'Coffee Shop Network'];
    const ssids = ['OfficeWiFi', 'GuestNetwork', 'StaffAccess', 'SecureNet', 'PublicWiFi', 'CafeWiFi', 'FREE_WIFI', 'LINKSYS_DEFAULT'];
    const severities = ['High', 'Medium', 'Low'];
    const alertTypes = ['Evil Twin', 'Rogue AP', 'Suspicious Activity', 'Unauthorized Access'];
    
    return {
        severity: severities[Math.floor(Math.random() * severities.length)],
        time: new Date().toLocaleString(),
        location: locations[Math.floor(Math.random() * locations.length)],
        ssid: ssids[Math.floor(Math.random() * ssids.length)],
        bssid: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
        signal: `-${Math.floor(Math.random() * 40 + 40)} dBm`,
        devices: Math.floor(Math.random() * 5 + 1).toString(),
        alertType: alertTypes[Math.floor(Math.random() * alertTypes.length)],
        packetData: `Sample packet capture data for BSSID analysis...\n\n[IEEE 802.11 Frame]\nFrame Control: 0x80\nDuration: 0x0000\nDestination: ff:ff:ff:ff:ff:ff\nSource: ${Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':')}\nBSSID: ${Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':')}\n\n[Analysis]\nPacket Type: Management Frame\nSubtype: Beacon\nEncryption: ${Math.random() > 0.5 ? 'WPA2-PSK' : 'Open'}\nSignal Strength: -${Math.floor(Math.random() * 40 + 40)} dBm`,
        deviceData: [
            {
                mac: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                type: ['Smartphone', 'Laptop', 'Tablet', 'IoT Device', 'Smart TV'][Math.floor(Math.random() * 5)],
                lastSeen: new Date(Date.now() - Math.random() * 300000).toLocaleString()
            },
            {
                mac: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                type: ['Smartphone', 'Laptop', 'Tablet', 'IoT Device', 'Smart TV'][Math.floor(Math.random() * 5)],
                lastSeen: new Date(Date.now() - Math.random() * 600000).toLocaleString()
            }
        ],
        comparisonData: {
            legitimate: {
                ssid: ssids[Math.floor(Math.random() * ssids.length)],
                bssid: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                security: ['WPA2-PSK', 'WPA3-SAE', 'WPA-PSK'][Math.floor(Math.random() * 3)],
                signal: `-${Math.floor(Math.random() * 20 + 30)} dBm`,
                vendor: ['Cisco', 'Netgear', 'Linksys', 'TP-Link'][Math.floor(Math.random() * 4)],
                firstSeen: '2024-01-15'
            },
            suspicious: {
                ssid: ssids[Math.floor(Math.random() * ssids.length)],
                bssid: Array(6).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
                security: 'Open',
                signal: `-${Math.floor(Math.random() * 40 + 40)} dBm`,
                vendor: 'Unknown',
                firstSeen: new Date().toLocaleDateString()
            }
        }
    };
}

function addThreatRow(tableBody, threat, tableId) {
    console.log(`Adding threat row to ${tableId}:`, threat.bssid, threat.alertType);
    
    const row = document.createElement('tr');
    const modalPrefix = tableId === 'threats-table' ? 'threats-modal-' : 'modal-';
    row.innerHTML = `
        <td><span class="severity-badge ${threat.severity.toLowerCase()}">${threat.severity}</span></td>
        <td>${threat.time}</td>
        <td>${threat.location}</td>
        <td>${threat.ssid}</td>
        <td class="mac-address">${threat.bssid}</td>
        <td>${threat.signal}</td>
        <td>${threat.devices}</td>
        <td>${threat.alertType}</td>
        <td class="action-buttons">
            <button onclick="openForensicsModal('${modalPrefix}packets', '${threat.bssid}')" class="action-btn small" title="View packet capture">Packets</button>
            <button onclick="openForensicsModal('${modalPrefix}devices', '${threat.bssid}')" class="action-btn small" title="View connected devices">Devices</button>
            <button onclick="openForensicsModal('${modalPrefix}compare', '${threat.bssid}')" class="action-btn small" title="Compare with legitimate AP">Compare</button>
        </td>
    `;

    // Add animation class only for dashboard table, but only if less than 3 rows
    if (tableId === 'recent-threat-table') {
        const rows = tableBody.getElementsByTagName('tr');
        if (rows.length < 3) {
            row.classList.add('new-threat');
            setTimeout(() => {
                row.classList.remove('new-threat');
            }, 1000);
        }
    }

    // Insert at the top of the table
    if (tableBody.firstChild) {
        tableBody.insertBefore(row, tableBody.firstChild);
    } else {
        tableBody.appendChild(row);
    }

    // For dashboard, keep only 3 rows
    if (tableId === 'recent-threat-table') {
        const rows = tableBody.getElementsByTagName('tr');
        while (rows.length > 3) {
            tableBody.removeChild(rows[rows.length - 1]);
        }
    }
    
    console.log(`Threat row added successfully. Table now has ${tableBody.getElementsByTagName('tr').length} rows`);
}

export function addNewThreatToTable(threat) {
    // Store threat data
    threatData[threat.bssid] = threat;

    // Add to both tables
    const tables = ['recent-threat-table', 'threats-table'];
    tables.forEach(tableId => {
        const tableBody = document.querySelector(`#${tableId} tbody`);
        if (tableBody) {
            addThreatRow(tableBody, threat, tableId);
        }
    });

    // Show evil twin alert if it's an evil twin threat
    if (threat.alertType === 'Evil Twin') {
        showEvilTwinAlert();
    }
}

export function showEvilTwinAlert() {
    const alert = document.createElement('div');
    alert.className = 'evil-twin-alert';
    alert.innerHTML = `
        <div class="alert-content">
            <h3>⚠️ Evil Twin Detected!</h3>
            <p>A suspicious network matching a known legitimate network has been detected.</p>
            <button onclick="this.parentElement.parentElement.remove()">Dismiss</button>
        </div>
    `;
    document.body.appendChild(alert);
    
    // Auto-remove after animation completes (5.6 seconds total)
    setTimeout(() => {
        if (alert && alert.parentElement) {
            alert.remove();
        }
    }, 5600);
}

export function openForensicsModal(modalId, bssid) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    const threat = threatData[bssid];
    if (!threat) return;

    let content = '';
    switch (modalId) {
        case 'threats-modal-packets':
        case 'modal-packets':
            content = `
                <div class="modal-header">
                    <h3>📦 Packet Capture Analysis</h3>
                    <span class="forensics-modal-close" onclick="closeForensicsModal('${modalId}')">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="packet-info">
                        <div class="info-row">
                            <span class="info-label">Target BSSID:</span>
                            <span class="info-value">${threat.bssid}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Capture Time:</span>
                            <span class="info-value">${threat.time}</span>
                        </div>
                        <div class="info-row">
                            <span class="info-label">Alert Type:</span>
                            <span class="info-value">${threat.alertType}</span>
                        </div>
                    </div>
                    <div class="packet-data">
                        <h4>Packet Analysis</h4>
                        <pre>${threat.packetData}</pre>
                    </div>
                    <div class="modal-actions">
                        <button class="action-btn primary" onclick="downloadPacketCapture('${threat.bssid}')">
                            📄 Download .pcap File
                        </button>
                        <button class="action-btn secondary" onclick="generateReport('${threat.bssid}')">
                            📊 Generate Report
                        </button>
                    </div>
                </div>
            `;
            break;
        case 'threats-modal-devices':
        case 'modal-devices':
            content = `
                <div class="modal-header">
                    <h3>📱 Connected Devices Analysis</h3>
                    <span class="forensics-modal-close" onclick="closeForensicsModal('${modalId}')">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="devices-summary">
                        <div class="summary-card">
                            <div class="summary-number">${threat.deviceData.length}</div>
                            <div class="summary-label">Devices Detected</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-number">${threat.devices}</div>
                            <div class="summary-label">Active Connections</div>
                        </div>
                    </div>
                    <div class="device-list">
                        <h4>Device Details</h4>
                        ${threat.deviceData.map(device => `
                            <div class="device-item">
                                <div class="device-header">
                                    <div class="device-icon">📱</div>
                                    <div class="device-info">
                                        <div class="device-mac">${device.mac}</div>
                                        <div class="device-type">${device.type}</div>
                                    </div>
                                    <div class="device-status active">Active</div>
                                </div>
                                <div class="device-details">
                                    <div class="detail-item">
                                        <span class="detail-label">Last Seen:</span>
                                        <span class="detail-value">${device.lastSeen}</span>
                                    </div>
                                    <div class="detail-item">
                                        <span class="detail-label">Connection Type:</span>
                                        <span class="detail-value">802.11n</span>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
            break;
        case 'threats-modal-compare':
        case 'modal-compare':
            content = `
                <div class="modal-header">
                    <h3>🔍 AP Comparison: ${threat.alertType}</h3>
                    <span class="forensics-modal-close" onclick="closeForensicsModal('${modalId}')">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="comparison-grid">
                        <div class="comparison-item legitimate">
                            <div class="comparison-header">
                                <div class="comparison-icon">✅</div>
                                <h4>Legitimate Access Point</h4>
                            </div>
                            <div class="comparison-details">
                                <div class="detail-row">
                                    <span class="detail-label">SSID:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.ssid}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">BSSID:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.bssid}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Security:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.security}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Signal:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.signal}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Vendor:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.vendor}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">First Seen:</span>
                                    <span class="detail-value">${threat.comparisonData.legitimate.firstSeen}</span>
                                </div>
                            </div>
                        </div>
                        <div class="comparison-item suspicious">
                            <div class="comparison-header">
                                <div class="comparison-icon">⚠️</div>
                                <h4>Suspicious Access Point</h4>
                            </div>
                            <div class="comparison-details">
                                <div class="detail-row">
                                    <span class="detail-label">SSID:</span>
                                    <span class="detail-value">${threat.comparisonData.suspicious.ssid}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">BSSID:</span>
                                    <span class="detail-value">${threat.comparisonData.suspicious.bssid}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Security:</span>
                                    <span class="detail-value danger">${threat.comparisonData.suspicious.security}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Signal:</span>
                                    <span class="detail-value">${threat.comparisonData.suspicious.signal}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">Vendor:</span>
                                    <span class="detail-value danger">${threat.comparisonData.suspicious.vendor}</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">First Seen:</span>
                                    <span class="detail-value">${threat.comparisonData.suspicious.firstSeen}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="threat-analysis">
                        <h4>🔬 Threat Analysis</h4>
                        <div class="analysis-points">
                            <div class="analysis-point risk">
                                <span class="point-icon">⚠️</span>
                                <span class="point-text">SSID name similarity suggests potential evil twin attack</span>
                            </div>
                            <div class="analysis-point risk">
                                <span class="point-icon">🔓</span>
                                <span class="point-text">Open security configuration is suspicious for this network type</span>
                            </div>
                            <div class="analysis-point info">
                                <span class="point-icon">📍</span>
                                <span class="point-text">Geographic proximity detected between legitimate and suspicious APs</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            break;
    }

    modal.querySelector('.forensics-modal-content').innerHTML = content;
    modal.style.display = 'block';
}

export function closeForensicsModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// Utility functions for enhanced functionality
window.clearAllFilters = function() {
    console.log('Clearing all filters');
    document.querySelectorAll('#severityFilter, #alertTypeFilter, #timeRangeFilter').forEach(filter => {
        if (filter) filter.value = '';
    });
    const searchInput = document.getElementById('threatSearchInput');
    if (searchInput) searchInput.value = '';
    
    // Reset filters
    currentFilters = {
        search: '',
        severity: '',
        alertType: '',
        timeRange: ''
    };
    
    applyFilters();
    if (typeof window.showToast === 'function') {
        window.showToast('All filters cleared', 'info');
    }
};

window.exportThreats = function() {
    console.log('Exporting threats');
    if (typeof window.showToast === 'function') {
        window.showToast('Generating threat report...', 'info');
    }
    
    setTimeout(() => {
        const threats = Object.values(threatData);
        let csvContent = 'Severity,Time,Location,SSID,BSSID,Signal,Devices,Alert Type\n';
        
        threats.forEach(threat => {
            csvContent += `${threat.severity},${threat.time},${threat.location},${threat.ssid},${threat.bssid},${threat.signal},${threat.devices},${threat.alertType}\n`;
        });
        
        const blob = new Blob([csvContent], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `threat_report_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        window.URL.revokeObjectURL(url);
        
        if (typeof window.showToast === 'function') {
            window.showToast('Threat report exported successfully!', 'success');
        }
    }, 1000);
};

window.refreshThreats = function() {
    console.log('Refreshing threats');
    renderThreatsTable();
    if (typeof window.showToast === 'function') {
        window.showToast('Threat data refreshed', 'success');
    }
};

window.downloadPacketCapture = function(bssid) {
    showToast('Packet capture file download started...', 'info');
    // Simulate download
    setTimeout(() => {
        showToast('Packet capture downloaded successfully!', 'success');
    }, 2000);
};

window.generateReport = function(bssid) {
    showToast('Generating detailed threat report...', 'info');
    // Simulate report generation
    setTimeout(() => {
        showToast('Threat report generated successfully!', 'success');
    }, 3000);
};

function generateCSVContent(threats) {
    const headers = ['Severity', 'Time', 'Location', 'SSID', 'BSSID', 'Signal', 'Devices', 'Alert Type'];
    const csvRows = [headers.join(',')];
    
    threats.forEach(threat => {
        const row = [
            threat.severity,
            threat.time,
            threat.location,
            threat.ssid,
            threat.bssid,
            threat.signal,
            threat.devices,
            threat.alertType
        ];
        csvRows.push(row.join(','));
    });
    
    return csvRows.join('\n');
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${getToastIcon(type)}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

function getToastIcon(type) {
    switch (type) {
        case 'success': return '✅';
        case 'error': return '❌';
        case 'warning': return '⚠️';
        default: return 'ℹ️';
    }
}

// Initialize real-time updates when the threats section is shown
export function initializeThreatsSection() {
    // Initialize both tables
    renderThreatTable('recent-threat-table');
    renderThreatTable('threats-table');
    
    // Start real-time updates if not already running
    if (!mockUpdateInterval) {
        startMockUpdates();
    }
}

// Clean up when leaving the threats section
export function cleanupThreatsSection() {
    stopMockUpdates();
    if (threatChart) {
        threatChart.destroy();
        threatChart = null;
    }
}

function startMockUpdates() {
    // Clear any existing interval
    if (mockUpdateInterval) {
        clearInterval(mockUpdateInterval);
    }
    
    // Add initial mock threats
    for (let i = 0; i < 15; i++) {
        const mockThreat = generateMockThreat();
        addNewThreatToTable(mockThreat);
    }
    
    // Add a new threat every 15 seconds
    mockUpdateInterval = setInterval(() => {
        const mockThreat = generateMockThreat();
        addNewThreatToTable(mockThreat);
    }, 15000);
}

function stopMockUpdates() {
    if (mockUpdateInterval) {
        clearInterval(mockUpdateInterval);
        mockUpdateInterval = null;
    }
}

// Make functions globally accessible
window.addNewThreatToTable = addNewThreatToTable;
window.showEvilTwinAlert = showEvilTwinAlert;
window.openForensicsModal = openForensicsModal;
window.closeForensicsModal = closeForensicsModal;
window.goToPage = goToPage;
window.testThreatActivity = () => {
    const mockThreat = generateMockThreat();
    addNewThreatToTable(mockThreat);
};

// Add manual initialization functions for debugging
window.initializeThreatData = function() {
    console.log('Manual threat data initialization...');
    initializeSampleThreats();
    renderRecentThreatActivity();
    console.log('Threat data initialized. Current threats:', Object.keys(threatData).length);
};

window.forceRenderThreats = function() {
    console.log('Force rendering threat tables...');
    renderThreatTable('recent-threat-table');
    renderThreatTable('threats-table');
};

window.debugThreatData = function() {
    console.log('Current threat data:', threatData);
    console.log('Number of threats:', Object.keys(threatData).length);
    const recentTable = document.querySelector('#recent-threat-table tbody');
    const threatsTable = document.querySelector('#threats-table tbody');
    console.log('Recent table rows:', recentTable ? recentTable.children.length : 'table not found');
    console.log('Threats table rows:', threatsTable ? threatsTable.children.length : 'table not found');
}; 
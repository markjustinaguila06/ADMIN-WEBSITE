// Import components
import Sidebar from './components/Sidebar/Sidebar.js';
import Header from './components/Header/Header.js';
import Card from './components/Card/Card.js';

// Import utilities
import { initializeMap, cleanupMap, initializeCoverageMap, zoomToProvince } from './utils/map.js';
import { renderTrendsChart, cleanupChart } from './utils/charts.js';
import { renderThreatsTable, renderRecentThreatActivity, initializeThreatsSection, cleanupThreatsSection, openForensicsModal, closeForensicsModal, showEvilTwinAlert, addNewThreatToTable } from './utils/threats.js';

// Global state
let dashboardMap = null;
let coverageMap = null;
let currentSection = 'dashboard';
let isInitialized = false; // Prevent multiple initializations

// Initialize components
function showSection(sectionName) {
    try {
        console.log(`Switching to section: ${sectionName}`);
        
        // Hide all sections by removing active class
        document.querySelectorAll('.main-content > div').forEach(section => {
            section.classList.remove('active');
        });

        // Show selected section
        const selectedSection = document.querySelector(`.${sectionName}`);
        if (selectedSection) {
            selectedSection.classList.add('active');
            console.log(`Section ${sectionName} activated`);
        } else {
            console.warn(`Section ${sectionName} not found`);
            return;
        }

        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        const selectedNavItem = document.querySelector(`.nav-item[data-section="${sectionName}"]`);
        if (selectedNavItem) {
            selectedNavItem.classList.add('active');
            console.log(`Navigation updated for: ${sectionName}`);
        }

        // Update page title
        const pageTitle = document.querySelector('.page-title');
        if (pageTitle) {
            const titles = {
                'dashboard': 'Dashboard',
                'coverage-map': 'Coverage Map',
                'networks': 'Wi-Fi Networks',
                'safety-tips': 'Safety Tips',
                'threats': 'Threat Activity',
                'analytics-reports': 'Analytics & Reports',
                'users': 'User Management',
                'whitelist': 'Whitelist Management',
                'notifications': 'Notifications',
                'reports': 'Reports',
                'settings': 'Settings'
            };
            pageTitle.textContent = titles[sectionName] || 'Dashboard';
        }

        // Initialize section-specific functionality
        switch (sectionName) {
            case 'dashboard':
                if (!dashboardMap) {
                    setTimeout(() => {
                        try {
                            dashboardMap = initializeMap('dashboardMap');
                        } catch (error) {
                            console.error('Failed to initialize dashboard map:', error);
                        }
                    }, 100);
                }
                // Initialize recent threat activity
                try {
                    renderRecentThreatActivity();
                    console.log('Recent threat activity initialized for dashboard');
                } catch (error) {
                    console.error('Failed to initialize recent threat activity:', error);
                }
                
                // Setup View Full button
                setTimeout(() => {
                    const viewFullBtn = document.getElementById('viewFullMapBtn');
                    if (viewFullBtn) {
                        viewFullBtn.addEventListener('click', () => {
                            showSection('coverage-map');
                        });
                    }
                }, 200);
                break;
            case 'coverage-map':
                if (!coverageMap) {
                    setTimeout(() => {
                        try {
                            coverageMap = initializeCoverageMap();
                        } catch (error) {
                            console.error('Failed to initialize coverage map:', error);
                        }
                    }, 100);
                }
                break;
            case 'threats':
                if (typeof window.initializeEnhancedThreats === 'function') {
                    setTimeout(() => {
                        try {
                            window.initializeEnhancedThreats();
                            window.renderEnhancedThreats('threats-section');
                        } catch (error) {
                            console.error('Failed to initialize enhanced threats:', error);
                            // Fallback to original threats
                            renderThreatsTable();
                        }
                    }, 100);
                } else {
                    renderThreatsTable();
                }
                break;
            case 'networks':
                if (typeof window.renderWiFiNetworks === 'function') {
                    setTimeout(() => {
                        try {
                            window.renderWiFiNetworks('wifi-networks-container');
                        } catch (error) {
                            console.error('Failed to render WiFi networks:', error);
                        }
                    }, 100);
                }
                break;
            case 'whitelist':
                if (typeof window.renderWhitelistTable === 'function') {
                    setTimeout(() => {
                        try {
                            window.renderWhitelistTable('whitelist-table-container');
                        } catch (error) {
                            console.error('Failed to render whitelist table:', error);
                        }
                    }, 100);
                } else {
                    console.warn('Whitelist table function not available');
                }
                break;
            case 'analytics-reports':
                if (typeof window.renderAnalyticsReports === 'function') {
                    setTimeout(() => {
                        try {
                            window.renderAnalyticsReports('analytics-reports-container');
                        } catch (error) {
                            console.error('Failed to render analytics reports:', error);
                        }
                    }, 100);
                }
                break;
        }

        currentSection = sectionName;

        // Dispatch section loaded event
        document.dispatchEvent(new CustomEvent('sectionLoaded', {
            detail: { section: sectionName }
        }));
        
        console.log(`Successfully switched to ${sectionName}`);
    } catch (error) {
        console.error('Error switching sections:', error);
    }
}

// Initialize threat data function for quick actions
function initializeThreatData() {
    console.log('Initializing threat data...');
    if (typeof addNewThreatToTable === 'function') {
        const newThreat = {
            severity: 'High',
            time: new Date().toLocaleString(),
            location: 'Test Location',
            ssid: 'TEST_EVIL_TWIN',
            bssid: '00:' + Array(5).fill(0).map(() => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(':').toUpperCase(),
            signal: '-45 dBm',
            devices: '3',
            alertType: 'Evil Twin'
        };
        
        addNewThreatToTable(newThreat);
        console.log('Test threat added successfully');
        showToast('Test threat added to activity feed', 'success');
    }
}

// Quick Action Functions - All Dashboard Buttons
function addNewWhitelistEntry() {
    console.log('Opening Add New Whitelist Entry modal...');
    showSection('whitelist');
    setTimeout(() => {
        if (typeof window.showWhitelistModal === 'function') {
            window.showWhitelistModal();
        } else {
            showToast('Whitelist management loaded. Click "Add Network" button.', 'info');
        }
    }, 500);
}



function configureAlertSettings() {
    console.log('Opening alert settings...');
    showAlertConfigModal();
}

function exportSecurityReport() {
    console.log('Generating security report...');
    showToast('Generating security report...', 'info');
    
    setTimeout(() => {
        const reportData = generateSecurityReportData();
        downloadReport(reportData, 'security_report.csv');
        showToast('Security report downloaded successfully!', 'success');
    }, 1500);
}



// Modal Functions
function showAlertConfigModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content-modern" style="max-width: 600px;">
            <div class="modal-header">
                <div class="modal-header-content">
                    <div class="modal-title-modern">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        Alert Settings
                    </div>
                    <button class="modal-close-x" onclick="this.closest('.modal-overlay').remove()">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Alert Threshold</label>
                    <select class="form-control">
                        <option>High Priority Only</option>
                        <option selected>Medium & High Priority</option>
                        <option>All Alerts</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Notification Methods</label>
                    <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 8px;">
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="checkbox" checked> Email Alerts
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="checkbox" checked> SMS Alerts
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="checkbox"> Push Notifications
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Alert Frequency</label>
                    <select class="form-control">
                        <option>Immediate</option>
                        <option selected>Every 5 minutes</option>
                        <option>Every 15 minutes</option>
                        <option>Hourly</option>
                    </select>
                </div>
            </div>
            
            <div class="modal-footer-modern">
                <button type="button" class="btn-modern btn-modern-secondary" onclick="this.closest('.modal-overlay').remove()">Cancel</button>
                <button type="button" class="btn-modern btn-modern-success" onclick="saveAlertSettings(this)">Save Settings</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function saveAlertSettings(button) {
    showToast('Alert settings saved successfully!', 'success');
    button.closest('.modal-overlay').remove();
}

// Utility Functions
function generateSecurityReportData() {
    const date = new Date().toLocaleDateString();
    return `Security Report - ${date}
Networks Scanned,1254
Verified Networks,987
Suspicious Networks,37
Threats Detected,15
Last Update,${new Date().toLocaleString()}

Regional Breakdown:
Cavite,287,231,28
Laguna,342,298,12
Batangas,215,187,8
Rizal,263,209,9
Quezon,147,62,3`;
}

function downloadReport(content, filename) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

function showToast(message, type = 'info') {
    // Remove existing toasts
    document.querySelectorAll('.toast').forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${icons[type] || icons.info}</span>
            <span class="toast-message">${message}</span>
        </div>
    `;
    
    // Add toast styles if not already present
    if (!document.getElementById('toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.innerHTML = `
            .toast {
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border-radius: 8px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                z-index: 10000;
                min-width: 300px;
                max-width: 500px;
                animation: slideInRight 0.3s ease-out;
            }
            
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            
            .toast-content {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 16px;
            }
            
            .toast-icon {
                font-size: 18px;
                flex-shrink: 0;
            }
            
            .toast-message {
                color: #374151;
                font-weight: 500;
            }
            
            .toast-success {
                border-left: 4px solid #10b981;
            }
            
            .toast-error {
                border-left: 4px solid #ef4444;
            }
            
            .toast-warning {
                border-left: 4px solid #f59e0b;
            }
            
            .toast-info {
                border-left: 4px solid #3b82f6;
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(toast);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        if (toast && toast.parentElement) {
            toast.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => toast.remove(), 300);
        }
    }, 3000);
}

// Export province detail functions for map popups
function showProvinceDetails(provinceName) {
    console.log(`Showing details for ${provinceName}`);
    showToast(`Loading detailed analytics for ${provinceName}...`, 'info');
    setTimeout(() => {
        showToast(`${provinceName} analytics: 95% network coverage, 12 active threats monitored`, 'success');
    }, 1000);
}

function showProvinceNetworks(provinceName) {
    console.log(`Showing networks for ${provinceName}`);
    showSection('networks');
    showToast(`Filtering networks for ${provinceName} province`, 'info');
}

function exportProvinceData(provinceName) {
    console.log(`Exporting data for ${provinceName}`);
    const csvContent = `Province,Networks,Verified,Suspicious,Coverage
${provinceName},${Math.floor(Math.random() * 200 + 100)},${Math.floor(Math.random() * 150 + 80)},${Math.floor(Math.random() * 10 + 3)},${Math.floor(Math.random() * 20 + 70)}%`;
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${provinceName}_data.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    showToast(`${provinceName} data exported successfully!`, 'success');
}

// Quick action functions
function clearAllFilters() {
    console.log('Clearing all filters');
    document.querySelectorAll('#severityFilter, #alertTypeFilter, #timeRangeFilter').forEach(filter => {
        if (filter) filter.value = '';
    });
    const searchInput = document.getElementById('threatSearchInput');
    if (searchInput) searchInput.value = '';
    // Trigger filter update if function exists
    if (typeof window.applyFilters === 'function') {
        window.applyFilters();
    }
    showToast('All filters cleared', 'info');
}

function exportThreats() {
    console.log('Exporting threats');
    showToast('Generating threat report...', 'info');
    setTimeout(() => {
        const threatData = `Threat Report - ${new Date().toLocaleDateString()}
Severity,Time,Location,SSID,BSSID,Signal,Devices,Alert Type
High,${new Date().toLocaleString()},Data Center,SecureNet,F2:8C:DC:D8:35:59,-55 dBm,4,Unauthorized Access`;
        downloadReport(threatData, 'threat_report.csv');
        showToast('Threat report exported successfully!', 'success');
    }, 1000);
}

function refreshThreats() {
    console.log('Refreshing threats');
    if (typeof renderThreatsTable === 'function') {
        renderThreatsTable();
    }
    showToast('Threat data refreshed', 'success');
}

// Quick action modal functions
function openQuickActionModal() {
    const modal = document.getElementById('quickActionModal');
    if (modal) modal.style.display = 'block';
}

function closeQuickActionModal() {
    const modal = document.getElementById('quickActionModal');
    if (modal) modal.style.display = 'none';
}

function blockThreat() {
    showToast('Network blocked successfully', 'success');
    closeQuickActionModal();
}

function addToWhitelist() {
    showToast('Network added to whitelist', 'success');
    closeQuickActionModal();
}

function investigateThreat() {
    showToast('Deep investigation initiated', 'info');
    closeQuickActionModal();
}

function createAlert() {
    showToast('Security alert created', 'success');
    closeQuickActionModal();
}

// Auto-refresh toggle functionality
function setupAutoRefresh() {
    const autoRefreshToggle = document.getElementById('autoRefresh');
    if (autoRefreshToggle) {
        autoRefreshToggle.addEventListener('change', (e) => {
            if (e.target.checked) {
                showToast('Auto-refresh enabled', 'success');
                // Start auto-refresh logic here
            } else {
                showToast('Auto-refresh disabled', 'info');
                // Stop auto-refresh logic here
            }
        });
    }
}

// Map network action functions
function reportThreat(networkId) {
    console.log(`Reporting threat for network: ${networkId}`);
    showToast('Threat reported to security team', 'success');
}

function verifyNetwork(networkId) {
    console.log(`Verifying network: ${networkId}`);
    showToast('Network verification initiated', 'info');
    setTimeout(() => {
        showToast('Network verified successfully', 'success');
    }, 1500);
}

// Make functions globally available
window.showSection = showSection;
window.zoomToProvince = zoomToProvince;
window.openForensicsModal = openForensicsModal;
window.closeForensicsModal = closeForensicsModal;
window.showEvilTwinAlert = showEvilTwinAlert;
window.initializeThreatData = initializeThreatData;
window.showProvinceDetails = showProvinceDetails;
window.showProvinceNetworks = showProvinceNetworks;
window.exportProvinceData = exportProvinceData;
window.clearAllFilters = clearAllFilters;
window.exportThreats = exportThreats;
window.refreshThreats = refreshThreats;
window.openQuickActionModal = openQuickActionModal;
window.closeQuickActionModal = closeQuickActionModal;
window.blockThreat = blockThreat;
window.addToWhitelist = addToWhitelist;
window.investigateThreat = investigateThreat;
window.createAlert = createAlert;

// Core functionality functions
window.addNewWhitelistEntry = addNewWhitelistEntry;
window.exportSecurityReport = exportSecurityReport;
window.showToast = showToast;
window.reportThreat = reportThreat;
window.verifyNetwork = verifyNetwork;
window.saveAlertSettings = saveAlertSettings;

// Setup navigation event listeners
function setupNavigationHandlers() {
    try {
        console.log('Setting up navigation handlers...');
        
        // Remove existing navigation listeners to prevent duplicates
        document.querySelectorAll('.nav-item').forEach(item => {
            // Clone node to remove all event listeners
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);
        });

        // Add fresh navigation listeners
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                console.log(`Navigation clicked for section: ${section}`);
                if (section) {
                    showSection(section);
                }
            });
        });

        // Handle "View All" and "Back to Dashboard" links
        document.querySelectorAll('a[onclick^="showSection"]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const match = link.getAttribute('onclick').match(/showSection\('([^']+)'\)/);
                if (match && match[1]) {
                    showSection(match[1]);
                }
            });
        });

        console.log('Navigation handlers set up successfully');
    } catch (error) {
        console.error('Error setting up navigation handlers:', error);
    }
}

// Initialize application
document.addEventListener('DOMContentLoaded', () => {
    // Check if already initialized
    if (isInitialized) {
        console.log('App already initialized, skipping...');
        return;
    }

    try {
        console.log('Initializing application...');
        
        // Mark as initialized
        isInitialized = true;
        
        // Setup navigation first
        setupNavigationHandlers();
        
        // Update user display with logged-in user's email
        if (window.authManager && window.authManager.updateUserDisplay) {
            setTimeout(() => {
                window.authManager.updateUserDisplay();
                console.log('User display updated with logged-in user info');
            }, 100);
        }
        
        // Show initial section
        showSection('dashboard');

        // Initialize trends chart
        renderTrendsChart('Last 7 Days');

        // Initialize recent threat activity for dashboard
        setTimeout(() => {
            try {
                console.log('Initializing recent threat activity on app startup...');
                renderRecentThreatActivity();
            } catch (error) {
                console.error('Failed to initialize recent threat activity on startup:', error);
            }
        }, 200);

        // Force map initialization after a short delay
        setTimeout(() => {
            try {
                if (!dashboardMap) {
                    console.log('Forcing dashboard map initialization...');
                    dashboardMap = initializeMap('dashboardMap');
                }
            } catch (error) {
                console.error('Failed to force initialize dashboard map:', error);
            }
        }, 500);

        // Setup sidebar toggle with improved state management
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const mainContent = document.querySelector('.main-content');

        if (menuToggle && sidebar) {
            // Remove existing listeners
            const newMenuToggle = menuToggle.cloneNode(true);
            menuToggle.parentNode.replaceChild(newMenuToggle, menuToggle);
            
            newMenuToggle.addEventListener('click', () => {
                const isCollapsed = sidebar.classList.contains('collapsed');
                sidebar.classList.toggle('collapsed');
                
                if (mainContent) {
                    if (!isCollapsed) {
                        mainContent.style.marginLeft = '60px';
                    } else {
                        mainContent.style.marginLeft = '280px';
                    }
                }
                
                // Show/hide overlay for mobile
                if (window.innerWidth <= 900) {
                    if (sidebarOverlay) {
                        sidebarOverlay.style.display = isCollapsed ? 'none' : 'block';
                    }
                }
            });
        }

        if (sidebarOverlay) {
            // Remove existing listeners
            const newSidebarOverlay = sidebarOverlay.cloneNode(true);
            sidebarOverlay.parentNode.replaceChild(newSidebarOverlay, sidebarOverlay);
            
            newSidebarOverlay.addEventListener('click', () => {
                if (sidebar) {
                    sidebar.classList.add('collapsed');
                }
                newSidebarOverlay.style.display = 'none';
                if (mainContent) mainContent.style.marginLeft = '280px';
            });
        }

        // Handle window resize
        window.addEventListener('resize', () => {
            try {
                if (dashboardMap && typeof dashboardMap.invalidateSize === 'function') {
                    dashboardMap.invalidateSize();
                }
                if (coverageMap && typeof coverageMap.invalidateSize === 'function') {
                    coverageMap.invalidateSize();
                }
            } catch (error) {
                console.error('Error handling window resize:', error);
            }
        });

        // Add search bar event listeners for different maps
        const searchInputs = ['dashboardMapSearchInput', 'coverageMapSearchInput'];
        searchInputs.forEach(inputId => {
            const searchInput = document.getElementById(inputId);
            if (searchInput) {
                searchInput.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        try {
                            zoomToProvince(searchInput.value.trim());
                        } catch (error) {
                            console.error('Error zooming to province:', error);
                        }
                    }
                });
            }
        });

        // Add zoom control event listeners
        const zoomControls = [
            { inId: 'dashboardZoomIn', outId: 'dashboardZoomOut', mapGetter: () => dashboardMap },
            { inId: 'coverageZoomIn', outId: 'coverageZoomOut', mapGetter: () => coverageMap }
        ];

        zoomControls.forEach(({ inId, outId, mapGetter }) => {
            const zoomInBtn = document.getElementById(inId);
            const zoomOutBtn = document.getElementById(outId);
            
            if (zoomInBtn) {
                zoomInBtn.addEventListener('click', () => {
                    const map = mapGetter();
                    if (map) map.zoomIn();
                });
            }
            
            if (zoomOutBtn) {
                zoomOutBtn.addEventListener('click', () => {
                    const map = mapGetter();
                    if (map) map.zoomOut();
                });
            }
        });

        // Setup auto-refresh toggle
        setupAutoRefresh();

        // Setup logout button
        const logoutBtn = document.querySelector('.logout-btn');
        if (logoutBtn && window.authManager) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                window.authManager.logout();
            });
        }

        console.log('Application initialized successfully');
    } catch (error) {
        console.error('Failed to initialize application:', error);
    }
});

// Cleanup on unload
window.addEventListener('beforeunload', () => {
    try {
        cleanupMap();
        cleanupChart();
        cleanupThreatsSection();
    } catch (error) {
        console.error('Error during cleanup:', error);
    }
}); 
import Card from './Card';
import './Card.css';

export default Card; 
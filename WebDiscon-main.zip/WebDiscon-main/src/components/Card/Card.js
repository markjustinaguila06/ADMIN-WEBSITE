// Card Component
class Card {
    constructor(options = {}) {
        this.options = {
            title: options.title || '',
            className: options.className || '',
            content: options.content || '',
            ...options
        };
    }

    render() {
        const card = document.createElement('div');
        card.className = `card ${this.options.className}`.trim();

        if (this.options.title) {
            const header = document.createElement('div');
            header.className = 'card-header';
            
            const title = document.createElement('div');
            title.className = 'card-title';
            title.textContent = this.options.title;
            
            header.appendChild(title);
            card.appendChild(header);
        }

        if (this.options.content) {
            const content = document.createElement('div');
            content.className = 'card-content';
            content.innerHTML = this.options.content;
            card.appendChild(content);
        }

        return card;
    }

    static create(options) {
        const card = new Card(options);
        return card.render();
    }
}

export default Card; 
import Header from './Header';
import './Header.css';

export default Header; 
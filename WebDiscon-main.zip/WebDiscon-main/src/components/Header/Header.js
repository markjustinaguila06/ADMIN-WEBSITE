// Header Component
class Header {
    constructor() {
        this.element = null;
        this.isInitialized = false;
    }

    init() {
        try {
            this.element = document.querySelector('.header');
            if (!this.element) {
                console.error('Header element not found');
                return;
            }

            // Check if already initialized to prevent duplicate event listeners
            if (this.isInitialized) {
                return;
            }

            this.setupEventListeners();
            this.render();
            this.isInitialized = true;
        } catch (error) {
            console.error('Error initializing header:', error);
        }
    }

    setupEventListeners() {
        try {
            const notificationBtn = this.element.querySelector('.header-icon-btn');
            if (notificationBtn) {
                // Remove existing listeners to prevent duplicates
                const newNotificationBtn = notificationBtn.cloneNode(true);
                notificationBtn.parentNode.replaceChild(newNotificationBtn, notificationBtn);
                
                newNotificationBtn.addEventListener('click', () => this.handleNotifications());
            }
        } catch (error) {
            console.error('Error setting up header event listeners:', error);
        }
    }

    handleNotifications() {
        try {
            // Handle notification button click
            console.log('Notifications clicked');
            // Add your notification logic here
            
            // Example: Show a notification dropdown or modal
            this.showNotificationPanel();
        } catch (error) {
            console.error('Error handling notifications:', error);
        }
    }

    showNotificationPanel() {
        try {
            // Create or show notification panel
            let notificationPanel = document.getElementById('notificationPanel');
            if (!notificationPanel) {
                notificationPanel = document.createElement('div');
                notificationPanel.id = 'notificationPanel';
                notificationPanel.className = 'notification-panel';
                notificationPanel.innerHTML = `
                    <div class="notification-header">
                        <h3>Notifications</h3>
                        <button onclick="this.parentElement.parentElement.remove()">&times;</button>
                    </div>
                    <div class="notification-content">
                        <p>No new notifications</p>
                    </div>
                `;
                document.body.appendChild(notificationPanel);
            }
            
            notificationPanel.style.display = 'block';
        } catch (error) {
            console.error('Error showing notification panel:', error);
        }
    }

    setTitle(title) {
        try {
            const titleElement = this.element.querySelector('.page-title');
            if (titleElement) {
                titleElement.textContent = title;
            } else {
                console.warn('Page title element not found');
            }
        } catch (error) {
            console.error('Error setting page title:', error);
        }
    }

    render() {
        try {
            // Header is already in HTML, just ensure proper state
            if (!this.element) {
                console.error('Header element not found during render');
            }
        } catch (error) {
            console.error('Error rendering header:', error);
        }
    }

    // Cleanup method
    destroy() {
        try {
            this.isInitialized = false;
            // Remove any custom event listeners if needed
        } catch (error) {
            console.error('Error destroying header:', error);
        }
    }
}

export default Header; 
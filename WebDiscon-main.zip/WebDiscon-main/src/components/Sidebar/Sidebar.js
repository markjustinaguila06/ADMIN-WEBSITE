// Sidebar Component
class Sidebar {
    constructor() {
        this.element = null;
        this.isCollapsed = false;
        this.isInitialized = false;
    }

    // Initialize the sidebar
    init() {
        try {
            this.element = document.getElementById('sidebar');
            if (!this.element) {
                console.error('Sidebar element not found');
                return;
            }

            // Check if already initialized to prevent duplicate event listeners
            if (this.isInitialized) {
                return;
            }

            this.setupEventListeners();
            this.render();
            this.isInitialized = true;
        } catch (error) {
            console.error('Error initializing sidebar:', error);
        }
    }

    // Setup event listeners
    setupEventListeners() {
        try {
            const menuToggle = document.getElementById('menuToggle');
            if (menuToggle) {
                // Remove existing listeners to prevent duplicates
                const newMenuToggle = menuToggle.cloneNode(true);
                menuToggle.parentNode.replaceChild(newMenuToggle, menuToggle);
                
                newMenuToggle.addEventListener('click', () => this.toggleSidebar());
            }

            // Add click listeners for navigation items
            const navItems = this.element.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                // Remove existing listeners to prevent duplicates
                const newItem = item.cloneNode(true);
                item.parentNode.replaceChild(newItem, item);
                
                newItem.addEventListener('click', (e) => {
                    const section = e.currentTarget.dataset.section;
                    if (section && typeof window.showSection === 'function') {
                        window.showSection(section);
                    }
                });
            });
        } catch (error) {
            console.error('Error setting up sidebar event listeners:', error);
        }
    }

    // Toggle sidebar visibility
    toggleSidebar() {
        try {
            this.isCollapsed = !this.isCollapsed;
            this.element.classList.toggle('collapsed', this.isCollapsed);
            
            // Update main content margin
            const mainContent = document.querySelector('.main-content');
            if (mainContent) {
                if (this.isCollapsed) {
                    mainContent.style.marginLeft = '60px';
                } else {
                    mainContent.style.marginLeft = '220px';
                }
            }

            // Handle mobile overlay
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            if (sidebarOverlay && window.innerWidth <= 900) {
                sidebarOverlay.style.display = this.isCollapsed ? 'none' : 'block';
            }
        } catch (error) {
            console.error('Error toggling sidebar:', error);
        }
    }

    // Collapse sidebar
    collapse() {
        try {
            this.isCollapsed = true;
            this.element.classList.add('collapsed');
            
            const mainContent = document.querySelector('.main-content');
            if (mainContent) {
                mainContent.style.marginLeft = '60px';
            }

            const sidebarOverlay = document.getElementById('sidebarOverlay');
            if (sidebarOverlay) {
                sidebarOverlay.style.display = 'none';
            }
        } catch (error) {
            console.error('Error collapsing sidebar:', error);
        }
    }

    // Expand sidebar
    expand() {
        try {
            this.isCollapsed = false;
            this.element.classList.remove('collapsed');
            
            const mainContent = document.querySelector('.main-content');
            if (mainContent) {
                mainContent.style.marginLeft = '220px';
            }

            const sidebarOverlay = document.getElementById('sidebarOverlay');
            if (sidebarOverlay && window.innerWidth <= 900) {
                sidebarOverlay.style.display = 'block';
            }
        } catch (error) {
            console.error('Error expanding sidebar:', error);
        }
    }

    // Render the sidebar
    render() {
        try {
            // Sidebar is already in HTML, just ensure proper state
            this.element.classList.toggle('collapsed', this.isCollapsed);
        } catch (error) {
            console.error('Error rendering sidebar:', error);
        }
    }

    // Cleanup method
    destroy() {
        try {
            this.isInitialized = false;
            // Remove any custom event listeners if needed
        } catch (error) {
            console.error('Error destroying sidebar:', error);
        }
    }
}

// Export the component
export default Sidebar; 
# Firebase Database Schema for DisCon-X

This document outlines the Firestore database schema and collections used in the DisCon-X application.

## 🗂️ Collections Overview

### 1. `network_scans`
Stores network scan data from mobile devices.

```json
{
  "id": "auto-generated-id",
  "lastScan": "2024-01-15T10:30:00.000Z",
  "networks": [
    {
      "ssid": "WiFi_Network_Name",
      "bssid": "00:11:22:33:44:55",
      "security": "WPA2",
      "signalStrength": -45,
      "frequency": 2412,
      "capabilities": ["WPA2-PSK-CCMP"],
      "isConnected": false,
      "isSuspicious": false
    }
  ],
  "statistics": {
    "totalNetworks": 25,
    "suspiciousNetworks": 2,
    "verifiedNetworks": 20,
    "threatsDetected": 1
  },
  "deviceId": "device_unique_id",
  "location": {
    "latitude": 14.2117,
    "longitude": 121.1644,
    "accuracy": 10.0,
    "city": "Manila",
    "address": "Sample Address"
  },
  "timestamp": "firestore-server-timestamp",
  "createdAt": "2024-01-15T10:30:00.000Z"
}
```

**Indexes:**
- `timestamp` (desc) + `deviceId` (asc)
- `deviceId` (asc) + `timestamp` (desc)

### 2. `threat_reports`
Stores threat reports submitted by mobile devices.

```json
{
  "id": "auto-generated-id",
  "network": {
    "ssid": "Suspicious_Network",
    "bssid": "00:11:22:33:44:55",
    "security": "OPEN",
    "signalStrength": -35
  },
  "location": {
    "latitude": 14.2117,
    "longitude": 121.1644,
    "accuracy": 5.0,
    "city": "Manila",
    "address": "Sample Location"
  },
  "deviceId": "device_unique_id",
  "additionalInfo": "Network appeared suddenly with strong signal",
  "reportType": "suspicious", // "suspicious", "evil_twin", "malicious", "other"
  "status": "pending", // "pending", "investigating", "resolved", "dismissed"
  "timestamp": "firestore-server-timestamp",
  "createdAt": "2024-01-15T10:30:00.000Z",
  "updatedAt": "firestore-server-timestamp"
}
```

**Indexes:**
- `timestamp` (desc) + `status` (asc)
- `reportType` (asc) + `timestamp` (desc)
- `status` (asc) + `timestamp` (desc)

### 3. `safety_tips`
Stores security education content.

```json
{
  "id": "1", // tip ID
  "category": "password", // "password", "router_security", "encryption", etc.
  "priority": "high", // "low", "medium", "high"
  "icon": "user",
  "iconColor": "blue",
  "title": "Use strong, unique passwords",
  "description": "Use strong, unique passwords for your Wi-Fi and devices.",
  "details": "Create complex passwords with at least 12 characters...",
  "iconSvg": "M12 17v.01M12 13a4 4 0 0 1 4 4v1H8v-1a4 4 0 0 1 4-4z...",
  "importedAt": "firestore-server-timestamp"
}
```

**Indexes:**
- `category` (asc) + `priority` (asc)
- `priority` (asc) + `category` (asc)

### 4. `safety_tips_metadata`
Stores metadata about safety tips.

```json
{
  "id": "current",
  "version": "1.0",
  "lastUpdated": "2024-01-15T10:30:00.000Z",
  "totalTips": 8,
  "categories": ["password", "router_security", "encryption", "firmware"],
  "importedAt": "firestore-server-timestamp"
}
```

### 5. `whitelists`
Stores whitelist metadata.

```json
{
  "id": "current",
  "version": "1.0.0",
  "lastUpdated": "firestore-server-timestamp",
  "checksum": "sha256-hash",
  "accessPointsCount": 1500
}
```

### 6. `whitelist_data`
Stores actual whitelist data (for smaller lists).

```json
{
  "id": "current",
  "accessPoints": [
    {
      "ssid": "Trusted_Network",
      "bssid": "00:11:22:33:44:55",
      "security": "WPA3",
      "verified": true,
      "verificationDate": "2024-01-15T10:30:00.000Z"
    }
  ],
  "importedAt": "firestore-server-timestamp"
}
```

### 7. `config`
Stores application configuration.

```json
{
  "id": "mobile_app",
  "scanInterval": 30,
  "threatDetectionEnabled": true,
  "autoReportThreats": false,
  "maxNetworksToStore": 100,
  "apiVersion": "1.0.0",
  "features": {
    "realTimeScanning": true,
    "gpsTracking": true,
    "threatReporting": true,
    "whitelistSync": true
  },
  "serverEndpoints": {
    "scanData": "/api/mobile/scan-data",
    "threatReport": "/api/mobile/threat-report",
    "safetyTips": "/api/safety-tips"
  },
  "updatedAt": "firestore-server-timestamp"
}
```

### 8. `analytics`
Stores analytics events.

```json
{
  "id": "auto-generated-id",
  "eventType": "network_scan", // "network_scan", "threat_detected", "app_open", etc.
  "eventData": {
    "networkCount": 25,
    "scanDuration": 5000,
    "threatsFound": 1
  },
  "deviceId": "device_unique_id",
  "appVersion": "1.0.0",
  "platform": "android", // "android", "ios"
  "location": {
    "latitude": 14.2117,
    "longitude": 121.1644,
    "city": "Manila"
  },
  "timestamp": "firestore-server-timestamp",
  "createdAt": "2024-01-15T10:30:00.000Z"
}
```

**Indexes:**
- `eventType` (asc) + `timestamp` (desc)
- `deviceId` (asc) + `timestamp` (desc)

### 9. `users` (for future authentication)
Stores user data when authentication is implemented.

```json
{
  "id": "user_uid",
  "email": "user@example.com",
  "displayName": "User Name",
  "photoURL": "https://...",
  "preferences": {
    "notifications": true,
    "autoScanning": true,
    "shareAnalytics": false
  },
  "deviceIds": ["device_id_1", "device_id_2"],
  "createdAt": "firestore-server-timestamp",
  "lastLoginAt": "firestore-server-timestamp"
}
```

## 🔥 Firebase Storage Structure

### `/whitelists/`
```
/whitelists/
  /current/
    whitelist_latest.json    # Full whitelist data
    whitelist_v1.0.0.json   # Versioned backups
  /archive/
    whitelist_2024-01-15.json
```

### `/exports/`
```
/exports/
  /network_scans/
    scan_data_2024-01-15.json
  /threat_reports/
    threat_reports_2024-01-15.json
  /analytics/
    analytics_2024-01-15.json
```

### `/users/` (future)
```
/users/
  /{userId}/
    profile_picture.jpg
    scan_exports/
      my_scan_data.json
```

## 🛡️ Security Rules

### Firestore Rules
- All data is readable/writable (development mode)
- Production should implement proper authentication
- Safety tips are read-only for clients
- Config data is read-only for clients

### Storage Rules
- Whitelists are read-only for clients
- Users can only access their own data (when auth is implemented)
- Exports are accessible to authenticated users

## 📊 Data Flow

1. **Mobile Scan Data Flow:**
   ```
   Mobile App → POST /api/mobile/scan-data → Firebase Service → network_scans collection
   ```

2. **Threat Report Flow:**
   ```
   Mobile App → POST /api/mobile/threat-report → Firebase Service → threat_reports collection
   ```

3. **Real-time Dashboard Updates:**
   ```
   Firebase Service → WebSocket → Dashboard → Live UI Updates
   ```

4. **Configuration Sync:**
   ```
   Firebase config collection → GET /api/mobile/config → Mobile App
   ```

## 🔧 Setup Instructions

1. **Initialize Firebase Project:**
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init
   ```

2. **Configure Environment:**
   ```bash
   cp .env.example .env
   # Edit .env with your Firebase credentials
   ```

3. **Deploy Firestore Rules:**
   ```bash
   firebase deploy --only firestore:rules
   ```

4. **Deploy Storage Rules:**
   ```bash
   firebase deploy --only storage:rules
   ```

5. **Create Indexes:**
   ```bash
   firebase deploy --only firestore:indexes
   ```

## 📈 Monitoring & Analytics

- Use Firebase Analytics dashboard for usage insights
- Monitor Firestore usage and costs
- Set up alerts for unusual activity
- Regular backup of critical data

## 🔄 Data Migration

Use the `/api/admin/migrate-data` endpoint to migrate existing in-memory data to Firebase when first setting up the integration.

## 🎯 Future Enhancements

1. **Authentication Integration**
   - User accounts and profiles
   - Personal scan history
   - Custom preferences

2. **Advanced Analytics**
   - Threat pattern analysis
   - Geographic threat mapping
   - Network behavior insights

3. **Machine Learning**
   - Threat prediction models
   - Network classification
   - Anomaly detection

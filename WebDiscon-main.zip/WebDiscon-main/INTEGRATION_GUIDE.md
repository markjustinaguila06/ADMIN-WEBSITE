# DisCon-X Website & Mobile App Integration Guide

## 🔗 Overview

This guide explains how the DisCon-X website dashboard and Flutter mobile app are integrated to provide real-time network monitoring and threat detection across platforms.

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Mobile App    │    │  Web Dashboard  │    │   Shared Data   │
│   (Flutter)     │    │  (Express.js)   │    │   (Firebase)    │
├─────────────────┤    ├─────────────────┤    ├─────────────────┤
│ • WiFi Scanning │    │ • Real-time UI  │    │ • Firestore DB  │
│ • Threat Detect │◄──►│ • API Endpoints │◄──►│ • Analytics     │
│ • GPS Tracking  │    │ • WebSocket     │    │ • Configuration │
│ • Local Storage │    │ • Data Display  │    │ • Sync Service  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🚀 Features

### Real-time Data Sync
- **Network Scan Results**: Mobile app scan data appears instantly on the dashboard
- **Threat Alerts**: Suspicious networks detected by mobile trigger dashboard alerts  
- **Statistics Updates**: Live network statistics and counts
- **Location Tracking**: GPS coordinates from mobile scans shown on dashboard map

### API Integration
- **REST API**: RESTful endpoints for data exchange
- **WebSocket**: Real-time bidirectional communication
- **Configuration**: Server-side configuration pushed to mobile app
- **Safety Tips**: Shared security tips database

### Firebase Integration
- **Firestore**: Shared database for persistent data
- **Analytics**: Usage tracking and performance monitoring
- **Storage**: File storage for network data and reports
- **Performance**: Real-time performance monitoring

## 📡 API Endpoints

### Mobile App Endpoints
```
POST /api/mobile/scan-data          # Submit network scan results
GET  /api/mobile/scan-data          # Get current scan data
POST /api/mobile/threat-report      # Submit threat report
GET  /api/mobile/threat-reports     # Get threat reports
GET  /api/mobile/config             # Get app configuration
```

### Safety Tips Endpoints
```
GET  /api/safety-tips               # Get all safety tips
GET  /api/safety-tips/:id           # Get specific tip
GET  /api/safety-tips/category/:cat # Get tips by category
GET  /api/safety-tips/priority/:pri # Get tips by priority
```

### Health & Status
```
GET  /api/health                    # API health check
```

## 🔌 WebSocket Events

### Server → Dashboard
- `scanDataUpdate`: New scan data from mobile
- `threatReportUpdate`: New threat report
- `threatReportsUpdate`: Batch threat reports update

### Dashboard → Server
- `requestScanUpdate`: Request latest scan data
- `requestThreatReports`: Request threat reports

## 📱 Mobile App Integration

### Network Provider Integration
The `NetworkProvider` in the Flutter app automatically:
1. Initializes web dashboard service on startup
2. Submits scan data after each network scan
3. Sends threat reports when suspicious networks detected
4. Syncs configuration from server

### Key Services
- **WebDashboardService**: Handles API communication
- **NetworkProvider**: Manages network scanning and data
- **FirebaseService**: Handles Firebase integration

### Configuration
Add to `shared_preferences`:
```dart
prefs.setString('dashboard_url', 'http://your-server:3000');
```

## 🌐 Dashboard Integration

### JavaScript Modules
- **mobile-integration.js**: Main integration logic
- **WebSocket client**: Real-time communication
- **API client**: REST API calls
- **UI updates**: Dynamic content updates

### CSS Components
- **mobile-integration.css**: Integration-specific styles
- **Connection indicators**: Visual connection status
- **Real-time animations**: Data update effects
- **Responsive design**: Mobile-friendly layouts

## 🛠️ Setup Instructions

### 1. Start the Server
```bash
cd websitecapstone
npm install
npm start
```
Server runs at: `http://localhost:3000`

### 2. Configure Mobile App
In the Flutter app, set the dashboard URL:
```dart
// In shared preferences or app config
dashboard_url: 'http://your-server-ip:3000'
```

### 3. Firebase Setup (Optional)
1. Create Firebase project
2. Add configuration files:
   - `android/app/google-services.json`
   - `ios/Runner/GoogleService-Info.plist`
3. Enable Firestore, Analytics, and Storage

### 4. Mobile App Build
```bash
cd disconx
flutter pub get
flutter run
```

## 📊 Data Flow

### 1. Network Scanning
```
Mobile App → WiFi Scan → Process Results → Submit to Dashboard
                ↓
Dashboard ← WebSocket ← Server ← API Endpoint ← Mobile Data
```

### 2. Threat Detection
```
Mobile App → Detect Threat → Generate Report → Submit to Server
                ↓
Dashboard ← Real-time Alert ← WebSocket ← Threat Report ← Mobile
```

### 3. Configuration Sync
```
Server → Configuration → API Response → Mobile App → Local Storage
```

## 🔧 Customization

### Adding New Data Types
1. **Server**: Add new API endpoint in `server.js`
2. **Mobile**: Add service method in `WebDashboardService`
3. **Dashboard**: Add WebSocket handler in `mobile-integration.js`
4. **UI**: Add display components in HTML/CSS

### Custom WebSocket Events
```javascript
// Dashboard
socket.emit('customEvent', data);
socket.on('customResponse', (data) => {
    // Handle response
});

// Server
socket.on('customEvent', (data) => {
    // Process data
    socket.emit('customResponse', response);
});
```

### Mobile Service Extensions
```dart
// Add to WebDashboardService
Future<bool> submitCustomData(Map<String, dynamic> data) async {
    final response = await _dio.post('/api/mobile/custom', data: data);
    return response.statusCode == 200;
}
```

## 🐛 Troubleshooting

### Connection Issues
1. **Check server status**: Visit `http://localhost:3000/api/health`
2. **Verify network**: Ensure mobile and server on same network
3. **Check firewall**: Allow port 3000 connections
4. **WebSocket errors**: Check browser console for connection errors

### Mobile App Issues
1. **Permissions**: Ensure location and WiFi permissions granted
2. **Network access**: Check internet connectivity
3. **Configuration**: Verify dashboard URL in app settings
4. **Logs**: Check Flutter debug console for errors

### Data Sync Issues
1. **API responses**: Check server logs for API calls
2. **WebSocket**: Monitor network tab for WebSocket messages
3. **Firebase**: Verify Firebase configuration if using
4. **Timing**: Check for race conditions in initialization

## 📈 Performance Optimization

### Mobile App
- **Batch uploads**: Group multiple scan results
- **Compression**: Compress large network data
- **Caching**: Cache API responses locally
- **Background sync**: Sync when app backgrounded

### Dashboard
- **WebSocket pooling**: Limit concurrent connections
- **Data pagination**: Limit displayed items
- **Update throttling**: Debounce rapid updates
- **Memory management**: Clean up old data

## 🔒 Security Considerations

### API Security
- **Rate limiting**: Prevent API abuse
- **Input validation**: Sanitize all inputs
- **Authentication**: Add API keys if needed
- **HTTPS**: Use SSL in production

### Data Privacy
- **Location data**: Anonymize GPS coordinates
- **Device IDs**: Use app-generated UUIDs
- **Network data**: Hash sensitive information
- **Storage**: Encrypt sensitive data

## 📝 Example Usage

### Testing the Integration

1. **Start server**: `npm start`
2. **Open dashboard**: `http://localhost:3000`
3. **Run mobile app**: Start Flutter app
4. **Perform scan**: Trigger network scan in mobile app
5. **View results**: Check dashboard for real-time updates

### Sample API Calls

```javascript
// Submit scan data from mobile
fetch('/api/mobile/scan-data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        networks: [...],
        statistics: { totalNetworks: 10, threats: 2 },
        deviceId: 'device_123',
        location: { latitude: 14.2117, longitude: 121.1644 }
    })
});

// Get threat reports for dashboard
fetch('/api/mobile/threat-reports?limit=20')
    .then(response => response.json())
    .then(data => console.log(data.reports));
```

## 🎯 Next Steps

1. **Enhanced Security**: Implement authentication and encryption
2. **Advanced Analytics**: Add data visualization and insights
3. **Offline Support**: Cache data for offline operation
4. **Multi-device**: Support multiple mobile devices
5. **Notifications**: Add push notifications for critical threats

## 📞 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review server and mobile app logs
3. Test API endpoints manually
4. Verify network connectivity and permissions

---

**Note**: This integration provides a foundation for real-time network monitoring. Extend and customize based on your specific requirements.

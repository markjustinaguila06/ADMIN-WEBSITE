# 🔥 Firebase Integration for DisCon-X

This document provides a complete guide for setting up and using Firebase with your DisCon-X application.

## 📋 Table of Contents

- [Overview](#overview)
- [Quick Start](#quick-start)
- [Setup Instructions](#setup-instructions)
- [Configuration](#configuration)
- [API Endpoints](#api-endpoints)
- [Database Schema](#database-schema)
- [Data Migration](#data-migration)
- [Real-time Features](#real-time-features)
- [Security](#security)
- [Monitoring](#monitoring)
- [Troubleshooting](#troubleshooting)

## 🌟 Overview

The Firebase integration adds persistent data storage, real-time synchronization, and cloud analytics to your DisCon-X application. It supports:

- **Firestore Database** - Scalable NoSQL database for all app data
- **Firebase Storage** - File storage for whitelists and exports
- **Firebase Analytics** - Usage tracking and insights
- **Real-time Sync** - Live data updates across all connected clients
- **Offline Support** - Cached data when Firebase is unavailable

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install firebase-admin dotenv
npm install -g firebase-tools
```

### 2. Setup Firebase Project

```bash
# Login to Firebase
firebase login

# Initialize Firebase in your project
firebase init

# Select: Firestore, Storage, Functions (optional)
```

### 3. Configure Environment

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your Firebase credentials
nano .env
```

### 4. Run Setup Script

```bash
# Run the automated setup
node setup-firebase.js
```

### 5. Start the Server

```bash
npm start
```

## 🛠️ Setup Instructions

### Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Click "Create a project"
3. Enter project name: `discon-x-app`
4. Enable Google Analytics (optional)
5. Choose analytics account

### Step 2: Enable Services

1. **Firestore Database:**
   - Go to Firestore Database
   - Click "Create database"
   - Start in test mode
   - Choose location closest to your users

2. **Storage:**
   - Go to Storage
   - Click "Get started"
   - Start in test mode

3. **Analytics (Optional):**
   - Already enabled if chosen during project creation

### Step 3: Generate Service Account

1. Go to Project Settings → Service Accounts
2. Click "Generate new private key"
3. Download the JSON file
4. Extract credentials for `.env` file

### Step 4: Configure Environment Variables

Create `.env` file in project root:

```env
# Firebase Configuration
FIREBASE_PROJECT_ID=your-project-id
FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYour-Private-Key-Here\n-----END PRIVATE KEY-----\n"
FIREBASE_CLIENT_EMAIL=firebase-adminsdk-xxxxx@your-project-id.iam.gserviceaccount.com

# Optional
FIREBASE_DATABASE_URL=https://your-project-id-default-rtdb.firebaseio.com/
FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com

# Server Configuration
PORT=3000
NODE_ENV=development
```

### Step 5: Deploy Security Rules

```bash
# Deploy Firestore rules
firebase deploy --only firestore:rules

# Deploy Storage rules
firebase deploy --only storage:rules

# Deploy indexes
firebase deploy --only firestore:indexes
```

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `FIREBASE_PROJECT_ID` | Your Firebase project ID | Yes |
| `FIREBASE_PRIVATE_KEY` | Service account private key | Yes |
| `FIREBASE_CLIENT_EMAIL` | Service account email | Yes |
| `FIREBASE_DATABASE_URL` | Realtime Database URL | No |
| `FIREBASE_STORAGE_BUCKET` | Storage bucket name | No |
| `PORT` | Server port (default: 3000) | No |
| `NODE_ENV` | Environment (development/production) | No |

### Firebase Configuration Files

- `firebase.json` - Firebase project configuration
- `firestore.rules` - Database security rules
- `storage.rules` - Storage security rules
- `firestore.indexes.json` - Database indexes

## 🔗 API Endpoints

### Enhanced Endpoints with Firebase

All existing endpoints now support Firebase storage with fallback to in-memory storage:

#### Network Scanning
```http
POST /api/mobile/scan-data
GET  /api/mobile/scan-data?limit=10&deviceId=device123
```

#### Threat Reporting
```http
POST /api/mobile/threat-report
GET  /api/mobile/threat-reports?limit=50&status=pending
PATCH /api/mobile/threat-reports/:id/status
```

#### Safety Tips
```http
GET /api/safety-tips
GET /api/safety-tips/category/:category
GET /api/safety-tips/priority/:priority
GET /api/safety-tips/:id
```

#### Configuration
```http
GET /api/mobile/config
```

### New Firebase-Specific Endpoints

#### Data Migration
```http
POST /api/admin/migrate-data
```
Migrates existing in-memory data to Firebase.

#### Analytics
```http
POST /api/analytics/event
```
Saves analytics events to Firebase.

#### Health Check
```http
GET /api/health
```
Enhanced with Firebase status.

## 🗄️ Database Schema

### Collections

1. **`network_scans`** - Network scan data from mobile devices
2. **`threat_reports`** - Threat reports and suspicious network data
3. **`safety_tips`** - Security education content
4. **`config`** - Application configuration
5. **`analytics`** - Analytics events and usage data
6. **`whitelists`** - Trusted network whitelist metadata
7. **`users`** - User data (future authentication)

See [firebase-schema.md](firebase-schema.md) for detailed schema documentation.

## 📦 Data Migration

### Automatic Migration

Run the migration endpoint to move existing data:

```bash
curl -X POST http://localhost:3000/api/admin/migrate-data
```

### Manual Migration

Use the setup script for initial data import:

```bash
node setup-firebase.js
```

### Migration Features

- **Safety Tips**: Imports all default security tips
- **Configuration**: Sets up default app configuration
- **Sample Data**: Creates test network scans and threat reports
- **Validation**: Checks data integrity during migration

## ⚡ Real-time Features

### WebSocket Integration

The Firebase integration maintains real-time WebSocket updates:

```javascript
// Client-side WebSocket events
socket.on('scanDataUpdate', (data) => {
    console.log('New scan data:', data);
    // Update dashboard UI
});

socket.on('threatReportUpdate', (data) => {
    console.log('New threat report:', data);
    // Update threats display
});

socket.on('threatReportStatusUpdate', (data) => {
    console.log('Threat report status changed:', data);
    // Update report status
});
```

### Firebase Real-time Subscriptions

```javascript
// Server-side real-time subscriptions
const unsubscribeScans = firebaseService.subscribeToNetworkScans((snapshot) => {
    snapshot.forEach(doc => {
        const scanData = { id: doc.id, ...doc.data() };
        io.emit('scanDataUpdate', scanData);
    });
});

const unsubscribeReports = firebaseService.subscribeToThreatReports((snapshot) => {
    snapshot.forEach(doc => {
        const reportData = { id: doc.id, ...doc.data() };
        io.emit('threatReportUpdate', reportData);
    });
});
```

## 🔒 Security

### Current Security Rules

**Development Mode:**
- All reads/writes allowed for testing
- No authentication required

**Production Recommendations:**
- Enable Firebase Authentication
- Restrict write access to authenticated users
- Implement field-level security
- Add rate limiting

### Security Rules Examples

```javascript
// Firestore Rules (Production)
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Require authentication
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
    
    // Public safety tips (read-only)
    match /safety_tips/{tipId} {
      allow read: if true;
      allow write: if false;
    }
    
    // User data (own data only)
    match /users/{userId} {
      allow read, write: if request.auth.uid == userId;
    }
  }
}
```

## 📊 Monitoring

### Firebase Console Monitoring

1. **Database Usage**: Monitor reads/writes in Firestore
2. **Storage Usage**: Track file storage consumption
3. **Analytics**: View user engagement metrics
4. **Performance**: Monitor query performance

### Application Health Monitoring

Check Firebase status via health endpoint:

```bash
curl http://localhost:3000/api/health
```

Response includes Firebase connectivity status:

```json
{
  "success": true,
  "status": "healthy",
  "integrations": {
    "firebase": "healthy"
  },
  "firebase": {
    "success": true,
    "status": "healthy"
  }
}
```

### Logging

The application logs Firebase operations:

```
🔥 Firebase initialized successfully
📚 Safety tips imported to Firebase
⚙️ Default app configuration set
✅ Network scan data saved to Firebase
📊 Threat report saved to Firebase
```

## 🐛 Troubleshooting

### Common Issues

#### 1. Firebase Initialization Failed
```
❌ Firebase initialization error: [Error details]
```

**Solutions:**
- Check `.env` file has correct credentials
- Verify Firebase project exists
- Ensure service account has proper permissions
- Check internet connectivity

#### 2. Firestore Permission Denied
```
Error: Missing or insufficient permissions
```

**Solutions:**
- Update Firestore security rules
- Enable authentication if required
- Check service account permissions
- Verify project configuration

#### 3. Data Not Syncing
```
⚠️ Falling back to in-memory storage
```

**Solutions:**
- Check Firebase service status
- Verify network connectivity
- Monitor Firebase console for errors
- Restart the server

#### 4. Environment Variables Missing
```
Error: Missing required environment variable
```

**Solutions:**
- Copy `.env.example` to `.env`
- Fill in all required Firebase credentials
- Restart the server after changes

### Debug Mode

Enable debug logging by setting:

```env
NODE_ENV=development
DEBUG=firebase:*
```

### Health Checks

Regular health check endpoints:

```bash
# Check overall API health
curl http://localhost:3000/api/health

# Test Firebase connectivity
curl -X POST http://localhost:3000/api/admin/migrate-data
```

## 📚 Additional Resources

- [Firebase Documentation](https://firebase.google.com/docs)
- [Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started)
- [Firebase Admin SDK](https://firebase.google.com/docs/admin/setup)
- [Firebase Console](https://console.firebase.google.com)

## 🎯 Next Steps

1. **Enable Authentication**: Add user accounts and profiles
2. **Advanced Security**: Implement production security rules
3. **Analytics Dashboard**: Create data visualization
4. **Offline Support**: Enhance offline capabilities
5. **Performance Optimization**: Optimize queries and indexes

---

🔥 **Firebase Integration Complete!** Your DisCon-X application now has persistent, scalable data storage with real-time synchronization capabilities.
